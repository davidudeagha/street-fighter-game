package AI;

import Utils.MoveMap;
import org.junit.Test;

import java.util.List;
import java.util.Map;
import java.util.Random;

public class IntegratedMarkovLearnerTest {


    @Test
    public static void main(String[] args) {
//        Map<Integer, Move> map = new HashMap<>();
//        map.put(0, new HighKick());
//        map.put(1, new HighPunch());
//        map.put(2, new LowKick());
//        map.put(3, new LowPunch());
//        map.put(4, new HighBlock());
//        map.put(5, new LowBlock());
//        map.put(6,new MoveForward());
//        map.put(7,new MoveBackward());
        Map<Integer, GameLogic.Move> map = new MoveMap().getMap();

        IntegratedMarkovLearner model = new IntegratedMarkovLearner();

        for (int i = 0; i < 100; i++) {
            Random random = new Random();
            int chosenMove = random.nextInt(6);
//            int chosenMove = 1;
            System.out.println("Human Move "+ map.get(chosenMove));
            model.update(chosenMove);


            int move = model.chooseMove(100, 105);
            List<Float> scores = model.getExpectedScores();
            System.out.println("AI Move "+map.get(move)+"\n\n");
//            System.out.println(scores);
            int largest = 0;
            for (int j = 0; j < scores.size(); j++) {
                if (scores.get(j) > scores.get(largest)) largest = j;
            }

//            Assert.assertEquals(map.get(largest), map.get(move));

//            System.out.println(random.nextInt(4));
        }
//        System.out.println("FIn");
    }

}