package AI;

import java.util.Arrays;
import java.util.List;
import java.util.Random;

import org.junit.Test;

public class LearnerTest {
    int[][] scores = {{10, 0, 0, 10}, {10, 10, 10, 0}, {5, 0, 0, 0}, {0, 5, 0, 0}};








    @Test
    public void chooseMove() {
        List<List<Integer>> s = Arrays.asList(Arrays.asList(10,0,0,10),Arrays.asList(10,10,10,0),Arrays.asList(5,0,0,0),Arrays.asList(0,5,0,0));
        Learner learner = new Learner(s);

        for (int i=0;i<100;i++){
            Random random = new Random();
            learner.update(random.nextInt(3)+1) ;

//            System.out.println(learner.predict());
            System.out.println(learner.chooseMove());

//            System.out.println(random.nextInt(4));
        }


        System.out.println("END");


    }




}