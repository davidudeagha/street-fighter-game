package Client;

import Level.HumanVSHumanLevel;
import RenderEngine.Game;
import javafx.application.Application;
import javafx.stage.Stage;

public class TestClient extends Application {

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage stage) throws Exception {
        Game game = new Game(new HumanVSHumanLevel(1));
//        Game game = new Game(new HumanVSAILevel());
    }
}
