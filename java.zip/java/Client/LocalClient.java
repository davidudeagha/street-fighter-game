package Client;

import Level.HumanVSAILevel;
import Level.HumanVSHumanLevel;
import Network.DBConnect;
import Network.Login;
import Network.Register;
import RenderEngine.Game;
import javafx.animation.FadeTransition;
import javafx.animation.TranslateTransition;
import javafx.application.Application;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.effect.DropShadow;
import javafx.scene.effect.GaussianBlur;
import javafx.scene.effect.Glow;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.*;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.util.Callback;
import javafx.util.Duration;

import java.io.File;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DecimalFormat;

public class LocalClient extends Application {

	private GameMenu gameMenu;
	private MediaPlayer mediaPlayer;
	private double volume = 1;
	private DecimalFormat df = new DecimalFormat("#.##");
	Pane root;
	Scene scene;
	
	@Override
	public void start(Stage primaryStage) throws Exception {
		try {
			String bip = "resources/sounds/Big Mojo.mp3";
			Media media = new javafx.scene.media.Media(Paths.get(bip).toUri().toString());
			mediaPlayer = new MediaPlayer(media);
			mediaPlayer.setVolume(1);
			mediaPlayer.setCycleCount(MediaPlayer.INDEFINITE);
			mediaPlayer.play();
		} catch (Exception e) {
			try {
				String bip = "src/main/resources/sounds/Big Mojo.wav";
//            Media media = new javafx.scene.media.Media(Paths.get(bip).toUri().toString());

				Media media = new Media(new File(bip).toURI().toString());

				mediaPlayer = new MediaPlayer(media);
				mediaPlayer.setVolume(1);
				mediaPlayer.setCycleCount(MediaPlayer.INDEFINITE);
				mediaPlayer.play();
			} catch (Exception x) {
				System.err.println("Media player error");
			}
		}
		root = new Pane();
		root.setPrefSize(800, 600);

//        InputStream is = Files.newInputStream(Paths.get("src/main/resources/images/SF5.jpg"));
		InputStream is = Files.newInputStream(Paths.get("src/main/resources/images/Backgrounds/bg2.jpg"));
		Image img = new Image(is);

		is.close();

		ImageView imgView = new ImageView(img);
		imgView.setFitWidth(800);
		imgView.setFitHeight(600); // to fit the window

		gameMenu = new GameMenu();
		gameMenu.setVisible(true);

		root.getChildren().addAll(imgView, gameMenu); // display image as an image view

		scene = new Scene(root);
		scene.setOnKeyPressed(event -> {
			if (event.getCode() == KeyCode.ESCAPE) {
				if (!gameMenu.isVisible()) {
					FadeTransition ft = new FadeTransition(Duration.seconds(0.5), gameMenu);
					ft.setFromValue(0);
					ft.setToValue(1);
					gameMenu.setVisible(true);
					ft.play();
				} else {
					FadeTransition ft = new FadeTransition(Duration.seconds(0.5), gameMenu);
					ft.setFromValue(1);
					ft.setToValue(0);
					ft.setOnFinished(evt -> gameMenu.setVisible(false));
					ft.play();
				}
			}
		});

		primaryStage.setScene(scene);
		primaryStage.show();

	} // for the background image

	private class GameMenu extends Parent {
		private String username = ""; // a node that can contain children

		GameMenu() {

			VBox menu0 = new VBox(10);// 10 is the distance between two elements
			VBox menu1 = new VBox(10);
			VBox menu2 = new VBox(10);
			VBox menu3 = new VBox(10);
			VBox menu4 = new VBox(10);
			VBox onlineMenu1 = new VBox(10);
			VBox leaderboardMenu = new VBox(10);

			VBox.setVgrow(menu0, Priority.ALWAYS);

			menu0.setTranslateX(100);
			menu0.setTranslateY(200);

			menu1.setTranslateX(100);
			menu1.setTranslateY(200);

			menu2.setTranslateX(100);
			menu2.setTranslateY(200);

			menu3.setTranslateX(100);
			menu3.setTranslateY(200);

			menu4.setTranslateX(100);
			menu4.setTranslateY(200);

			onlineMenu1.setTranslateX(100);
			onlineMenu1.setTranslateY(200);

			leaderboardMenu.setTranslateX(100);
			leaderboardMenu.setTranslateY(50);

			final int offset = 400;

			menu1.setTranslateX(offset);
			menu2.setTranslateX(offset);
			menu3.setTranslateX(offset);
			menu0.setTranslateX(offset);
			onlineMenu1.setTranslateX(offset);
			leaderboardMenu.setTranslateX(offset);

			Label lname = new Label("Username : ");
			Label lpassword = new Label("Password : ");
			Label lmessage = new Label();

			TextField tfname = new TextField();
			PasswordField tfpassword = new PasswordField();
			MenuButton btnRegister = new MenuButton("Register");
			btnRegister.setOnMouseClicked(event -> {
				lmessage.setStyle("-fx-text-fill: red;");
				username = tfname.getText();

				System.out.println(tfpassword.getText());
				String password = tfpassword.getText();
				if (username.equals("")) {
					lmessage.setText("Please enter your username");
				} else if (password.equals("")) {
					lmessage.setText("Please enter your password");
					/*
					 * Introduce another else if clause here with the database, if not in the
					 * database, then the final else clause is called
					 */
				} else {
					System.out.println(username + " " + password);
					Register register = new Register();
					register.register(username, password);
					register.close();
				}
			});
			MenuButton btnLogin = new MenuButton("Login");
			btnLogin.setOnMouseClicked(event -> {
				lmessage.setStyle("-fx-text-fill: red;");
				username = tfname.getText();

				System.out.println(tfpassword.getText());
				String password = tfpassword.getText();
				if (username.equals("")) {
					lmessage.setText("Please enter your username");
				} else if (password.equals("")) {
					lmessage.setText("Please enter your password");
					/*
					 * Introduce another else if clause here with the database, if not in the
					 * database, then the final else clause is called
					 */
				} else {
					System.out.println(username + " " + password);
					Login login = new Login();
					if (login.login(username, password)) {
						login.close();
						System.out.println("Login Successful");

						getChildren().add(menu0);
						TranslateTransition tt = new TranslateTransition(Duration.seconds(0.25), menu4);
						tt.setToX(menu4.getTranslateX() - offset);

						TranslateTransition tt1 = new TranslateTransition(Duration.seconds(0.5), menu0);
						tt1.setToX(menu4.getTranslateX());

						tt.play();
						tt1.play();

						tt.setOnFinished(evt -> {
							getChildren().remove(menu4);
						});
					}

////                    Client4Two ct = new Client4Two(new UpdatePacket(new HumanCharacter()));
//                    try {
//                        ct.createRoom(513);
//                        ct.joinRoom(513);
//                        ct.match();

//                    } catch (Exception e) {
//                        e.printStackTrace();
//                    }

				}
			});

			Label roomNumberLabel = new Label("Enter room number");
			TextField roomNumber = new TextField();
			MenuButton btnConnect = new MenuButton("Connect");
			btnConnect.setOnMouseClicked(mouseEvent -> {
				try {
					int rn = Integer.valueOf(roomNumber.getText());
//                        onlineMenu1.setVisible(false);
					// todo make menu disappear when game starts
					this.setVisible(false);
					super.setVisible(false);
					root.setVisible(false);
					Game game = new Game(new HumanVSHumanLevel(rn));
				} catch (Exception e) {
					roomNumberLabel.setText("Error with input, please enter a valid number");
				}
			});
//            MenuButton btnResume = new MenuButton("Resume");
//            btnResume.setOnMouseClicked(event -> {
//                FadeTransition ft = new FadeTransition(Duration.seconds(0.5), this); // animation for it
//                ft.setFromValue(1);
//                ft.setToValue(0);
//                ft.setOnFinished(evt -> setVisible(false));
//                ft.play();
//            });

			MenuButton btnOptions = new MenuButton("Options");
			btnOptions.setOnMouseClicked(event -> {
				getChildren().add(menu1);

				TranslateTransition tt = new TranslateTransition(Duration.seconds(0.25), menu0);
				tt.setToX(menu0.getTranslateX() - offset);

				TranslateTransition tt1 = new TranslateTransition(Duration.seconds(0.5), menu1);
				tt1.setToX(menu0.getTranslateX());

				tt.play();
				tt1.play();

				tt.setOnFinished(evt -> {
					getChildren().remove(menu0);
				});
			});

			MenuButton btnExit = new MenuButton("Exit");
			btnExit.setOnMouseClicked(event -> {
				System.exit(0);
			});

			MenuButton btnFreeBattle = new MenuButton("Free Battle");
			btnFreeBattle.setOnMouseClicked(event -> {
				getChildren().add(menu2);

				TranslateTransition tt = new TranslateTransition(Duration.seconds(0.25), menu0);
				tt.setToX(menu0.getTranslateX() - offset);

				TranslateTransition tt1 = new TranslateTransition(Duration.seconds(0.5), menu2);
				tt1.setToX(menu0.getTranslateX());

				tt.play();
				tt1.play();

				tt.setOnFinished(evt -> {
					getChildren().remove(menu0);
				});
			});

			MenuButton btnBack = new MenuButton("Back");
			btnBack.setOnMouseClicked(event -> {
				getChildren().add(menu0);

				TranslateTransition tt = new TranslateTransition(Duration.seconds(0.25), menu1);
				tt.setToX(menu1.getTranslateX() + offset);

				TranslateTransition tt1 = new TranslateTransition(Duration.seconds(0.5), menu0);
				tt1.setToX(menu1.getTranslateX());

				tt.play();
				tt1.play();

				tt.setOnFinished(evt -> {
					getChildren().remove(menu1);
				});
			});

			MenuButton btnBack2 = new MenuButton("Back");
			btnBack2.setOnMouseClicked(event -> {
				getChildren().add(menu0);

				TranslateTransition tt = new TranslateTransition(Duration.seconds(0.25), menu2);
				tt.setToX(menu2.getTranslateX() + offset);

				TranslateTransition tt1 = new TranslateTransition(Duration.seconds(0.5), menu0);
				tt1.setToX(menu2.getTranslateX());

				tt.play();
				tt1.play();

				tt.setOnFinished(evt -> {
					getChildren().remove(menu2);
				});
			});

			MenuButton btnInc = new MenuButton("Increase Volume");
			btnInc.setOnMouseClicked(event -> {
				if (volume == 1) {
					mediaPlayer.setVolume(1);
				} else {
					volume = volume + 0.05;
					volume = Double.parseDouble(df.format(volume));
					mediaPlayer.setVolume(volume);
				}
			});

			MenuButton btnDec = new MenuButton("Decrease Volume");
			btnDec.setOnMouseClicked(event -> {
				if (volume == 0) {
					mediaPlayer.setVolume(0);
				} else {
					volume = volume - 0.05;
					volume = Double.parseDouble(df.format(volume));
					mediaPlayer.setVolume(volume);
				}
			});

			MenuButton btnVideo = new MenuButton("Video");

			MenuButton btnMute = new MenuButton("Mute/Unmute Sounds");
			btnMute.setOnMouseClicked(event -> {
				if (mediaPlayer.getVolume() == 0) {
					mediaPlayer.setVolume(volume);
				} else if (mediaPlayer.getVolume() > 0) {
					mediaPlayer.setVolume(0);
				}
			});

//            MenuButton btnLocal = new MenuButton("Local Multiplayer");
//            btnLocal.setOnMouseClicked(event -> {
//                getChildren().add(menu3);
//
//                TranslateTransition tt = new TranslateTransition(Duration.seconds(0.25), menu2);
//                tt.setToX(menu2.getTranslateX() - offset);
//
//                TranslateTransition tt1 = new TranslateTransition(Duration.seconds(0.5), menu3);
//                tt1.setToX(menu2.getTranslateX());
//
//                tt.play();
//                tt1.play();
//
//                tt.setOnFinished(evt -> {
//                    getChildren().remove(menu2);
//                });
//            });

			MenuButton btnBack3 = new MenuButton("Back");
			btnBack3.setOnMouseClicked(event -> {
				getChildren().add(menu2);

				TranslateTransition tt = new TranslateTransition(Duration.seconds(0.25), menu3);
				tt.setToX(menu3.getTranslateX() + offset);

				TranslateTransition tt1 = new TranslateTransition(Duration.seconds(0.5), menu2);
				tt1.setToX(menu3.getTranslateX());

				tt.play();
				tt1.play();

				tt.setOnFinished(evt -> {
					getChildren().remove(menu3);
				});
			});

			MenuButton btnOnline = new MenuButton("Online Multiplayer");
			btnOnline.setOnMouseClicked(event -> {
				getChildren().add(onlineMenu1);

				TranslateTransition tt = new TranslateTransition(Duration.seconds(0.25), menu2);
				tt.setToX(menu2.getTranslateX() - offset);

				TranslateTransition tt1 = new TranslateTransition(Duration.seconds(0.5), onlineMenu1);
				tt1.setToX(menu2.getTranslateX());

				tt.play();
				tt1.play();

				tt.setOnFinished(evt -> {
					getChildren().remove(menu2);
				});
			});
			
			MenuButton btnBack4 = new MenuButton("Back");
			btnBack4.setOnMouseClicked(event -> {
				getChildren().add(menu2);

				TranslateTransition tt = new TranslateTransition(Duration.seconds(0.25), menu4);
				tt.setToX(menu4.getTranslateX() + offset);

				TranslateTransition tt1 = new TranslateTransition(Duration.seconds(0.5), menu2);
				tt1.setToX(menu4.getTranslateX());

				tt.play();
				tt1.play();

				tt.setOnFinished(evt -> {
					getChildren().remove(menu4);
				});
			});
			MenuButton btnCOM = new MenuButton("COM VS Battle");
			btnCOM.setOnMouseClicked(event -> {
//                Game gameDemo = new Game();
				Game game = new Game(new HumanVSAILevel(username));

//                gameDemo.run();

			});
			MenuButton btnTwo = new MenuButton("Two Player");
			MenuButton btnTournament = new MenuButton("Tournament Mode");

			MenuButton btnLeaderboard = new MenuButton("Leaderboard");
			btnLeaderboard.setOnMouseClicked(event -> {
				
				getChildren().add(leaderboardMenu);

				TranslateTransition tt = new TranslateTransition(Duration.seconds(0.25), menu0);
				tt.setToX(menu0.getTranslateX() - offset);

				TranslateTransition tt1 = new TranslateTransition(Duration.seconds(0.5), leaderboardMenu);
				tt1.setToX(menu0.getTranslateX());

				tt.play();
				tt1.play();

				tt.setOnFinished(evt -> {
					getChildren().remove(menu0);
				});
			});

			// leaderboard
			TableView leaderboard = new TableView();
			Connection conn = DBConnect.getConn();
			PreparedStatement pstmt;
			String getLeaderBoardData = "SELECT userInfo.username, score FROM scores,userInfo WHERE id=scores.playerID ORDER BY score DESC;";
			try {
				ObservableList<ObservableList> data = FXCollections.observableArrayList();
				pstmt = conn.prepareStatement(getLeaderBoardData);
				ResultSet rs = pstmt.executeQuery();
				for (int i = 0; i < rs.getMetaData().getColumnCount(); i++) {
					final int j = i;
					TableColumn col = new TableColumn(rs.getMetaData().getColumnName(i + 1));
					col.setCellValueFactory(
							(Callback<TableColumn.CellDataFeatures<ObservableList, String>, ObservableValue<String>>) param -> new SimpleStringProperty(
									param.getValue().get(j).toString()));

					leaderboard.getColumns().addAll(col);
					System.out.println("Column [" + i + "] ");
				}
				while (rs.next()) {
					ObservableList<String> row = FXCollections.observableArrayList();
					for (int i = 1; i <= rs.getMetaData().getColumnCount(); i++) {
						// Iterate Column
						row.add(rs.getString(i));
					}
					System.out.println("Row [1] added " + row);
					data.add(row);

				}
				leaderboard.setItems(data);
				rs.close();
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}

			MenuButton btnBack5 = new MenuButton("Back");
			btnBack5.setOnMouseClicked(event -> {
				getChildren().add(menu0);

				TranslateTransition tt = new TranslateTransition(Duration.seconds(0.25), leaderboardMenu);
				tt.setToX(leaderboardMenu.getTranslateX() + offset);

				TranslateTransition tt1 = new TranslateTransition(Duration.seconds(0.5), menu0);
				tt1.setToX(leaderboardMenu.getTranslateX());

				tt.play();
				tt1.play();

				tt.setOnFinished(evt -> {
					getChildren().remove(leaderboardMenu);
				});
			});
			
			MenuButton btnBack6 = new MenuButton("Back");
			btnBack6.setOnMouseClicked(event -> {
				getChildren().add(menu2);

				TranslateTransition tt = new TranslateTransition(Duration.seconds(0.25), onlineMenu1);
				tt.setToX(onlineMenu1.getTranslateX() + offset);

				TranslateTransition tt1 = new TranslateTransition(Duration.seconds(0.5), menu2);
				tt1.setToX(onlineMenu1.getTranslateX());

				tt.play();
				tt1.play();

				tt.setOnFinished(evt -> {
					getChildren().remove(onlineMenu1);
				});
			});

			GridPane menu4Grid = new GridPane();
			menu4Grid.addRow(0, lname, tfname);
			menu4Grid.addRow(1, lpassword, tfpassword);
			menu4Grid.add(btnLogin, 2, 0, 1, 2);
			menu4Grid.add(btnRegister, 2, 4, 1, 2);
			menu4Grid.add(lmessage, 0, 2, 3, 1);
			menu4Grid.setAlignment(Pos.CENTER);

			GridPane onlineMenuGrid = new GridPane();
			onlineMenuGrid.addRow(0, roomNumberLabel, roomNumber);
			onlineMenuGrid.addRow(1);
			onlineMenuGrid.add(btnConnect, 2, 0, 1, 2);
			onlineMenuGrid.setAlignment(Pos.CENTER);

			GridPane leaderboardMenuGrid = new GridPane();
			leaderboardMenuGrid.add(leaderboard, 1, 0);
			leaderboardMenuGrid.setAlignment(Pos.CENTER);
//            leaderboardMenu.getChildren().addAll(leaderboard, btnBack5);

			menu0.getChildren().addAll(btnFreeBattle, btnOptions, btnExit, btnLeaderboard);
			menu1.getChildren().addAll(btnMute, btnDec, btnInc, btnVideo, btnBack);
			menu2.getChildren().addAll(btnCOM, btnOnline, btnBack2);
			menu3.getChildren().addAll(btnTwo, btnTournament, btnBack3);
			menu4.getChildren().addAll(menu4Grid, btnBack4);
			onlineMenu1.getChildren().addAll(roomNumberLabel, roomNumber, btnConnect, btnBack6);
			leaderboardMenu.getChildren().addAll(leaderboardMenuGrid, btnBack5);

			Rectangle background = new Rectangle(800, 600);
			background.setFill(Color.GREY);
			background.setOpacity(0.4);

			getChildren().addAll(background, menu4);

		}
	}

	private static class MenuButton extends StackPane { // our menu button
		private Text text;

		public MenuButton(String name) {
			text = new Text(name);
			text.setFont(text.getFont().font(20)); // can be changed
			text.setFill(Color.WHITE);// originally, text is white
			text.setTranslateX(10);

			Rectangle bg = new Rectangle(250, 30);
			bg.setOpacity(0.6); // to make the button kind of see through
			bg.setFill(Color.BLACK); // arbitrary colour
			bg.setEffect(new GaussianBlur(3.5)); // arbitrary blur

			setAlignment(Pos.CENTER_LEFT);
			setRotate(-0.5);
			getChildren().addAll(bg, text);

			setOnMouseEntered(event -> {
				bg.setTranslateX(10); // moves the rectangles and text by 10 in X
				text.setTranslateX(20);
				bg.setFill(Color.WHITE);
				text.setFill(Color.BLACK);
			}); // This is when we move the mouse around in the menu, changes the colours

			setOnMouseExited(event -> {
				bg.setTranslateX(0); // moves the rectangles and text by 10 in X
				text.setTranslateX(10);
				bg.setFill(Color.BLACK);
				text.setFill(Color.WHITE);
			});

			DropShadow drop = new DropShadow(50, Color.WHITE);
			drop.setInput(new Glow()); // add a shadow

			setOnMousePressed(event -> setEffect(drop));
			setOnMouseReleased(event -> setEffect(null));

		}
	}

	public static void main(String[] args) {
		launch(args);

	}
}
