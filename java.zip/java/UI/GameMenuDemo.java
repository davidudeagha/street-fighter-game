package UI;

import javafx.animation.FadeTransition;
import javafx.animation.TranslateTransition;
import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.effect.DropShadow;
import javafx.scene.effect.GaussianBlur;
import javafx.scene.effect.Glow;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.media.MediaPlayer;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.DecimalFormat;

import RenderEngine.Game;

public class GameMenuDemo extends Application {

	private GameMenu gameMenu;
	MediaPlayer mediaPlayer;
	double volume = 1;
	DecimalFormat df = new DecimalFormat("#.##");
	int sizex = 1920;
	int sizey = 1080;

	@Override
	public void start(Stage primaryStage) throws Exception {

//		String bip = "resources/sounds/Big Mojo.mp3";
//		Media media = new javafx.scene.media.Media(Paths.get(bip).toUri().toString());
//		mediaPlayer = new MediaPlayer(media);
//		mediaPlayer.setVolume(1);
//		mediaPlayer.play();

		Pane root = new Pane();
		root.setPrefSize(sizex, sizey);

		InputStream is = Files.newInputStream(Paths.get("src/main/resources/images/Backgrounds/bg2.jpg"));

		Image img = new Image(is);

		is.close();

		ImageView imgView = new ImageView(img);
		imgView.setFitWidth(sizex);
		imgView.setFitHeight(sizey); // to fit the window

		gameMenu = new GameMenu();
		gameMenu.setVisible(false);

		root.getChildren().addAll(imgView, gameMenu); // display image as an image view

		Scene scene = new Scene(root);
		scene.setOnKeyPressed(event -> {
			if (event.getCode() == KeyCode.ESCAPE) {
				if (!gameMenu.isVisible()) {
					FadeTransition ft = new FadeTransition(Duration.seconds(0.5), gameMenu);
					ft.setFromValue(0);
					ft.setToValue(1);
					gameMenu.setVisible(true);
					ft.play();
				} else {
					FadeTransition ft = new FadeTransition(Duration.seconds(0.5), gameMenu);
					ft.setFromValue(1);
					ft.setToValue(0);
					ft.setOnFinished(evt -> gameMenu.setVisible(false));
					ft.play();
				}
			}
		});

		primaryStage.setScene(scene);
		primaryStage.show();

	} // for the background image

	private class GameMenu extends Parent { // a node that can contain children
		public GameMenu() {
			VBox menu0 = new VBox(15);// 10 is the distance between two elements
			VBox menu1 = new VBox(15);
			VBox menu2 = new VBox(15);
			VBox menu3 = new VBox(15);
			VBox menu4 = new VBox(15);

			menu0.setTranslateX(500);
			menu0.setTranslateY(300);

			menu1.setTranslateX(500);
			menu1.setTranslateY(300);

			menu2.setTranslateX(500);
			menu2.setTranslateY(300);

			menu3.setTranslateX(500);
			menu3.setTranslateY(300);
			
			menu4.setTranslateX(500);
			menu4.setTranslateY(300);

			final int offset = 400;

			menu1.setTranslateX(offset);
			menu2.setTranslateX(offset);
			menu3.setTranslateX(offset);
			menu4.setTranslateX(offset);

			Label lname = new Label("Username : ");
			Label lpassword = new Label("Password : ");
			Label lmessage = new Label();

			TextField tfname = new TextField();
			PasswordField tfpassword = new PasswordField();

			MenuButton btnLogin = new MenuButton("Login");
			btnLogin.setOnMouseClicked(event -> {
				lmessage.setStyle("-fx-text-fill: red;");
				String name = tfname.getText();
				String password = tfpassword.getText();
				if (name.equals("")) {
					lmessage.setText("Please enter your username");
				} else if (password.equals("")) {
					lmessage.setText("Please enter your password");
					/*Introduce another else if clause here with the database,
					 *if not in the database, then the final else clause is called*/
				} else {
					lmessage.setText("Invalid username or password");
				}
			});

			MenuButton btnResume = new MenuButton("Resume");
			btnResume.setOnMouseClicked(event -> {
				FadeTransition ft = new FadeTransition(Duration.seconds(0.5), this); // animation for it
				ft.setFromValue(1);
				ft.setToValue(0);
				ft.setOnFinished(evt -> setVisible(false));
				ft.play();
			}); // just a little animation

			MenuButton btnOptions = new MenuButton("Options");
			btnOptions.setOnMouseClicked(event -> {
				getChildren().add(menu1);

				TranslateTransition tt = new TranslateTransition(Duration.seconds(0.25), menu0);
				tt.setToX(menu0.getTranslateX() - offset);

				TranslateTransition tt1 = new TranslateTransition(Duration.seconds(0.5), menu1);
				tt1.setToX(menu0.getTranslateX());

				tt.play();
				tt1.play();

				tt.setOnFinished(evt -> {
					getChildren().remove(menu0);
				});
			});

			MenuButton btnExit = new MenuButton("Exit");
			btnExit.setOnMouseClicked(event -> {
				System.exit(0);
			});

			MenuButton btnFreeBattle = new MenuButton("Free Battle");
			btnFreeBattle.setOnMouseClicked(event -> {
				getChildren().add(menu2);

				TranslateTransition tt = new TranslateTransition(Duration.seconds(0.25), menu0);
				tt.setToX(menu0.getTranslateX() - offset);

				TranslateTransition tt1 = new TranslateTransition(Duration.seconds(0.5), menu2);
				tt1.setToX(menu0.getTranslateX());

				tt.play();
				tt1.play();

				tt.setOnFinished(evt -> {
					getChildren().remove(menu0);
				});
			});

			MenuButton btnBack = new MenuButton("Back");
			btnBack.setOnMouseClicked(event -> {
				getChildren().add(menu0);

				TranslateTransition tt = new TranslateTransition(Duration.seconds(0.25), menu1);
				tt.setToX(menu1.getTranslateX() + offset);

				TranslateTransition tt1 = new TranslateTransition(Duration.seconds(0.5), menu0);
				tt1.setToX(menu1.getTranslateX());

				tt.play();
				tt1.play();

				tt.setOnFinished(evt -> {
					getChildren().remove(menu1);
				});
			});

			MenuButton btnBack2 = new MenuButton("Back");
			btnBack2.setOnMouseClicked(event -> {
				getChildren().add(menu0);

				TranslateTransition tt = new TranslateTransition(Duration.seconds(0.25), menu2);
				tt.setToX(menu2.getTranslateX() + offset);

				TranslateTransition tt1 = new TranslateTransition(Duration.seconds(0.5), menu0);
				tt1.setToX(menu2.getTranslateX());

				tt.play();
				tt1.play();

				tt.setOnFinished(evt -> {
					getChildren().remove(menu2);
				});
			});

			MenuButton btnInc = new MenuButton("Increase Volume");
			btnInc.setOnMouseClicked(event -> {
				if (volume == 1) {
					mediaPlayer.setVolume(1);
				} else {
					volume = volume + 0.05;
					volume = Double.parseDouble(df.format(volume));
					mediaPlayer.setVolume(volume);
				}
			});

			MenuButton btnDec = new MenuButton("Decrease Volume");
			btnDec.setOnMouseClicked(event -> {
				if (volume == 0) {
					mediaPlayer.setVolume(0);
				} else {
					volume = volume - 0.05;
					volume = Double.parseDouble(df.format(volume));
					mediaPlayer.setVolume(volume);
				}
			});
			
			MenuButton btnMute = new MenuButton("Mute Sounds");
			btnMute.setOnMouseClicked(event -> {
				mediaPlayer.setVolume(0);
			});

			MenuButton btnUnMute = new MenuButton("Unmute Sounds");
			btnUnMute.setOnMouseClicked(event -> {
				mediaPlayer.setVolume(volume);
			});


			MenuButton btnLocal = new MenuButton("Local Multiplayer");
			btnLocal.setOnMouseClicked(event -> {
				getChildren().add(menu3);

				TranslateTransition tt = new TranslateTransition(Duration.seconds(0.25), menu2);
				tt.setToX(menu2.getTranslateX() - offset);

				TranslateTransition tt1 = new TranslateTransition(Duration.seconds(0.5), menu3);
				tt1.setToX(menu2.getTranslateX());

				tt.play();
				tt1.play();

				tt.setOnFinished(evt -> {
					getChildren().remove(menu2);
				});
			});

			MenuButton btnBack3 = new MenuButton("Back");
			btnBack3.setOnMouseClicked(event -> {
				getChildren().add(menu2);

				TranslateTransition tt = new TranslateTransition(Duration.seconds(0.25), menu3);
				tt.setToX(menu3.getTranslateX() + offset);

				TranslateTransition tt1 = new TranslateTransition(Duration.seconds(0.5), menu2);
				tt1.setToX(menu3.getTranslateX());

				tt.play();
				tt1.play();

				tt.setOnFinished(evt -> {
					getChildren().remove(menu3);
				});
			});

			MenuButton btnOnline = new MenuButton("Online Multiplayer");
			btnOnline.setOnMouseClicked(event -> {
				getChildren().add(menu4);

				TranslateTransition tt = new TranslateTransition(Duration.seconds(0.25), menu2);
				tt.setToX(menu2.getTranslateX() - offset);

				TranslateTransition tt1 = new TranslateTransition(Duration.seconds(0.5), menu4);
				tt1.setToX(menu2.getTranslateX());

				tt.play();
				tt1.play();

				tt.setOnFinished(evt -> {
					getChildren().remove(menu2);
				});
			});
			MenuButton btnBack4 = new MenuButton("Back");
			btnBack4.setOnMouseClicked(event -> {
				getChildren().add(menu2);

				TranslateTransition tt = new TranslateTransition(Duration.seconds(0.25), menu4);
				tt.setToX(menu4.getTranslateX() + offset);

				TranslateTransition tt1 = new TranslateTransition(Duration.seconds(0.5), menu2);
				tt1.setToX(menu4.getTranslateX());

				tt.play();
				tt1.play();

				tt.setOnFinished(evt -> {
					getChildren().remove(menu4);
				});
			});
			MenuButton btnCOM = new MenuButton("COM VS Battle");

			MenuButton btnTwo = new MenuButton("Two Player");
			MenuButton btnTournament = new MenuButton("Tournament Mode");

			GridPane grid = new GridPane();
			grid.addRow(0, lname, tfname);
			grid.addRow(1, lpassword, tfpassword);
			grid.add(btnLogin, 2, 0, 1, 2);
			grid.add(lmessage, 0, 2, 3, 1);
			grid.setAlignment(Pos.CENTER);

			menu0.getChildren().addAll(btnResume, btnFreeBattle, btnOptions, btnExit);
			menu1.getChildren().addAll(btnMute, btnUnMute, btnDec, btnInc, btnBack);
			menu2.getChildren().addAll(btnCOM, btnLocal, btnOnline, btnBack2);
			menu3.getChildren().addAll(btnTwo, btnTournament, btnBack3);
			menu4.getChildren().addAll(grid, btnBack4);

			Rectangle background = new Rectangle(sizex, sizey);
			background.setFill(Color.GREY);
			background.setOpacity(0.4);

			getChildren().addAll(background, menu0);
		}
	}

	private static class MenuButton extends StackPane { // our menu button
		private Text text;

		public MenuButton(String name) {
			text = new Text(name);
			text.getFont();
			text.setFont(Font.font(20)); // can be changed
			text.setFill(Color.WHITE);// originally, text is white
			text.setTranslateX(10);

			Rectangle bg = new Rectangle(250, 30);
			bg.setOpacity(0.6); // to make the button kind of see through
			bg.setFill(Color.BLACK); // arbitrary colour
			bg.setEffect(new GaussianBlur(3.5)); // arbitrary blur

			setAlignment(Pos.CENTER_LEFT);
			setRotate(-0.5);
			getChildren().addAll(bg, text);

			setOnMouseEntered(event -> {
				bg.setTranslateX(10); // moves the rectangles and text by 10 in X
				text.setTranslateX(20);
				bg.setFill(Color.WHITE);
				text.setFill(Color.BLACK);
			}); // This is when we move the mouse around in the menu, changes the colours

			setOnMouseExited(event -> {
				bg.setTranslateX(0); // moves the rectangles and text by 10 in X
				text.setTranslateX(10);
				bg.setFill(Color.BLACK);
				text.setFill(Color.WHITE);
			});

			DropShadow drop = new DropShadow(50, Color.WHITE);
			drop.setInput(new Glow()); // add a shadow

			setOnMousePressed(event -> setEffect(drop));
			setOnMouseReleased(event -> setEffect(null));

		}
	}

	public static void main(String[] args) {
		launch(args);
	}
}
