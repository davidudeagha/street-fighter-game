public class TestParticle {
	final static double GRAVITY = 9.81;
	final static double TIME_PASS = 0.25;
	final static double TIME_PASS_SQ = TIME_PASS * TIME_PASS;

	private Vector pos;
	private Vector vel;

	public TestParticle(Vector pos, Vector vel) {
		this.pos = pos;
		this.vel = vel;
	}

	public void jump(boolean start) {
		this.vel.setYComp(30);
		this.jump();
	}

	public void jump() {
		double r_x = this.pos.getXComp();
		double r_y = this.pos.getYComp();
		double v_x = this.vel.getXComp();
		double v_y = this.vel.getYComp();

		r_x += (v_x * TIME_PASS);

		r_y += (v_y * TIME_PASS) - ((GRAVITY * TIME_PASS_SQ) / 2);
		v_y -= (GRAVITY * TIME_PASS);

		if (r_y <= 0.0) {
			r_y = 0.0;
			v_y = 0.0;
			v_x = 0.0;
		}

		pos.setXComp(r_x);
		pos.setYComp(r_y);
		vel.setXComp(v_x);
		vel.setYComp(v_y);
	}

	public String toString() {
		String status = "r" + this.pos + ", v" + this.vel;
		return status;
	}

	public static void main(String[] args) {
		TestParticle test = new TestParticle(new Vector(0, 0), new Vector(0, 0));
		System.out.println(test);

	}
}