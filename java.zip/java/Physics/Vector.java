public class Vector {
	private double x;
	private double y;

	public Vector(double x, double y) {
		this.x = x;
		this.y = y;
	}

	public void setXComp(double x) {
		this.x = x;
	}

	public void setYComp(double y) {
		this.y = y;
	}

	public double getXComp() {
		return this.x;
	}

	public double getYComp() {
		return this.y;
	}

	public String toString() {
		return "(" + getXComp() + ", " + getYComp() + ")";
	}
}