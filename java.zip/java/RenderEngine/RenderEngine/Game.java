package RenderEngine;
import Level.Level;
import Level.PlayerHealthBar;
import javafx.animation.AnimationTimer;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Label;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

/**
 * Class that renders the Level, health bars and takes keyboard input
 */
public class Game extends Application {
    public static final int WIDTH = 960; /** Use WIDTH and SCALE to scale up the window. */
    public static final int HEIGHT = 540; //16:9 aspect ratio.
    public static final int SCALE = 1; //Use WIDTH and SCALE to scale up the window.

    private Pane root = new Pane();
    private Level level;
    public Scene scene;

    private boolean running;
    PlayerHealthBar player1HealthBar = new PlayerHealthBar();
    PlayerHealthBar player2HealthBar = new PlayerHealthBar();

    /**
     * Stars the game and begins rendering
     * @param stage stage to render all objects to
     */
    @Override
    public void start(Stage stage) {
        scene = new Scene(root);
        stage.setTitle("STICKFIGHTER");
        Canvas canvas = new Canvas(WIDTH * SCALE, HEIGHT * SCALE);
        GraphicsContext g = canvas.getGraphicsContext2D();
        stage.setScene(scene);
        stage.setResizable(false);
//        level = new HumanVSHumanLevel();
//        level = new AIVSAILevel();
//        level = new HumanVSAILevel();
//		level = new TestLevel();
        player2HealthBar.relocate(720, player2HealthBar.getY());
        player2HealthBar.setValue(1);
//        player2HealthBar.setValue(100);

        player1HealthBar.setValue(1);
        root.getChildren().add(canvas);
        root.getChildren().add(player1HealthBar);
        root.getChildren().add(player2HealthBar);
//		stage.setResizable(true);
        scene.setOnKeyPressed(this::keyPressed);
        scene.setOnKeyReleased(this::keyReleased);
        scene.setOnMouseClicked(this::printMouseCoords);
        AnimationTimer timer = new AnimationTimer() {

            @Override
            public void handle(long now) {
                update();
                g.clearRect(0, 0, WIDTH, HEIGHT);
                render(g);
                if (!level.isRunning()) {
                    System.err.println("Game Over");
                    if(level.getWinner()==1) {
                        Label youWin = new Label("YOU WIN!");
                        Label scoreLabel = new Label("You scored: " + level.getPlayerScore());
                        root.getChildren().clear();
                        root.getChildren().addAll(youWin, scoreLabel);
//                        System.exit(0);
                    }else{
                        Label youWin = new Label("YOU Lose!");
                        Label scoreLabel = new Label("You scored: " + level.getPlayerScore());
                        root.getChildren().clear();
                        root.getChildren().addAll(youWin, scoreLabel);
//                        System.exit(0);
                    }
                }
            }
        };

        timer.start();
        running = true;

        stage.show();
    }

    /**
     * for debugging player positions
     * @param mouseEvent mouse clicked event
     */
    private void printMouseCoords(MouseEvent mouseEvent) {
        System.out.println("X: " + mouseEvent.getX() + " Y: " + mouseEvent.getY());
    }

    /**
     * updates display by parsing player moves and updating level (and by extension all player objects)
     */
    private void update() {
        level.parseMoves(player1HealthBar,player2HealthBar);
        level.update();
    }

    /**
     * renders all objects to the screen
     * @param g
     */
    private void render(GraphicsContext g) {
        level.render(g);
    }

    private void keyPressed(KeyEvent e) {
        level.keyPressed(e.getCode().toString());
    }

    private void keyReleased(KeyEvent e) {
        level.keyReleased(e.getCode().toString());
    }

//    public static void main(String[] args) {
//        launch(args);
//    }

    /**
     * Constructor for game allows for generalisation of levels (game types)
     * @param level Level object specifying which type of game is to be rendered (Human vs AI etc.)
     */
    public Game(Level level){
        this.level = level;
//        launch();
        start(new Stage());
    }
}