package RenderEngine;
//
//import TestLevel.TestLevel;
//
//import javax.swing.*;
//import java.awt.*;
//import java.awt.image.BufferStrategy;
//import java.awt.image.BufferedImage;
//
//public class GameImp extends Canvas implements Runnable{
//    private static final long serialVersionUID = 1L;
//
//    public static final int WIDTH = 320; //Use WIDTH and SCALE to scale up the window.
//    public static final int HEIGHT = WIDTH / 16 * 9; //16:9 aspect ratio.
//    public static final int SCALE = 3; //Use WIDTH and SCALE to scale up the window.
//    public static final String GAMENAME = "STICKFIGHTER"; //Current working title
//
//    private JFrame frame;
//
//    private TestLevel level;
//
//    public boolean running = false;
//    public int updateCount = 0;
//
//    private BufferedImage image = new BufferedImage(WIDTH, HEIGHT, BufferedImage.TYPE_INT_RGB);
//    Graphics2D g = (Graphics2D) image.getGraphics();
//
//    public GameImp() {
//        setPreferredSize(new Dimension((WIDTH * SCALE), (HEIGHT * SCALE)));
//        setMaximumSize(new Dimension((WIDTH * SCALE), (HEIGHT * SCALE)));
//        setMinimumSize(new Dimension((WIDTH * SCALE), (HEIGHT * SCALE)));
//
//        frame = new JFrame(GAMENAME);
//        frame.setLayout(new BorderLayout());
//        frame.add(this, BorderLayout.CENTER);
//        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//        frame.pack();
//        frame.setResizable(false);
//        frame.setLocationRelativeTo(null);
//        frame.setVisible(true);
//        frame.setFocusable(true);
//        frame.requestFocus();
////        frame.addKeyListener(this);
//    }
//
//    private void init() {
//        running = true;
//        level = new TestLevel();
//    }
//
//    @Override
//    public void run() {
//        init();
//        long beforeTime = System.nanoTime();
//        double timePerUpdate = 1000000000D/60D; // Maintains a constant 60 FPS (60 updates a second)
//
//        int updates = 0;
//        int frames = 0;
//
//        long beforeTimeCheck = System.currentTimeMillis();
//        double difference = 0;
//
//
//        while (running) {
//            long afterTime = System.nanoTime();
//            difference += (afterTime - beforeTime) / timePerUpdate;
//            beforeTime = afterTime;
//            boolean shouldRender = false;
//
//            while (difference >= 1) {
//                updates++;
//                update();
//                difference -= 1;
//                shouldRender = true;
//            }
//
//            try {
//                Thread.sleep(2);
//            }
//            catch (InterruptedException e) {
//                e.printStackTrace();
//            }
//
//            if (shouldRender) {
//                frames++;
//                render();
//                renderImage();
//            }
//
//            if ((System.currentTimeMillis() - beforeTimeCheck) > 1000) {
//                beforeTimeCheck += 1000;
//                System.out.println("FRAMES: " + frames + ", UPDATES: " + updates);
//                frames = 0;
//                updates = 0;
//            }
//        }
//    }
//
//    public void update() {
//        level.update();
//    }
//
//    public void render() {
//        level.render(g);
//    }
//
//    public void renderImage() {
//        BufferStrategy bs = getBufferStrategy();
//        if (bs == null) {
//            createBufferStrategy(3); //Triple buffering to fix flickering issue.
//            return;
//        }
//
//        Graphics g2 = bs.getDrawGraphics();
//        g2.fillRect(0, 0, getWidth(), getHeight());
//        g2.drawImage(image, 0, 0, getWidth(), getHeight(), null);
//        g2.dispose(); //Frees up memory, when image is no longer in use.
////        bs.show();
//    }
//}
