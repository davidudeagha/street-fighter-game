package RenderEngine;

import javafx.scene.image.Image;

public class Animation {
	
	private Image[] frameArray;
	
	private int currentFrame;
	
	private long startTime;
	private long delay;
	private int animationID=-1;
	private boolean looped;

	public boolean isIdle() {
		return idle;
	}

	public void setIdle(boolean idle) {
		this.idle = idle;
	}

	private boolean idle = false;
	public Animation() {
		looped = false;
	}

    public int getAnimationID() {
        return animationID;
    }

    public Animation(int id){
	    looped = false;
	    this.animationID = id;
    }
	
	public void importFrames(Image[] frameArr) {
		frameArray = frameArr;
		currentFrame = 1;
		startTime = System.nanoTime();
		looped = false;
	}
	
	public void setDelay(long val) { 
		delay = val;
	}
	
	public void setFrame(int i) { 
		currentFrame = i;
	}
	
	public void update() {
		
		long timeTaken = (System.nanoTime() - startTime) / 1000000;
		
		if (timeTaken > delay) {
			currentFrame++;
			startTime = System.nanoTime();
		}
		
		if (currentFrame == frameArray.length) {
			currentFrame = 1;
			looped = true;
		}

	}
	
	public int getFrame() { 
		return currentFrame; 
	}
	
	public Image getImage() { 
		return frameArray[currentFrame]; 
	}
	
	public boolean hasPlayedOnce() { 
		return looped; 
	}
}