package Animations.RegularCharacter;

import java.io.IOException;
import java.nio.file.Paths;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import javafx.util.Duration;

/* Testing an animation method*/
public class StartCrouchBlock extends Application {

	final static javafx.scene.image.Image STARTCROUCHBLOCK_1 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/StartCrouchBlock/1.png").toUri().toString());
	final static javafx.scene.image.Image STARTCROUCHBLOCK_2 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/StartCrouchBlock/2.png").toUri().toString());
	final static javafx.scene.image.Image STARTCROUCHBLOCK_3 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/StartCrouchBlock/3.png").toUri().toString());
	final static javafx.scene.image.Image STARTCROUCHBLOCK_4 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/StartCrouchBlock/4.png").toUri().toString());
	final static javafx.scene.image.Image STARTCROUCHBLOCK_5= new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/StartCrouchBlock/5.png").toUri().toString());
	final static javafx.scene.image.Image STARTCROUCHBLOCK_6 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/StartCrouchBlock/6.png").toUri().toString());
	
	private Group startcrouchblock;

	@Override
	public void start(Stage primaryStage) throws IOException {
		final ImageView startcrouchblock1 = new ImageView(STARTCROUCHBLOCK_1);
		final ImageView startcrouchblock2 = new ImageView(STARTCROUCHBLOCK_2);
		final ImageView startcrouchblock3 = new ImageView(STARTCROUCHBLOCK_3);
		final ImageView startcrouchblock4 = new ImageView(STARTCROUCHBLOCK_4);
		final ImageView startcrouchblock5 = new ImageView(STARTCROUCHBLOCK_5);
		final ImageView startcrouchblock6 = new ImageView(STARTCROUCHBLOCK_6);

		startcrouchblock = new Group(startcrouchblock1);

		startcrouchblock.setTranslateX(0);
		startcrouchblock.setTranslateY(0);

		Timeline t = new Timeline();
		t.setCycleCount(Timeline.INDEFINITE);

		t.getKeyFrames().add(new KeyFrame(Duration.millis(100), (ActionEvent event) -> {
			startcrouchblock.getChildren().setAll(startcrouchblock2);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(200), (ActionEvent event) -> {
			startcrouchblock.getChildren().setAll(startcrouchblock3);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(300), (ActionEvent event) -> {
			startcrouchblock.getChildren().setAll(startcrouchblock4);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(400), (ActionEvent event) -> {
			startcrouchblock.getChildren().setAll(startcrouchblock5);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(500), (ActionEvent event) -> {
			startcrouchblock.getChildren().setAll(startcrouchblock6);
		}));
		t.play();

		primaryStage.setScene(new Scene(startcrouchblock, 1000, 800));
		primaryStage.setTitle("Start Crouch Block");
		primaryStage.show();
	}

	public static void main(String[] args) {
		launch(args);
	}
}