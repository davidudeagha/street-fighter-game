package Animations.RegularCharacter;

import java.io.IOException;
import java.nio.file.Paths;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import javafx.util.Duration;

/* Testing an animation method*/
public class EndCrouchBlock extends Application {

	final static javafx.scene.image.Image ENDCROUCHBLOCK_1 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/EndCrouchBlock/1.png").toUri().toString());
	final static javafx.scene.image.Image ENDCROUCHBLOCK_2 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/EndCrouchBlock/2.png").toUri().toString());
	final static javafx.scene.image.Image ENDCROUCHBLOCK_3 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/EndCrouchBlock/3.png").toUri().toString());
	final static javafx.scene.image.Image ENDCROUCHBLOCK_4 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/EndCrouchBlock/4.png").toUri().toString());
	final static javafx.scene.image.Image ENDCROUCHBLOCK_5= new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/EndCrouchBlock/5.png").toUri().toString());
	final static javafx.scene.image.Image ENDCROUCHBLOCK_6 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/EndCrouchBlock/6.png").toUri().toString());
	
	private Group endcrouchblock;

	@Override
	public void start(Stage primaryStage) throws IOException {
		final ImageView endcrouchblock1 = new ImageView(ENDCROUCHBLOCK_1);
		final ImageView endcrouchblock2 = new ImageView(ENDCROUCHBLOCK_2);
		final ImageView endcrouchblock3 = new ImageView(ENDCROUCHBLOCK_3);
		final ImageView endcrouchblock4 = new ImageView(ENDCROUCHBLOCK_4);
		final ImageView endcrouchblock5 = new ImageView(ENDCROUCHBLOCK_5);
		final ImageView endcrouchblock6 = new ImageView(ENDCROUCHBLOCK_6);

		endcrouchblock = new Group(endcrouchblock1);

		endcrouchblock.setTranslateX(0);
		endcrouchblock.setTranslateY(0);

		Timeline t = new Timeline();
		t.setCycleCount(Timeline.INDEFINITE);

		t.getKeyFrames().add(new KeyFrame(Duration.millis(100), (ActionEvent event) -> {
			endcrouchblock.getChildren().setAll(endcrouchblock2);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(150), (ActionEvent event) -> {
			endcrouchblock.getChildren().setAll(endcrouchblock3);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(200), (ActionEvent event) -> {
			endcrouchblock.getChildren().setAll(endcrouchblock4);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(250), (ActionEvent event) -> {
			endcrouchblock.getChildren().setAll(endcrouchblock5);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(300), (ActionEvent event) -> {
			endcrouchblock.getChildren().setAll(endcrouchblock6);
		}));
		t.play();

		primaryStage.setScene(new Scene(endcrouchblock, 1000, 800));
		primaryStage.setTitle("End Crouch Block");
		primaryStage.show();
	}

	public static void main(String[] args) {
		launch(args);
	}
}