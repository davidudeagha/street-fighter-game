package Animations.RegularCharacter;

import java.io.IOException;
import java.nio.file.Paths;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import javafx.util.Duration;

/* Testing an animation method*/
public class HighPunch extends Application {

	final static javafx.scene.image.Image HIGHPUNCH_1 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/HighPunch/1.png").toUri().toString());
	final static javafx.scene.image.Image HIGHPUNCH_2 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/HighPunch/2.png").toUri().toString());
	final static javafx.scene.image.Image HIGHPUNCH_3 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/HighPunch/3.png").toUri().toString());
	final static javafx.scene.image.Image HIGHPUNCH_4 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/HighPunch/4.png").toUri().toString());
	final static javafx.scene.image.Image HIGHPUNCH_5= new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/HighPunch/5.png").toUri().toString());
	final static javafx.scene.image.Image HIGHPUNCH_6 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/HighPunch/6.png").toUri().toString());
	final static javafx.scene.image.Image HIGHPUNCH_7 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/HighPunch/7.png").toUri().toString());
	final static javafx.scene.image.Image HIGHPUNCH_8 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/HighPunch/8.png").toUri().toString());
	final static javafx.scene.image.Image HIGHPUNCH_9 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/HighPunch/9.png").toUri().toString());
	final static javafx.scene.image.Image HIGHPUNCH_10 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/HighPunch/10.png").toUri().toString());
	final static javafx.scene.image.Image HIGHPUNCH_11 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/HighPunch/11.png").toUri().toString());
	final static javafx.scene.image.Image HIGHPUNCH_12 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/HighPunch/12.png").toUri().toString());
	final static javafx.scene.image.Image HIGHPUNCH_13 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/HighPunch/13.png").toUri().toString());
	final static javafx.scene.image.Image HIGHPUNCH_14 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/HighPunch/14.png").toUri().toString());
	final static javafx.scene.image.Image HIGHPUNCH_15 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/HighPunch/15.png").toUri().toString());

	private Group punch;

	@Override
	public void start(Stage primaryStage) throws IOException {
		final ImageView punch1 = new ImageView(HIGHPUNCH_1);
		final ImageView punch2 = new ImageView(HIGHPUNCH_2);
		final ImageView punch3 = new ImageView(HIGHPUNCH_3);
		final ImageView punch4 = new ImageView(HIGHPUNCH_4);
		final ImageView punch5 = new ImageView(HIGHPUNCH_5);
		final ImageView punch6 = new ImageView(HIGHPUNCH_6);
		final ImageView punch7 = new ImageView(HIGHPUNCH_7);
		final ImageView punch8 = new ImageView(HIGHPUNCH_8);
		final ImageView punch9 = new ImageView(HIGHPUNCH_9);
		final ImageView punch10 = new ImageView(HIGHPUNCH_10);
		final ImageView punch11 = new ImageView(HIGHPUNCH_11);
		final ImageView punch12 = new ImageView(HIGHPUNCH_12);
		final ImageView punch13 = new ImageView(HIGHPUNCH_13);
		final ImageView punch14 = new ImageView(HIGHPUNCH_14);
		final ImageView punch15 = new ImageView(HIGHPUNCH_15);

		punch = new Group(punch1);

		punch.setTranslateX(0);
		punch.setTranslateY(0);

		Timeline t = new Timeline();
		t.setCycleCount(Timeline.INDEFINITE);

		t.getKeyFrames().add(new KeyFrame(Duration.millis(100), (ActionEvent event) -> {
			punch.getChildren().setAll(punch2);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(150), (ActionEvent event) -> {
			punch.getChildren().setAll(punch3);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(200), (ActionEvent event) -> {
			punch.getChildren().setAll(punch4);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(250), (ActionEvent event) -> {
			punch.getChildren().setAll(punch5);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(300), (ActionEvent event) -> {
			punch.getChildren().setAll(punch6);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(350), (ActionEvent event) -> {
			punch.getChildren().setAll(punch7);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(400), (ActionEvent event) -> {
			punch.getChildren().setAll(punch8);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(450), (ActionEvent event) -> {
			punch.getChildren().setAll(punch9);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(500), (ActionEvent event) -> {
			punch.getChildren().setAll(punch10);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(550), (ActionEvent event) -> {
			punch.getChildren().setAll(punch11);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(600), (ActionEvent event) -> {
			punch.getChildren().setAll(punch12);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(650), (ActionEvent event) -> {
			punch.getChildren().setAll(punch13);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(700), (ActionEvent event) -> {
			punch.getChildren().setAll(punch14);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(750), (ActionEvent event) -> {
			punch.getChildren().setAll(punch15);
		}));
		t.play();

		primaryStage.setScene(new Scene(punch, 1000, 800));
		primaryStage.setTitle("High Punch");
		primaryStage.show();
	}

	public static void main(String[] args) {
		launch(args);
	}
}