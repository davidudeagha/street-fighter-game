package Animations.RegularCharacter;

import java.io.IOException;
import java.nio.file.Paths;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import javafx.util.Duration;

/* Testing an animation method*/
public class StartBlocking extends Application {

	final static javafx.scene.image.Image STARTBLOCK_1 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/StartBlock/1.png").toUri().toString());
	final static javafx.scene.image.Image STARTBLOCK_2 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/StartBlock/2.png").toUri().toString());
	final static javafx.scene.image.Image STARTBLOCK_3 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/StartBlock/3.png").toUri().toString());
	final static javafx.scene.image.Image STARTBLOCK_4 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/StartBlock/4.png").toUri().toString());
	final static javafx.scene.image.Image STARTBLOCK_5= new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/StartBlock/5.png").toUri().toString());
	final static javafx.scene.image.Image STARTBLOCK_6 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/StartBlock/6.png").toUri().toString());
	final static javafx.scene.image.Image STARTBLOCK_7 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/StartBlock/7.png").toUri().toString());
	
	private Group startblock;

	@Override
	public void start(Stage primaryStage) throws IOException {
		final ImageView startblock1 = new ImageView(STARTBLOCK_1);
		final ImageView startblock2 = new ImageView(STARTBLOCK_2);
		final ImageView startblock3 = new ImageView(STARTBLOCK_3);
		final ImageView startblock4 = new ImageView(STARTBLOCK_4);
		final ImageView startblock5 = new ImageView(STARTBLOCK_5);
		final ImageView startblock6 = new ImageView(STARTBLOCK_6);
		final ImageView startblock7 = new ImageView(STARTBLOCK_7);

		startblock = new Group(startblock1);

		startblock.setTranslateX(0);
		startblock.setTranslateY(0);

		Timeline t = new Timeline();
		t.setCycleCount(Timeline.INDEFINITE);

		t.getKeyFrames().add(new KeyFrame(Duration.millis(100), (ActionEvent event) -> {
			startblock.getChildren().setAll(startblock2);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(200), (ActionEvent event) -> {
			startblock.getChildren().setAll(startblock3);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(300), (ActionEvent event) -> {
			startblock.getChildren().setAll(startblock4);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(400), (ActionEvent event) -> {
			startblock.getChildren().setAll(startblock5);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(500), (ActionEvent event) -> {
			startblock.getChildren().setAll(startblock6);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(600), (ActionEvent event) -> {
			startblock.getChildren().setAll(startblock7);
		}));
		t.play();

		primaryStage.setScene(new Scene(startblock, 1000, 800));
		primaryStage.setTitle("Start Block");
		primaryStage.show();
	}

	public static void main(String[] args) {
		launch(args);
	}
}