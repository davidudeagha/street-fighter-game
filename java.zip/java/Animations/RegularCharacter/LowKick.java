package Animations.RegularCharacter;

import java.io.IOException;
import java.nio.file.Paths;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import javafx.util.Duration;

public class LowKick extends Application {

	final static javafx.scene.image.Image LOWKICK_1 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/LowKick/1.png").toUri().toString());
	final static javafx.scene.image.Image LOWKICK_2 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/LowKick/2.png").toUri().toString());
	final static javafx.scene.image.Image LOWKICK_3 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/LowKick/3.png").toUri().toString());
	final static javafx.scene.image.Image LOWKICK_4 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/LowKick/4.png").toUri().toString());
	final static javafx.scene.image.Image LOWKICK_5 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/LowKick/5.png").toUri().toString());
	final static javafx.scene.image.Image LOWKICK_6 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/LowKick/6.png").toUri().toString());
	final static javafx.scene.image.Image LOWKICK_7 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/LowKick/7.png").toUri().toString());
	final static javafx.scene.image.Image LOWKICK_8 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/LowKick/8.png").toUri().toString());
	final static javafx.scene.image.Image LOWKICK_9 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/LowKick/9.png").toUri().toString());
	final static javafx.scene.image.Image LOWKICK_10 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/LowKick/10.png").toUri().toString());
	final static javafx.scene.image.Image LOWKICK_11 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/LowKick/11.png").toUri().toString());
	final static javafx.scene.image.Image LOWKICK_12 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/LowKick/12.png").toUri().toString());
	final static javafx.scene.image.Image LOWKICK_13 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/LowKick/13.png").toUri().toString());
	final static javafx.scene.image.Image LOWKICK_14 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/LowKick/14.png").toUri().toString());

	private Group lowkick;

	@Override
	public void start(Stage primaryStage) throws IOException {
		final ImageView lowkick1 = new ImageView(LOWKICK_1);
		final ImageView lowkick2 = new ImageView(LOWKICK_2);
		final ImageView lowkick3 = new ImageView(LOWKICK_3);
		final ImageView lowkick4 = new ImageView(LOWKICK_4);
		final ImageView lowkick5 = new ImageView(LOWKICK_5);
		final ImageView lowkick6 = new ImageView(LOWKICK_6);
		final ImageView lowkick7 = new ImageView(LOWKICK_7);
		final ImageView lowkick8 = new ImageView(LOWKICK_8);
		final ImageView lowkick9 = new ImageView(LOWKICK_9);
		final ImageView lowkick10 = new ImageView(LOWKICK_10);
		final ImageView lowkick11 = new ImageView(LOWKICK_11);
		final ImageView lowkick12 = new ImageView(LOWKICK_12);
		final ImageView lowkick13 = new ImageView(LOWKICK_13);
		final ImageView lowkick14 = new ImageView(LOWKICK_14);

		lowkick = new Group(lowkick1);

		lowkick.setTranslateX(0);
		lowkick.setTranslateY(0);

		Timeline t = new Timeline();
		t.setCycleCount(Timeline.INDEFINITE);

		t.getKeyFrames().add(new KeyFrame(Duration.millis(100), (ActionEvent event) -> {
			lowkick.getChildren().setAll(lowkick2);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(130), (ActionEvent event) -> {
			lowkick.getChildren().setAll(lowkick3);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(160), (ActionEvent event) -> {
			lowkick.getChildren().setAll(lowkick4);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(190), (ActionEvent event) -> {
			lowkick.getChildren().setAll(lowkick5);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(210), (ActionEvent event) -> {
			lowkick.getChildren().setAll(lowkick6);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(240), (ActionEvent event) -> {
			lowkick.getChildren().setAll(lowkick7);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(270), (ActionEvent event) -> {
			lowkick.getChildren().setAll(lowkick8);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(300), (ActionEvent event) -> {
			lowkick.getChildren().setAll(lowkick9);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(330), (ActionEvent event) -> {
			lowkick.getChildren().setAll(lowkick10);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(360), (ActionEvent event) -> {
			lowkick.getChildren().setAll(lowkick11);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(390), (ActionEvent event) -> {
			lowkick.getChildren().setAll(lowkick12);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(310), (ActionEvent event) -> {
			lowkick.getChildren().setAll(lowkick13);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(340), (ActionEvent event) -> {
			lowkick.getChildren().setAll(lowkick14);
		}));
		t.play();

		primaryStage.setScene(new Scene(lowkick, 1000, 800));
		primaryStage.setTitle("Low Kick");
		primaryStage.show();
	}

	public static void main(String[] args) {
		launch(args);
	}
}