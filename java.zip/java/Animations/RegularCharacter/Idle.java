package Animations.RegularCharacter;

import java.io.IOException;
import java.nio.file.Paths;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import javafx.util.Duration;

public class Idle extends Application {

	final static javafx.scene.image.Image IDLE_1 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/Idle/1.png").toUri().toString());
	final static javafx.scene.image.Image IDLE_2 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/Idle/2.png").toUri().toString());
	final static javafx.scene.image.Image IDLE_3 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/Idle/3.png").toUri().toString());
	final static javafx.scene.image.Image IDLE_4 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/Idle/4.png").toUri().toString());
	final static javafx.scene.image.Image IDLE_5 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/Idle/5.png").toUri().toString());
	final static javafx.scene.image.Image IDLE_6 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/Idle/6.png").toUri().toString());
	final static javafx.scene.image.Image IDLE_7 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/Idle/7.png").toUri().toString());
	final static javafx.scene.image.Image IDLE_8 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/Idle/8.png").toUri().toString());
	final static javafx.scene.image.Image IDLE_9 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/Idle/9.png").toUri().toString());
	final static javafx.scene.image.Image IDLE_10 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/Idle/10.png").toUri().toString());
	final static javafx.scene.image.Image IDLE_11 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/Idle/11.png").toUri().toString());

	private Group idle;

	@Override
	public void start(Stage primaryStage) throws IOException {
		final ImageView idle1 = new ImageView(IDLE_1);
		final ImageView idle2 = new ImageView(IDLE_2);
		final ImageView idle3 = new ImageView(IDLE_3);
		final ImageView idle4 = new ImageView(IDLE_4);
		final ImageView idle5 = new ImageView(IDLE_5);
		final ImageView idle6 = new ImageView(IDLE_6);
		final ImageView idle7 = new ImageView(IDLE_7);
		final ImageView idle8 = new ImageView(IDLE_8);
		final ImageView idle9 = new ImageView(IDLE_9);
		final ImageView idle10 = new ImageView(IDLE_10);
		final ImageView idle11 = new ImageView(IDLE_11);
		idle = new Group(idle1);

		idle.setTranslateX(0);
		idle.setTranslateY(0);

		Timeline t = new Timeline();
		t.setCycleCount(Timeline.INDEFINITE);

		t.getKeyFrames().add(new KeyFrame(Duration.millis(100), (ActionEvent event) -> {
			idle.getChildren().setAll(idle2);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(150), (ActionEvent event) -> {
			idle.getChildren().setAll(idle3);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(200), (ActionEvent event) -> {
			idle.getChildren().setAll(idle4);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(250), (ActionEvent event) -> {
			idle.getChildren().setAll(idle5);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(300), (ActionEvent event) -> {
			idle.getChildren().setAll(idle6);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(350), (ActionEvent event) -> {
			idle.getChildren().setAll(idle7);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(400), (ActionEvent event) -> {
			idle.getChildren().setAll(idle8);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(450), (ActionEvent event) -> {
			idle.getChildren().setAll(idle9);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(500), (ActionEvent event) -> {
			idle.getChildren().setAll(idle10);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(550), (ActionEvent event) -> {
			idle.getChildren().setAll(idle11);
		}));
		t.play();

		primaryStage.setScene(new Scene(idle, 1000, 800));
		primaryStage.setTitle("Idle");
		primaryStage.show();
	}

	public static void main(String[] args) {
		launch(args);
	}
}