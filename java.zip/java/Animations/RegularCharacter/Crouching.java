package Animations.RegularCharacter;

import java.io.IOException;
import java.nio.file.Paths;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import javafx.util.Duration;

public class Crouching extends Application {

	final static javafx.scene.image.Image CROUCHING_1 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/Crouching/1.png").toUri().toString());
	final static javafx.scene.image.Image CROUCHING_2 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/Crouching/2.png").toUri().toString());
	final static javafx.scene.image.Image CROUCHING_3 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/Crouching/3.png").toUri().toString());
	final static javafx.scene.image.Image CROUCHING_4 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/Crouching/4.png").toUri().toString());
	final static javafx.scene.image.Image CROUCHING_5 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/Crouching/5.png").toUri().toString());
	final static javafx.scene.image.Image CROUCHING_6 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/Crouching/6.png").toUri().toString());
	final static javafx.scene.image.Image CROUCHING_7 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/Crouching/7.png").toUri().toString());
	final static javafx.scene.image.Image CROUCHING_8 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/Crouching/8.png").toUri().toString());
	final static javafx.scene.image.Image CROUCHING_9 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/Crouching/9.png").toUri().toString());
	final static javafx.scene.image.Image CROUCHING_10 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/Crouching/10.png").toUri().toString());

	private Group crouching;

	@Override
	public void start(Stage primaryStage) throws IOException {
		final ImageView crouching1 = new ImageView(CROUCHING_1);
		final ImageView crouching2 = new ImageView(CROUCHING_2);
		final ImageView crouching3 = new ImageView(CROUCHING_3);
		final ImageView crouching4 = new ImageView(CROUCHING_4);
		final ImageView crouching5 = new ImageView(CROUCHING_5);
		final ImageView crouching6 = new ImageView(CROUCHING_6);
		final ImageView crouching7 = new ImageView(CROUCHING_7);
		final ImageView crouching8 = new ImageView(CROUCHING_8);
		final ImageView crouching9 = new ImageView(CROUCHING_9);
		final ImageView crouching10 = new ImageView(CROUCHING_10);
		crouching = new Group(crouching1);

		crouching.setTranslateX(0);
		crouching.setTranslateY(0);

		Timeline t = new Timeline();
		t.setCycleCount(Timeline.INDEFINITE);

		t.getKeyFrames().add(new KeyFrame(Duration.millis(100), (ActionEvent event) -> {
			crouching.getChildren().setAll(crouching2);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(140), (ActionEvent event) -> {
			crouching.getChildren().setAll(crouching3);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(180), (ActionEvent event) -> {
			crouching.getChildren().setAll(crouching4);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(220), (ActionEvent event) -> {
			crouching.getChildren().setAll(crouching5);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(260), (ActionEvent event) -> {
			crouching.getChildren().setAll(crouching6);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(300), (ActionEvent event) -> {
			crouching.getChildren().setAll(crouching7);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(340), (ActionEvent event) -> {
			crouching.getChildren().setAll(crouching8);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(380), (ActionEvent event) -> {
			crouching.getChildren().setAll(crouching9);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(420), (ActionEvent event) -> {
			crouching.getChildren().setAll(crouching10);
		}));
		t.play();

		primaryStage.setScene(new Scene(crouching, 1000, 800));
		primaryStage.setTitle("Crouching");
		primaryStage.show();
	}

	public static void main(String[] args) {
		launch(args);
	}
}