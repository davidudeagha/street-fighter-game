package Animations.RegularCharacter;

import java.io.IOException;
import java.nio.file.Paths;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import javafx.util.Duration;

/* Testing an animation method*/
public class EndBlocking extends Application {

	final static javafx.scene.image.Image ENDBLOCK_1 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/EndBlock/1.png").toUri().toString());
	final static javafx.scene.image.Image ENDBLOCK_2 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/EndBlock/2.png").toUri().toString());
	final static javafx.scene.image.Image ENDBLOCK_3 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/EndBlock/3.png").toUri().toString());
	final static javafx.scene.image.Image ENDBLOCK_4 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/EndBlock/4.png").toUri().toString());
	final static javafx.scene.image.Image ENDBLOCK_5= new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/EndBlock/5.png").toUri().toString());
	final static javafx.scene.image.Image ENDBLOCK_6 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/EndBlock/6.png").toUri().toString());
	final static javafx.scene.image.Image ENDBLOCK_7 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/EndBlock/7.png").toUri().toString());

	private Group endblock;

	@Override
	public void start(Stage primaryStage) throws IOException {
		final ImageView endblock1 = new ImageView(ENDBLOCK_1);
		final ImageView endblock2 = new ImageView(ENDBLOCK_2);
		final ImageView endblock3 = new ImageView(ENDBLOCK_3);
		final ImageView endblock4 = new ImageView(ENDBLOCK_4);
		final ImageView endblock5 = new ImageView(ENDBLOCK_5);
		final ImageView endblock6 = new ImageView(ENDBLOCK_6);
		final ImageView endblock7 = new ImageView(ENDBLOCK_7);

		endblock = new Group(endblock1);

		endblock.setTranslateX(0);
		endblock.setTranslateY(0);

		Timeline t = new Timeline();
		t.setCycleCount(Timeline.INDEFINITE);

		t.getKeyFrames().add(new KeyFrame(Duration.millis(100), (ActionEvent event) -> {
			endblock.getChildren().setAll(endblock2);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(150), (ActionEvent event) -> {
			endblock.getChildren().setAll(endblock3);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(200), (ActionEvent event) -> {
			endblock.getChildren().setAll(endblock4);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(250), (ActionEvent event) -> {
			endblock.getChildren().setAll(endblock5);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(300), (ActionEvent event) -> {
			endblock.getChildren().setAll(endblock6);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(350), (ActionEvent event) -> {
			endblock.getChildren().setAll(endblock7);
		}));
		t.play();

		primaryStage.setScene(new Scene(endblock, 1000, 800));
		primaryStage.setTitle("End Block");
		primaryStage.show();
	}

	public static void main(String[] args) {
		launch(args);
	}
}