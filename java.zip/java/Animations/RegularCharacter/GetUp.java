package Animations.RegularCharacter;

import java.io.IOException;
import java.nio.file.Paths;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import javafx.util.Duration;

public class GetUp extends Application {

	final static javafx.scene.image.Image GETUP_1 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/GetUp/1.png").toUri().toString());
	final static javafx.scene.image.Image GETUP_2 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/GetUp/2.png").toUri().toString());
	final static javafx.scene.image.Image GETUP_3 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/GetUp/3.png").toUri().toString());
	final static javafx.scene.image.Image GETUP_4 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/GetUp/4.png").toUri().toString());
	final static javafx.scene.image.Image GETUP_5 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/GetUp/5.png").toUri().toString());
	final static javafx.scene.image.Image GETUP_6 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/GetUp/6.png").toUri().toString());
	final static javafx.scene.image.Image GETUP_7 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/GetUp/7.png").toUri().toString());
	final static javafx.scene.image.Image GETUP_8 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/GetUp/8.png").toUri().toString());
	final static javafx.scene.image.Image GETUP_9 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/GetUp/9.png").toUri().toString());

	private Group getup;

	@Override
	public void start(Stage primaryStage) throws IOException {
		final ImageView getup1 = new ImageView(GETUP_1);
		final ImageView getup2 = new ImageView(GETUP_2);
		final ImageView getup3 = new ImageView(GETUP_3);
		final ImageView getup4 = new ImageView(GETUP_4);
		final ImageView getup5 = new ImageView(GETUP_5);
		final ImageView getup6 = new ImageView(GETUP_6);
		final ImageView getup7 = new ImageView(GETUP_7);
		final ImageView getup8 = new ImageView(GETUP_8);
		final ImageView getup9 = new ImageView(GETUP_9);
		getup = new Group(getup1);

		getup.setTranslateX(0);
		getup.setTranslateY(0);

		Timeline t = new Timeline();
		t.setCycleCount(Timeline.INDEFINITE);

		t.getKeyFrames().add(new KeyFrame(Duration.millis(100), (ActionEvent event) -> {
			getup.getChildren().setAll(getup2);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(140), (ActionEvent event) -> {
			getup.getChildren().setAll(getup3);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(180), (ActionEvent event) -> {
			getup.getChildren().setAll(getup4);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(220), (ActionEvent event) -> {
			getup.getChildren().setAll(getup5);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(260), (ActionEvent event) -> {
			getup.getChildren().setAll(getup6);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(300), (ActionEvent event) -> {
			getup.getChildren().setAll(getup7);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(340), (ActionEvent event) -> {
			getup.getChildren().setAll(getup8);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(380), (ActionEvent event) -> {
			getup.getChildren().setAll(getup9);
		}));
		t.play();

		primaryStage.setScene(new Scene(getup, 1000, 800));
		primaryStage.setTitle("Get Up");
		primaryStage.show();
	}

	public static void main(String[] args) {
		launch(args);
	}
}