package Animations.RegularCharacter;

import java.io.IOException;
import java.nio.file.Paths;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import javafx.util.Duration;

public class CrouchingIdle extends Application {

	final static javafx.scene.image.Image CROUCHING_IDLE_1 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/Crouching_Idle/1.png").toUri().toString());
	final static javafx.scene.image.Image CROUCHING_IDLE_2 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/Crouching_Idle/2.png").toUri().toString());
	final static javafx.scene.image.Image CROUCHING_IDLE_3 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/Crouching_Idle/3.png").toUri().toString());
	final static javafx.scene.image.Image CROUCHING_IDLE_4 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/Crouching_Idle/4.png").toUri().toString());
	final static javafx.scene.image.Image CROUCHING_IDLE_5 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/Crouching_Idle/5.png").toUri().toString());
	final static javafx.scene.image.Image CROUCHING_IDLE_6 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/Crouching_Idle/6.png").toUri().toString());
	final static javafx.scene.image.Image CROUCHING_IDLE_7 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/Crouching_Idle/7.png").toUri().toString());
	final static javafx.scene.image.Image CROUCHING_IDLE_8 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/Crouching_Idle/8.png").toUri().toString());
	final static javafx.scene.image.Image CROUCHING_IDLE_9 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/Crouching_Idle/9.png").toUri().toString());
	private Group crouching_idle;

	@Override
	public void start(Stage primaryStage) throws IOException {
		final ImageView crouching_idle1 = new ImageView(CROUCHING_IDLE_1);
		final ImageView crouching_idle2 = new ImageView(CROUCHING_IDLE_2);
		final ImageView crouching_idle3 = new ImageView(CROUCHING_IDLE_3);
		final ImageView crouching_idle4 = new ImageView(CROUCHING_IDLE_4);
		final ImageView crouching_idle5 = new ImageView(CROUCHING_IDLE_5);
		final ImageView crouching_idle6 = new ImageView(CROUCHING_IDLE_6);
		final ImageView crouching_idle7 = new ImageView(CROUCHING_IDLE_7);
		final ImageView crouching_idle8 = new ImageView(CROUCHING_IDLE_8);
		final ImageView crouching_idle9 = new ImageView(CROUCHING_IDLE_9);
		crouching_idle = new Group(crouching_idle1);

		crouching_idle.setTranslateX(0);
		crouching_idle.setTranslateY(0);

		Timeline t = new Timeline();
		t.setCycleCount(Timeline.INDEFINITE);

		t.getKeyFrames().add(new KeyFrame(Duration.millis(100), (ActionEvent event) -> {
			crouching_idle.getChildren().setAll(crouching_idle2);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(150), (ActionEvent event) -> {
			crouching_idle.getChildren().setAll(crouching_idle3);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(200), (ActionEvent event) -> {
			crouching_idle.getChildren().setAll(crouching_idle4);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(250), (ActionEvent event) -> {
			crouching_idle.getChildren().setAll(crouching_idle5);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(300), (ActionEvent event) -> {
			crouching_idle.getChildren().setAll(crouching_idle6);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(350), (ActionEvent event) -> {
			crouching_idle.getChildren().setAll(crouching_idle7);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(400), (ActionEvent event) -> {
			crouching_idle.getChildren().setAll(crouching_idle8);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(450), (ActionEvent event) -> {
			crouching_idle.getChildren().setAll(crouching_idle9);
		}));
		t.play();

		primaryStage.setScene(new Scene(crouching_idle, 1000, 800));
		primaryStage.setTitle("Crouching Idle");
		primaryStage.show();
	}

	public static void main(String[] args) {
		launch(args);
	}
}