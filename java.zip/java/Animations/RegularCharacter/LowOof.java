package Animations.RegularCharacter;

import java.io.IOException;
import java.nio.file.Paths;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import javafx.util.Duration;

public class LowOof extends Application {

	final static javafx.scene.image.Image LOWOOF_1 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/LowOof/1.png").toUri().toString());
	final static javafx.scene.image.Image LOWOOF_2 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/LowOof/2.png").toUri().toString());
	final static javafx.scene.image.Image LOWOOF_3 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/LowOof/3.png").toUri().toString());
	final static javafx.scene.image.Image LOWOOF_4 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/LowOof/4.png").toUri().toString());
	final static javafx.scene.image.Image LOWOOF_5= new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/LowOof/5.png").toUri().toString());
	final static javafx.scene.image.Image LOWOOF_6 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/LowOof/6.png").toUri().toString());
	final static javafx.scene.image.Image LOWOOF_7 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/LowOof/7.png").toUri().toString());
	final static javafx.scene.image.Image LOWOOF_8 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/LowOof/8.png").toUri().toString());
	final static javafx.scene.image.Image LOWOOF_9 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/LowOof/9.png").toUri().toString());
	final static javafx.scene.image.Image LOWOOF_10 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/LowOof/10.png").toUri().toString());
	final static javafx.scene.image.Image LOWOOF_11 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/LowOof/11.png").toUri().toString());
	final static javafx.scene.image.Image LOWOOF_12 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/LowOof/12.png").toUri().toString());
	final static javafx.scene.image.Image LOWOOF_13 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/LowOof/13.png").toUri().toString());
	final static javafx.scene.image.Image LOWOOF_14 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/LowOof/14.png").toUri().toString());
	final static javafx.scene.image.Image LOWOOF_15 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/LowOof/15.png").toUri().toString());

	private Group lowoof;

	@Override
	public void start(Stage primaryStage) throws IOException {
		final ImageView lowoof1 = new ImageView(LOWOOF_1);
		final ImageView lowoof2 = new ImageView(LOWOOF_2);
		final ImageView lowoof3 = new ImageView(LOWOOF_3);
		final ImageView lowoof4 = new ImageView(LOWOOF_4);
		final ImageView lowoof5 = new ImageView(LOWOOF_5);
		final ImageView lowoof6 = new ImageView(LOWOOF_6);
		final ImageView lowoof7 = new ImageView(LOWOOF_7);
		final ImageView lowoof8 = new ImageView(LOWOOF_8);
		final ImageView lowoof9 = new ImageView(LOWOOF_9);
		final ImageView lowoof10 = new ImageView(LOWOOF_10);
		final ImageView lowoof11 = new ImageView(LOWOOF_11);
		final ImageView lowoof12 = new ImageView(LOWOOF_12);
		final ImageView lowoof13 = new ImageView(LOWOOF_13);
		final ImageView lowoof14 = new ImageView(LOWOOF_14);
		final ImageView lowoof15 = new ImageView(LOWOOF_15);

		lowoof = new Group(lowoof1);

		lowoof.setTranslateX(0);
		lowoof.setTranslateY(0);

		Timeline t = new Timeline();
		t.setCycleCount(Timeline.INDEFINITE);

		t.getKeyFrames().add(new KeyFrame(Duration.millis(100), (ActionEvent event) -> {
			lowoof.getChildren().setAll(lowoof2);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(140), (ActionEvent event) -> {
			lowoof.getChildren().setAll(lowoof3);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(180), (ActionEvent event) -> {
			lowoof.getChildren().setAll(lowoof4);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(220), (ActionEvent event) -> {
			lowoof.getChildren().setAll(lowoof5);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(260), (ActionEvent event) -> {
			lowoof.getChildren().setAll(lowoof6);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(300), (ActionEvent event) -> {
			lowoof.getChildren().setAll(lowoof7);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(340), (ActionEvent event) -> {
			lowoof.getChildren().setAll(lowoof8);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(380), (ActionEvent event) -> {
			lowoof.getChildren().setAll(lowoof9);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(420), (ActionEvent event) -> {
			lowoof.getChildren().setAll(lowoof10);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(460), (ActionEvent event) -> {
			lowoof.getChildren().setAll(lowoof11);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(500), (ActionEvent event) -> {
			lowoof.getChildren().setAll(lowoof12);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(540), (ActionEvent event) -> {
			lowoof.getChildren().setAll(lowoof13);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(580), (ActionEvent event) -> {
			lowoof.getChildren().setAll(lowoof14);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(620), (ActionEvent event) -> {
			lowoof.getChildren().setAll(lowoof15);
		}));
		t.play();

		primaryStage.setScene(new Scene(lowoof, 1000, 800));
		primaryStage.setTitle("Low Oof");
		primaryStage.show();
	}

	public static void main(String[] args) {
		launch(args);
	}
}