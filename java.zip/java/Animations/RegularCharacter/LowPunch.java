package Animations.RegularCharacter;

import java.io.IOException;
import java.nio.file.Paths;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import javafx.util.Duration;

/* Testing an animation method*/
public class LowPunch extends Application {

	final static javafx.scene.image.Image LOWPUNCH_1 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacterLowPunch/1.png").toUri().toString());
	final static javafx.scene.image.Image LOWPUNCH_2 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacterLowPunch/2.png").toUri().toString());
	final static javafx.scene.image.Image LOWPUNCH_3 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacterLowPunch/3.png").toUri().toString());
	final static javafx.scene.image.Image LOWPUNCH_4 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacterLowPunch/4.png").toUri().toString());
	final static javafx.scene.image.Image LOWPUNCH_5= new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacterLowPunch/5.png").toUri().toString());
	final static javafx.scene.image.Image LOWPUNCH_6 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacterLowPunch/6.png").toUri().toString());
	final static javafx.scene.image.Image LOWPUNCH_7 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacterLowPunch/7.png").toUri().toString());
	final static javafx.scene.image.Image LOWPUNCH_8 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacterLowPunch/8.png").toUri().toString());
	final static javafx.scene.image.Image LOWPUNCH_9 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacterLowPunch/9.png").toUri().toString());
	final static javafx.scene.image.Image LOWPUNCH_10 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacterLowPunch/10.png").toUri().toString());
	final static javafx.scene.image.Image LOWPUNCH_11 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacterLowPunch/11.png").toUri().toString());

	private Group lowpunch;

	@Override
	public void start(Stage primaryStage) throws IOException {
		final ImageView lowpunch1 = new ImageView(LOWPUNCH_1);
		final ImageView lowpunch2 = new ImageView(LOWPUNCH_2);
		final ImageView lowpunch3 = new ImageView(LOWPUNCH_3);
		final ImageView lowpunch4 = new ImageView(LOWPUNCH_4);
		final ImageView lowpunch5 = new ImageView(LOWPUNCH_5);
		final ImageView lowpunch6 = new ImageView(LOWPUNCH_6);
		final ImageView lowpunch7 = new ImageView(LOWPUNCH_7);
		final ImageView lowpunch8 = new ImageView(LOWPUNCH_8);
		final ImageView lowpunch9 = new ImageView(LOWPUNCH_9);
		final ImageView lowpunch10 = new ImageView(LOWPUNCH_10);
		final ImageView lowpunch11 = new ImageView(LOWPUNCH_11);

		lowpunch = new Group(lowpunch1);

		lowpunch.setTranslateX(0);
		lowpunch.setTranslateY(0);

		Timeline t = new Timeline();
		t.setCycleCount(Timeline.INDEFINITE);

		t.getKeyFrames().add(new KeyFrame(Duration.millis(100), (ActionEvent event) -> {
			lowpunch.getChildren().setAll(lowpunch2);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(130), (ActionEvent event) -> {
			lowpunch.getChildren().setAll(lowpunch3);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(160), (ActionEvent event) -> {
			lowpunch.getChildren().setAll(lowpunch4);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(190), (ActionEvent event) -> {
			lowpunch.getChildren().setAll(lowpunch5);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(210), (ActionEvent event) -> {
			lowpunch.getChildren().setAll(lowpunch6);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(240), (ActionEvent event) -> {
			lowpunch.getChildren().setAll(lowpunch7);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(270), (ActionEvent event) -> {
			lowpunch.getChildren().setAll(lowpunch8);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(300), (ActionEvent event) -> {
			lowpunch.getChildren().setAll(lowpunch9);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(330), (ActionEvent event) -> {
			lowpunch.getChildren().setAll(lowpunch10);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(360), (ActionEvent event) -> {
			lowpunch.getChildren().setAll(lowpunch11);
		}));
		t.play();

		primaryStage.setScene(new Scene(lowpunch, 1000, 800));
		primaryStage.setTitle("Low Punch");
		primaryStage.show();
	}

	public static void main(String[] args) {
		launch(args);
	}
}