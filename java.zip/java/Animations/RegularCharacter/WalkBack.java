package Animations.RegularCharacter;

import java.io.IOException;
import java.nio.file.Paths;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import javafx.util.Duration;

/* Testing an animation method*/
public class WalkBack extends Application {

	final static javafx.scene.image.Image WALKBACK_1 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/WalkBackward/1.png").toUri().toString());
	final static javafx.scene.image.Image WALKBACK_2 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/WalkBackward/2.png").toUri().toString());
	final static javafx.scene.image.Image WALKBACK_3 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/WalkBackward/3.png").toUri().toString());
	final static javafx.scene.image.Image WALKBACK_4 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/WalkBackward/4.png").toUri().toString());
	final static javafx.scene.image.Image WALKBACK_5= new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/WalkBackward/5.png").toUri().toString());
	final static javafx.scene.image.Image WALKBACK_6 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/WalkBackward/6.png").toUri().toString());
	final static javafx.scene.image.Image WALKBACK_7 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/WalkBackward/7.png").toUri().toString());
	final static javafx.scene.image.Image WALKBACK_8 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/WalkBackward/8.png").toUri().toString());

	private Group walkback;

	@Override
	public void start(Stage primaryStage) throws IOException {
		final ImageView walkback1 = new ImageView(WALKBACK_1);
		final ImageView walkback2 = new ImageView(WALKBACK_2);
		final ImageView walkback3 = new ImageView(WALKBACK_3);
		final ImageView walkback4 = new ImageView(WALKBACK_4);
		final ImageView walkback5 = new ImageView(WALKBACK_5);
		final ImageView walkback6 = new ImageView(WALKBACK_6);
		final ImageView walkback7 = new ImageView(WALKBACK_7);
		final ImageView walkback8 = new ImageView(WALKBACK_8);

		walkback = new Group(walkback1);

		walkback.setTranslateX(0);
		walkback.setTranslateY(0);

		Timeline t = new Timeline();
		t.setCycleCount(Timeline.INDEFINITE);

		t.getKeyFrames().add(new KeyFrame(Duration.millis(100), (ActionEvent event) -> {
			walkback.getChildren().setAll(walkback2);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(200), (ActionEvent event) -> {
			walkback.getChildren().setAll(walkback3);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(300), (ActionEvent event) -> {
			walkback.getChildren().setAll(walkback4);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(400), (ActionEvent event) -> {
			walkback.getChildren().setAll(walkback5);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(500), (ActionEvent event) -> {
			walkback.getChildren().setAll(walkback6);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(600), (ActionEvent event) -> {
			walkback.getChildren().setAll(walkback7);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(700), (ActionEvent event) -> {
			walkback.getChildren().setAll(walkback8);
		}));	
		t.play();

		primaryStage.setScene(new Scene(walkback, 1000, 800));
		primaryStage.setTitle("Walkback");
		primaryStage.show();
	}

	public static void main(String[] args) {
		launch(args);
	}
}