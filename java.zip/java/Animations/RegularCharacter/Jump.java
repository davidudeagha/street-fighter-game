package Animations.RegularCharacter;

import java.io.IOException;
import java.nio.file.Paths;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import javafx.util.Duration;

/* Testing an animation method*/
public class Jump extends Application {

	final static javafx.scene.image.Image JUMP_1 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacterJump/1.png").toUri().toString());
	final static javafx.scene.image.Image JUMP_2 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacterJump/2.png").toUri().toString());
	final static javafx.scene.image.Image JUMP_3 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacterJump/3.png").toUri().toString());
	final static javafx.scene.image.Image JUMP_4 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacterJump/4.png").toUri().toString());
	final static javafx.scene.image.Image JUMP_5= new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacterJump/5.png").toUri().toString());
	final static javafx.scene.image.Image JUMP_6 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacterJump/6.png").toUri().toString());
	final static javafx.scene.image.Image JUMP_7 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacterJump/7.png").toUri().toString());
	final static javafx.scene.image.Image JUMP_8 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacterJump/8.png").toUri().toString());
	final static javafx.scene.image.Image JUMP_9 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacterJump/9.png").toUri().toString());
	final static javafx.scene.image.Image JUMP_10 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacterJump/10.png").toUri().toString());
	final static javafx.scene.image.Image JUMP_11 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacterJump/11.png").toUri().toString());
	final static javafx.scene.image.Image JUMP_12 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacterJump/12.png").toUri().toString());
	final static javafx.scene.image.Image JUMP_13 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacterJump/13.png").toUri().toString());
	final static javafx.scene.image.Image JUMP_14 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacterJump/14.png").toUri().toString());
	final static javafx.scene.image.Image JUMP_15 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacterJump/15.png").toUri().toString());
	final static javafx.scene.image.Image JUMP_16 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacterJump/16.png").toUri().toString());
	final static javafx.scene.image.Image JUMP_17 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacterJump/17.png").toUri().toString());
	final static javafx.scene.image.Image JUMP_18 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacterJump/18.png").toUri().toString());
	final static javafx.scene.image.Image JUMP_19 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacterJump/19.png").toUri().toString());
	final static javafx.scene.image.Image JUMP_20 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacterJump/20.png").toUri().toString());
	final static javafx.scene.image.Image JUMP_21 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacterJump/21.png").toUri().toString());
	final static javafx.scene.image.Image JUMP_22 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacterJump/22.png").toUri().toString());
	final static javafx.scene.image.Image JUMP_23 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacterJump/23.png").toUri().toString());
	final static javafx.scene.image.Image JUMP_24 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacterJump/24.png").toUri().toString());
	final static javafx.scene.image.Image JUMP_25 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacterJump/25.png").toUri().toString());
	final static javafx.scene.image.Image JUMP_26 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacterJump/26.png").toUri().toString());
	final static javafx.scene.image.Image JUMP_27 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacterJump/27.png").toUri().toString());

	private Group jump;

	@Override
	public void start(Stage primaryStage) throws IOException {
		final ImageView jump1 = new ImageView(JUMP_1);
		final ImageView jump2 = new ImageView(JUMP_2);
		final ImageView jump3 = new ImageView(JUMP_3);
		final ImageView jump4 = new ImageView(JUMP_4);
		final ImageView jump5 = new ImageView(JUMP_5);
		final ImageView jump6 = new ImageView(JUMP_6);
		final ImageView jump7 = new ImageView(JUMP_7);
		final ImageView jump8 = new ImageView(JUMP_8);
		final ImageView jump9 = new ImageView(JUMP_9);
		final ImageView jump10 = new ImageView(JUMP_10);
		final ImageView jump11 = new ImageView(JUMP_11);
		final ImageView jump12 = new ImageView(JUMP_12);
		final ImageView jump13 = new ImageView(JUMP_13);
		final ImageView jump14 = new ImageView(JUMP_14);
		final ImageView jump15 = new ImageView(JUMP_15);
		final ImageView jump16 = new ImageView(JUMP_16);
		final ImageView jump17 = new ImageView(JUMP_17);
		final ImageView jump18 = new ImageView(JUMP_18);
		final ImageView jump19 = new ImageView(JUMP_19);
		final ImageView jump20 = new ImageView(JUMP_20);
		final ImageView jump21 = new ImageView(JUMP_21);
		final ImageView jump22 = new ImageView(JUMP_22);
		final ImageView jump23 = new ImageView(JUMP_23);
		final ImageView jump24 = new ImageView(JUMP_24);
		final ImageView jump25 = new ImageView(JUMP_25);
		final ImageView jump26 = new ImageView(JUMP_26);
		final ImageView jump27 = new ImageView(JUMP_27);

		jump = new Group(jump1);

		jump.setTranslateX(0);
		jump.setTranslateY(0);

		Timeline t = new Timeline();
		t.setCycleCount(Timeline.INDEFINITE);

		t.getKeyFrames().add(new KeyFrame(Duration.millis(100), (ActionEvent event) -> {
			jump.getChildren().setAll(jump2);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(130), (ActionEvent event) -> {
			jump.getChildren().setAll(jump3);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(160), (ActionEvent event) -> {
			jump.getChildren().setAll(jump4);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(190), (ActionEvent event) -> {
			jump.getChildren().setAll(jump5);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(210), (ActionEvent event) -> {
			jump.getChildren().setAll(jump6);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(240), (ActionEvent event) -> {
			jump.getChildren().setAll(jump7);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(270), (ActionEvent event) -> {
			jump.getChildren().setAll(jump8);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(300), (ActionEvent event) -> {
			jump.getChildren().setAll(jump9);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(330), (ActionEvent event) -> {
			jump.getChildren().setAll(jump10);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(360), (ActionEvent event) -> {
			jump.getChildren().setAll(jump11);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(390), (ActionEvent event) -> {
			jump.getChildren().setAll(jump12);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(410), (ActionEvent event) -> {
			jump.getChildren().setAll(jump13);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(440), (ActionEvent event) -> {
			jump.getChildren().setAll(jump14);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(470), (ActionEvent event) -> {
			jump.getChildren().setAll(jump15);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(500), (ActionEvent event) -> {
			jump.getChildren().setAll(jump16);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(530), (ActionEvent event) -> {
			jump.getChildren().setAll(jump17);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(560), (ActionEvent event) -> {
			jump.getChildren().setAll(jump18);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(590), (ActionEvent event) -> {
			jump.getChildren().setAll(jump19);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(610), (ActionEvent event) -> {
			jump.getChildren().setAll(jump20);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(640), (ActionEvent event) -> {
			jump.getChildren().setAll(jump21);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(670), (ActionEvent event) -> {
			jump.getChildren().setAll(jump22);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(700), (ActionEvent event) -> {
			jump.getChildren().setAll(jump23);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(730), (ActionEvent event) -> {
			jump.getChildren().setAll(jump24);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(760), (ActionEvent event) -> {
			jump.getChildren().setAll(jump25);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(790), (ActionEvent event) -> {
			jump.getChildren().setAll(jump26);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(810), (ActionEvent event) -> {
			jump.getChildren().setAll(jump27);
		}));
		t.play();

		primaryStage.setScene(new Scene(jump, 1000, 800));
		primaryStage.setTitle("Jump");
		primaryStage.show();
	}

	public static void main(String[] args) {
		launch(args);
	}
}