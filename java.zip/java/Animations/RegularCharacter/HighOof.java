package Animations.RegularCharacter;

import java.io.IOException;
import java.nio.file.Paths;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import javafx.util.Duration;

public class HighOof extends Application {

	final static javafx.scene.image.Image HIGHOOF_1 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/HighOof/1.png").toUri().toString());
	final static javafx.scene.image.Image HIGHOOF_2 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/HighOof/2.png").toUri().toString());
	final static javafx.scene.image.Image HIGHOOF_3 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/HighOof/3.png").toUri().toString());
	final static javafx.scene.image.Image HIGHOOF_4 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/HighOof/4.png").toUri().toString());
	final static javafx.scene.image.Image HIGHOOF_5= new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/HighOof/5.png").toUri().toString());
	final static javafx.scene.image.Image HIGHOOF_6 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/HighOof/6.png").toUri().toString());
	final static javafx.scene.image.Image HIGHOOF_7 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/HighOof/7.png").toUri().toString());
	final static javafx.scene.image.Image HIGHOOF_8 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/HighOof/8.png").toUri().toString());
	final static javafx.scene.image.Image HIGHOOF_9 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/HighOof/9.png").toUri().toString());
	final static javafx.scene.image.Image HIGHOOF_10 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/HighOof/10.png").toUri().toString());
	final static javafx.scene.image.Image HIGHOOF_11 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/HighOof/11.png").toUri().toString());
	final static javafx.scene.image.Image HIGHOOF_12 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/HighOof/12.png").toUri().toString());
	final static javafx.scene.image.Image HIGHOOF_13 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/HighOof/13.png").toUri().toString());
	final static javafx.scene.image.Image HIGHOOF_14 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/HighOof/14.png").toUri().toString());
	final static javafx.scene.image.Image HIGHOOF_15 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/HighOof/15.png").toUri().toString());

	private Group highoof;

	@Override
	public void start(Stage primaryStage) throws IOException {
		final ImageView highoof1 = new ImageView(HIGHOOF_1);
		final ImageView highoof2 = new ImageView(HIGHOOF_2);
		final ImageView highoof3 = new ImageView(HIGHOOF_3);
		final ImageView highoof4 = new ImageView(HIGHOOF_4);
		final ImageView highoof5 = new ImageView(HIGHOOF_5);
		final ImageView highoof6 = new ImageView(HIGHOOF_6);
		final ImageView highoof7 = new ImageView(HIGHOOF_7);
		final ImageView highoof8 = new ImageView(HIGHOOF_8);
		final ImageView highoof9 = new ImageView(HIGHOOF_9);
		final ImageView highoof10 = new ImageView(HIGHOOF_10);
		final ImageView highoof11 = new ImageView(HIGHOOF_11);
		final ImageView highoof12 = new ImageView(HIGHOOF_12);
		final ImageView highoof13 = new ImageView(HIGHOOF_13);
		final ImageView highoof14 = new ImageView(HIGHOOF_14);
		final ImageView highoof15 = new ImageView(HIGHOOF_15);

		highoof = new Group(highoof1);

		highoof.setTranslateX(0);
		highoof.setTranslateY(0);

		Timeline t = new Timeline();
		t.setCycleCount(Timeline.INDEFINITE);

		t.getKeyFrames().add(new KeyFrame(Duration.millis(100), (ActionEvent event) -> {
			highoof.getChildren().setAll(highoof2);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(140), (ActionEvent event) -> {
			highoof.getChildren().setAll(highoof3);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(180), (ActionEvent event) -> {
			highoof.getChildren().setAll(highoof4);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(220), (ActionEvent event) -> {
			highoof.getChildren().setAll(highoof5);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(260), (ActionEvent event) -> {
			highoof.getChildren().setAll(highoof6);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(300), (ActionEvent event) -> {
			highoof.getChildren().setAll(highoof7);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(340), (ActionEvent event) -> {
			highoof.getChildren().setAll(highoof8);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(380), (ActionEvent event) -> {
			highoof.getChildren().setAll(highoof9);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(420), (ActionEvent event) -> {
			highoof.getChildren().setAll(highoof10);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(460), (ActionEvent event) -> {
			highoof.getChildren().setAll(highoof11);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(500), (ActionEvent event) -> {
			highoof.getChildren().setAll(highoof12);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(540), (ActionEvent event) -> {
			highoof.getChildren().setAll(highoof13);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(580), (ActionEvent event) -> {
			highoof.getChildren().setAll(highoof14);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(620), (ActionEvent event) -> {
			highoof.getChildren().setAll(highoof15);
		}));
		t.play();

		primaryStage.setScene(new Scene(highoof, 1000, 800));
		primaryStage.setTitle("High Oof");
		primaryStage.show();
	}

	public static void main(String[] args) {
		launch(args);
	}
}