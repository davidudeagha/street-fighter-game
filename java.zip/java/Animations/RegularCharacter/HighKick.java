package Animations.RegularCharacter;

import java.io.IOException;
import java.nio.file.Paths;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import javafx.util.Duration;

public class HighKick extends Application {

	final static javafx.scene.image.Image HIGHKICK_1 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/HighKick/1.png").toUri().toString());
	final static javafx.scene.image.Image HIGHKICK_2 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/HighKick/2.png").toUri().toString());
	final static javafx.scene.image.Image HIGHKICK_3 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/HighKick/3.png").toUri().toString());
	final static javafx.scene.image.Image HIGHKICK_4 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/HighKick/4.png").toUri().toString());
	final static javafx.scene.image.Image HIGHKICK_5= new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/HighKick/5.png").toUri().toString());
	final static javafx.scene.image.Image HIGHKICK_6 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/HighKick/6.png").toUri().toString());
	final static javafx.scene.image.Image HIGHKICK_7 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/HighKick/7.png").toUri().toString());
	final static javafx.scene.image.Image HIGHKICK_8 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/HighKick/8.png").toUri().toString());
	final static javafx.scene.image.Image HIGHKICK_9 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/HighKick/9.png").toUri().toString());
	final static javafx.scene.image.Image HIGHKICK_10 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/HighKick/10.png").toUri().toString());
	final static javafx.scene.image.Image HIGHKICK_11 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/HighKick/11.png").toUri().toString());
	final static javafx.scene.image.Image HIGHKICK_12 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/HighKick/12.png").toUri().toString());
	final static javafx.scene.image.Image HIGHKICK_13 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/HighKick/13.png").toUri().toString());
	final static javafx.scene.image.Image HIGHKICK_14 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/HighKick/14.png").toUri().toString());
	final static javafx.scene.image.Image HIGHKICK_15 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/HighKick/15.png").toUri().toString());
	final static javafx.scene.image.Image HIGHKICK_16 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/HighKick/16.png").toUri().toString());
	final static javafx.scene.image.Image HIGHKICK_17 = new javafx.scene.image.Image(
			Paths.get("resources/images/RegularCharacter/HighKick/17.png").toUri().toString());

	private Group kick;

	@Override
	public void start(Stage primaryStage) throws IOException {
		final ImageView kick1 = new ImageView(HIGHKICK_1);
		final ImageView kick2 = new ImageView(HIGHKICK_2);
		final ImageView kick3 = new ImageView(HIGHKICK_3);
		final ImageView kick4 = new ImageView(HIGHKICK_4);
		final ImageView kick5 = new ImageView(HIGHKICK_5);
		final ImageView kick6 = new ImageView(HIGHKICK_6);
		final ImageView kick7 = new ImageView(HIGHKICK_7);
		final ImageView kick8 = new ImageView(HIGHKICK_8);
		final ImageView kick9 = new ImageView(HIGHKICK_9);
		final ImageView kick10 = new ImageView(HIGHKICK_10);
		final ImageView kick11 = new ImageView(HIGHKICK_11);
		final ImageView kick12 = new ImageView(HIGHKICK_12);
		final ImageView kick13 = new ImageView(HIGHKICK_13);
		final ImageView kick14 = new ImageView(HIGHKICK_14);
		final ImageView kick15 = new ImageView(HIGHKICK_15);
		final ImageView kick16 = new ImageView(HIGHKICK_16);
		final ImageView kick17 = new ImageView(HIGHKICK_17);

		kick = new Group(kick1);

		kick.setTranslateX(0);
		kick.setTranslateY(0);

		Timeline t = new Timeline();
		t.setCycleCount(Timeline.INDEFINITE);

		t.getKeyFrames().add(new KeyFrame(Duration.millis(100), (ActionEvent event) -> {
			kick.getChildren().setAll(kick2);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(140), (ActionEvent event) -> {
			kick.getChildren().setAll(kick3);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(180), (ActionEvent event) -> {
			kick.getChildren().setAll(kick4);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(220), (ActionEvent event) -> {
			kick.getChildren().setAll(kick5);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(260), (ActionEvent event) -> {
			kick.getChildren().setAll(kick6);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(300), (ActionEvent event) -> {
			kick.getChildren().setAll(kick7);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(340), (ActionEvent event) -> {
			kick.getChildren().setAll(kick8);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(380), (ActionEvent event) -> {
			kick.getChildren().setAll(kick9);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(420), (ActionEvent event) -> {
			kick.getChildren().setAll(kick10);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(460), (ActionEvent event) -> {
			kick.getChildren().setAll(kick11);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(500), (ActionEvent event) -> {
			kick.getChildren().setAll(kick12);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(540), (ActionEvent event) -> {
			kick.getChildren().setAll(kick13);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(580), (ActionEvent event) -> {
			kick.getChildren().setAll(kick14);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(620), (ActionEvent event) -> {
			kick.getChildren().setAll(kick15);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(660), (ActionEvent event) -> {
			kick.getChildren().setAll(kick16);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(700), (ActionEvent event) -> {
			kick.getChildren().setAll(kick17);
		}));
		t.play();

		primaryStage.setScene(new Scene(kick, 1000, 800));
		primaryStage.setTitle("High Kick");
		primaryStage.show();
	}

	public static void main(String[] args) {
		launch(args);
	}
}