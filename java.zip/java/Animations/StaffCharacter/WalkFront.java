package Animations.StaffCharacter;

import java.io.IOException;
import java.nio.file.Paths;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import javafx.util.Duration;

/*To be repeated*/
public class WalkFront extends Application {

	final static javafx.scene.image.Image WALKFORWARD_1 = new javafx.scene.image.Image(
			Paths.get("resources/images/StaffCharacter/WalkForward/1.png").toUri().toString());
	final static javafx.scene.image.Image WALKFORWARD_2 = new javafx.scene.image.Image(
			Paths.get("resources/images/StaffCharacter/WalkForward/2.png").toUri().toString());
	final static javafx.scene.image.Image WALKFORWARD_3 = new javafx.scene.image.Image(
			Paths.get("resources/images/StaffCharacter/WalkForward/3.png").toUri().toString());
	final static javafx.scene.image.Image WALKFORWARD_4 = new javafx.scene.image.Image(
			Paths.get("resources/images/StaffCharacter/WalkForward/4.png").toUri().toString());
	final static javafx.scene.image.Image WALKFORWARD_5= new javafx.scene.image.Image(
			Paths.get("resources/images/StaffCharacter/WalkForward/5.png").toUri().toString());
	final static javafx.scene.image.Image WALKFORWARD_6 = new javafx.scene.image.Image(
			Paths.get("resources/images/StaffCharacter/WalkForward/6.png").toUri().toString());
	final static javafx.scene.image.Image WALKFORWARD_7 = new javafx.scene.image.Image(
			Paths.get("resources/images/StaffCharacter/WalkForward/7.png").toUri().toString());
	final static javafx.scene.image.Image WALKFORWARD_8 = new javafx.scene.image.Image(
			Paths.get("resources/images/StaffCharacter/WalkForward/8.png").toUri().toString());
	final static javafx.scene.image.Image WALKFORWARD_9 = new javafx.scene.image.Image(
			Paths.get("resources/images/StaffCharacter/WalkForward/9.png").toUri().toString());
	final static javafx.scene.image.Image WALKFORWARD_10 = new javafx.scene.image.Image(
			Paths.get("resources/images/StaffCharacter/WalkForward/10.png").toUri().toString());
	final static javafx.scene.image.Image WALKFORWARD_11 = new javafx.scene.image.Image(
			Paths.get("resources/images/StaffCharacter/WalkForward/11.png").toUri().toString());
	final static javafx.scene.image.Image WALKFORWARD_12 = new javafx.scene.image.Image(
			Paths.get("resources/images/StaffCharacter/WalkForward/12.png").toUri().toString());

	private Group walkforward;

	@Override
	public void start(Stage primaryStage) throws IOException {
		final ImageView walkforward1 = new ImageView(WALKFORWARD_1);
		final ImageView walkforward2 = new ImageView(WALKFORWARD_2);
		final ImageView walkforward3 = new ImageView(WALKFORWARD_3);
		final ImageView walkforward4 = new ImageView(WALKFORWARD_4);
		final ImageView walkforward5 = new ImageView(WALKFORWARD_5);
		final ImageView walkforward6 = new ImageView(WALKFORWARD_6);
		final ImageView walkforward7 = new ImageView(WALKFORWARD_7);
		final ImageView walkforward8 = new ImageView(WALKFORWARD_8);
		final ImageView walkforward9 = new ImageView(WALKFORWARD_9);
		final ImageView walkforward10 = new ImageView(WALKFORWARD_10);
		final ImageView walkforward11 = new ImageView(WALKFORWARD_11);
		final ImageView walkforward12 = new ImageView(WALKFORWARD_12);

		walkforward = new Group(walkforward1);

		walkforward.setTranslateX(0);
		walkforward.setTranslateY(0);

		Timeline t = new Timeline();
		t.setCycleCount(Timeline.INDEFINITE);

		t.getKeyFrames().add(new KeyFrame(Duration.millis(100), (ActionEvent event) -> {
			walkforward.getChildren().setAll(walkforward2);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(200), (ActionEvent event) -> {
			walkforward.getChildren().setAll(walkforward3);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(300), (ActionEvent event) -> {
			walkforward.getChildren().setAll(walkforward4);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(400), (ActionEvent event) -> {
			walkforward.getChildren().setAll(walkforward5);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(500), (ActionEvent event) -> {
			walkforward.getChildren().setAll(walkforward6);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(600), (ActionEvent event) -> {
			walkforward.getChildren().setAll(walkforward7);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(700), (ActionEvent event) -> {
			walkforward.getChildren().setAll(walkforward8);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(750), (ActionEvent event) -> {
			walkforward.getChildren().setAll(walkforward9);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(800), (ActionEvent event) -> {
			walkforward.getChildren().setAll(walkforward10);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(850), (ActionEvent event) -> {
			walkforward.getChildren().setAll(walkforward11);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(900), (ActionEvent event) -> {
			walkforward.getChildren().setAll(walkforward12);
		}));
		t.play();

		primaryStage.setScene(new Scene(walkforward, 1000, 800));
		primaryStage.setTitle("Walkfront");
		primaryStage.show();
	}

	public static void main(String[] args) {
		launch(args);
	}
}