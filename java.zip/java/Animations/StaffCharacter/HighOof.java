package Animations.StaffCharacter;

import java.io.IOException;
import java.nio.file.Paths;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import javafx.util.Duration;

/* Testing an animation method*/
public class HighOof extends Application {

	final static javafx.scene.image.Image HIGHOOF_1 = new javafx.scene.image.Image(
			Paths.get("resources/images/StaffCharacter/HighOof/1.png").toUri().toString());
	final static javafx.scene.image.Image HIGHOOF_2 = new javafx.scene.image.Image(
			Paths.get("resources/images/StaffCharacter/HighOof/2.png").toUri().toString());
	final static javafx.scene.image.Image HIGHOOF_3 = new javafx.scene.image.Image(
			Paths.get("resources/images/StaffCharacter/HighOof/3.png").toUri().toString());
	final static javafx.scene.image.Image HIGHOOF_4 = new javafx.scene.image.Image(
			Paths.get("resources/images/StaffCharacter/HighOof/4.png").toUri().toString());
	final static javafx.scene.image.Image HIGHOOF_5= new javafx.scene.image.Image(
			Paths.get("resources/images/StaffCharacter/HighOof/5.png").toUri().toString());
	final static javafx.scene.image.Image HIGHOOF_6 = new javafx.scene.image.Image(
			Paths.get("resources/images/StaffCharacter/HighOof/6.png").toUri().toString());
	final static javafx.scene.image.Image HIGHOOF_7 = new javafx.scene.image.Image(
			Paths.get("resources/images/StaffCharacter/HighOof/7.png").toUri().toString());
	final static javafx.scene.image.Image HIGHOOF_8 = new javafx.scene.image.Image(
			Paths.get("resources/images/StaffCharacter/HighOof/8.png").toUri().toString());
	final static javafx.scene.image.Image HIGHOOF_9 = new javafx.scene.image.Image(
			Paths.get("resources/images/StaffCharacter/HighOof/9.png").toUri().toString());
	private Group highoof;

	@Override
	public void start(Stage primaryStage) throws IOException {
		final ImageView highoof1 = new ImageView(HIGHOOF_1);
		final ImageView highoof2 = new ImageView(HIGHOOF_2);
		final ImageView highoof3 = new ImageView(HIGHOOF_3);
		final ImageView highoof4 = new ImageView(HIGHOOF_4);
		final ImageView highoof5 = new ImageView(HIGHOOF_5);
		final ImageView highoof6 = new ImageView(HIGHOOF_6);
		final ImageView highoof7 = new ImageView(HIGHOOF_7);
		final ImageView highoof8 = new ImageView(HIGHOOF_8);
		final ImageView highoof9 = new ImageView(HIGHOOF_9);

		highoof = new Group(highoof1);

		highoof.setTranslateX(0);
		highoof.setTranslateY(0);

		Timeline t = new Timeline();
		t.setCycleCount(Timeline.INDEFINITE);

		t.getKeyFrames().add(new KeyFrame(Duration.millis(100), (ActionEvent event) -> {
			highoof.getChildren().setAll(highoof2);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(150), (ActionEvent event) -> {
			highoof.getChildren().setAll(highoof3);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(200), (ActionEvent event) -> {
			highoof.getChildren().setAll(highoof4);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(250), (ActionEvent event) -> {
			highoof.getChildren().setAll(highoof5);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(300), (ActionEvent event) -> {
			highoof.getChildren().setAll(highoof6);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(350), (ActionEvent event) -> {
			highoof.getChildren().setAll(highoof7);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(400), (ActionEvent event) -> {
			highoof.getChildren().setAll(highoof8);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(450), (ActionEvent event) -> {
			highoof.getChildren().setAll(highoof9);
		}));
		t.play();

		primaryStage.setScene(new Scene(highoof, 1000, 800));
		primaryStage.setTitle("High Oof");
		primaryStage.show();
	}

	public static void main(String[] args) {
		launch(args);
	}
}