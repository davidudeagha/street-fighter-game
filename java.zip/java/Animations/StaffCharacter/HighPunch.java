package Animations.StaffCharacter;

import java.io.IOException;
import java.nio.file.Paths;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import javafx.util.Duration;

public class HighPunch extends Application {

	final static javafx.scene.image.Image HIGHPUNCH_1 = new javafx.scene.image.Image(
			Paths.get("resources/images/StaffCharacter/HighPunch/1.png").toUri().toString());
	final static javafx.scene.image.Image HIGHPUNCH_2 = new javafx.scene.image.Image(
			Paths.get("resources/images/StaffCharacter/HighPunch/2.png").toUri().toString());
	final static javafx.scene.image.Image HIGHPUNCH_3 = new javafx.scene.image.Image(
			Paths.get("resources/images/StaffCharacter/HighPunch/3.png").toUri().toString());
	final static javafx.scene.image.Image HIGHPUNCH_4 = new javafx.scene.image.Image(
			Paths.get("resources/images/StaffCharacter/HighPunch/4.png").toUri().toString());
	final static javafx.scene.image.Image HIGHPUNCH_5 = new javafx.scene.image.Image(
			Paths.get("resources/images/StaffCharacter/HighPunch/5.png").toUri().toString());
	final static javafx.scene.image.Image HIGHPUNCH_6 = new javafx.scene.image.Image(
			Paths.get("resources/images/StaffCharacter/HighPunch/6.png").toUri().toString());
	final static javafx.scene.image.Image HIGHPUNCH_7 = new javafx.scene.image.Image(
			Paths.get("resources/images/StaffCharacter/HighPunch/7.png").toUri().toString());
	final static javafx.scene.image.Image HIGHPUNCH_8 = new javafx.scene.image.Image(
			Paths.get("resources/images/StaffCharacter/HighPunch/8.png").toUri().toString());
	final static javafx.scene.image.Image HIGHPUNCH_9 = new javafx.scene.image.Image(
			Paths.get("resources/images/StaffCharacter/HighPunch/9.png").toUri().toString());
	final static javafx.scene.image.Image HIGHPUNCH_10 = new javafx.scene.image.Image(
			Paths.get("resources/images/StaffCharacter/HighPunch/10.png").toUri().toString());
	final static javafx.scene.image.Image HIGHPUNCH_11 = new javafx.scene.image.Image(
			Paths.get("resources/images/StaffCharacter/HighPunch/11.png").toUri().toString());
	final static javafx.scene.image.Image HIGHPUNCH_12 = new javafx.scene.image.Image(
			Paths.get("resources/images/StaffCharacter/HighPunch/12.png").toUri().toString());
	final static javafx.scene.image.Image HIGHPUNCH_13 = new javafx.scene.image.Image(
			Paths.get("resources/images/StaffCharacter/HighPunch/13.png").toUri().toString());
	final static javafx.scene.image.Image HIGHPUNCH_14 = new javafx.scene.image.Image(
			Paths.get("resources/images/StaffCharacter/HighPunch/14.png").toUri().toString());
	final static javafx.scene.image.Image HIGHPUNCH_15 = new javafx.scene.image.Image(
			Paths.get("resources/images/StaffCharacter/HighPunch/15.png").toUri().toString());
	final static javafx.scene.image.Image HIGHPUNCH_16 = new javafx.scene.image.Image(
			Paths.get("resources/images/StaffCharacter/HighPunch/16.png").toUri().toString());
	final static javafx.scene.image.Image HIGHPUNCH_17 = new javafx.scene.image.Image(
			Paths.get("resources/images/StaffCharacter/HighPunch/17.png").toUri().toString());
	final static javafx.scene.image.Image HIGHPUNCH_18 = new javafx.scene.image.Image(
			Paths.get("resources/images/StaffCharacter/HighPunch/18.png").toUri().toString());
	final static javafx.scene.image.Image HIGHPUNCH_19 = new javafx.scene.image.Image(
			Paths.get("resources/images/StaffCharacter/HighPunch/19.png").toUri().toString());
	final static javafx.scene.image.Image HIGHPUNCH_20 = new javafx.scene.image.Image(
			Paths.get("resources/images/StaffCharacter/HighPunch/20.png").toUri().toString());
	final static javafx.scene.image.Image HIGHPUNCH_21 = new javafx.scene.image.Image(
			Paths.get("resources/images/StaffCharacter/HighPunch/21.png").toUri().toString());
	final static javafx.scene.image.Image HIGHPUNCH_22 = new javafx.scene.image.Image(
			Paths.get("resources/images/StaffCharacter/HighPunch/22.png").toUri().toString());
	final static javafx.scene.image.Image HIGHPUNCH_23 = new javafx.scene.image.Image(
			Paths.get("resources/images/StaffCharacter/HighPunch/23.png").toUri().toString());
	final static javafx.scene.image.Image HIGHPUNCH_24 = new javafx.scene.image.Image(
			Paths.get("resources/images/StaffCharacter/HighPunch/24.png").toUri().toString());
	final static javafx.scene.image.Image HIGHPUNCH_25 = new javafx.scene.image.Image(
			Paths.get("resources/images/StaffCharacter/HighPunch/25.png").toUri().toString());
	final static javafx.scene.image.Image HIGHPUNCH_26 = new javafx.scene.image.Image(
			Paths.get("resources/images/StaffCharacter/HighPunch/26.png").toUri().toString());

	private Group highpunch;

	@Override
	public void start(Stage primaryStage) throws IOException {
		final ImageView highpunch1 = new ImageView(HIGHPUNCH_1);
		final ImageView highpunch2 = new ImageView(HIGHPUNCH_2);
		final ImageView highpunch3 = new ImageView(HIGHPUNCH_3);
		final ImageView highpunch4 = new ImageView(HIGHPUNCH_4);
		final ImageView highpunch5 = new ImageView(HIGHPUNCH_5);
		final ImageView highpunch6 = new ImageView(HIGHPUNCH_6);
		final ImageView highpunch7 = new ImageView(HIGHPUNCH_7);
		final ImageView highpunch8 = new ImageView(HIGHPUNCH_8);
		final ImageView highpunch9 = new ImageView(HIGHPUNCH_9);
		final ImageView highpunch10 = new ImageView(HIGHPUNCH_10);
		final ImageView highpunch11 = new ImageView(HIGHPUNCH_11);
		final ImageView highpunch12 = new ImageView(HIGHPUNCH_12);
		final ImageView highpunch13 = new ImageView(HIGHPUNCH_13);
		final ImageView highpunch14 = new ImageView(HIGHPUNCH_14);
		final ImageView highpunch15 = new ImageView(HIGHPUNCH_15);
		final ImageView highpunch16 = new ImageView(HIGHPUNCH_16);
		final ImageView highpunch17 = new ImageView(HIGHPUNCH_17);
		final ImageView highpunch18 = new ImageView(HIGHPUNCH_18);
		final ImageView highpunch19 = new ImageView(HIGHPUNCH_19);
		final ImageView highpunch20 = new ImageView(HIGHPUNCH_20);
		final ImageView highpunch21 = new ImageView(HIGHPUNCH_21);
		final ImageView highpunch22 = new ImageView(HIGHPUNCH_22);
		final ImageView highpunch23 = new ImageView(HIGHPUNCH_23);
		final ImageView highpunch24 = new ImageView(HIGHPUNCH_24);
		final ImageView highpunch25 = new ImageView(HIGHPUNCH_25);
		final ImageView highpunch26 = new ImageView(HIGHPUNCH_26);

		highpunch = new Group(highpunch1);

		highpunch.setTranslateX(0);
		highpunch.setTranslateY(0);

		Timeline t = new Timeline();
		t.setCycleCount(Timeline.INDEFINITE);

		t.getKeyFrames().add(new KeyFrame(Duration.millis(100), (ActionEvent event) -> {
			highpunch.getChildren().setAll(highpunch2);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(150), (ActionEvent event) -> {
			highpunch.getChildren().setAll(highpunch3);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(200), (ActionEvent event) -> {
			highpunch.getChildren().setAll(highpunch4);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(250), (ActionEvent event) -> {
			highpunch.getChildren().setAll(highpunch5);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(300), (ActionEvent event) -> {
			highpunch.getChildren().setAll(highpunch6);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(350), (ActionEvent event) -> {
			highpunch.getChildren().setAll(highpunch7);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(400), (ActionEvent event) -> {
			highpunch.getChildren().setAll(highpunch8);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(450), (ActionEvent event) -> {
			highpunch.getChildren().setAll(highpunch9);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(500), (ActionEvent event) -> {
			highpunch.getChildren().setAll(highpunch10);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(600), (ActionEvent event) -> {
			highpunch.getChildren().setAll(highpunch11);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(650), (ActionEvent event) -> {
			highpunch.getChildren().setAll(highpunch12);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(700), (ActionEvent event) -> {
			highpunch.getChildren().setAll(highpunch13);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(750), (ActionEvent event) -> {
			highpunch.getChildren().setAll(highpunch14);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(800), (ActionEvent event) -> {
			highpunch.getChildren().setAll(highpunch15);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(850), (ActionEvent event) -> {
			highpunch.getChildren().setAll(highpunch16);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(900), (ActionEvent event) -> {
			highpunch.getChildren().setAll(highpunch17);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(950), (ActionEvent event) -> {
			highpunch.getChildren().setAll(highpunch18);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(1000), (ActionEvent event) -> {
			highpunch.getChildren().setAll(highpunch19);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(1050), (ActionEvent event) -> {
			highpunch.getChildren().setAll(highpunch20);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(1100), (ActionEvent event) -> {
			highpunch.getChildren().setAll(highpunch21);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(1150), (ActionEvent event) -> {
			highpunch.getChildren().setAll(highpunch22);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(1200), (ActionEvent event) -> {
			highpunch.getChildren().setAll(highpunch23);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(1250), (ActionEvent event) -> {
			highpunch.getChildren().setAll(highpunch24);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(1300), (ActionEvent event) -> {
			highpunch.getChildren().setAll(highpunch25);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(1350), (ActionEvent event) -> {
			highpunch.getChildren().setAll(highpunch26);
		}));
		t.play();

		primaryStage.setScene(new Scene(highpunch, 1000, 800));
		primaryStage.setTitle("High Punch");
		primaryStage.show();
	}

	public static void main(String[] args) {
		launch(args);
	}
}