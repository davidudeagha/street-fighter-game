package Animations.StaffCharacter;

import java.io.IOException;
import java.nio.file.Paths;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import javafx.util.Duration;

public class Taunt extends Application {

	final static javafx.scene.image.Image TAUNT_1 = new javafx.scene.image.Image(
			Paths.get("resources/images/StaffCharacter/Taunt/1.png").toUri().toString());
	final static javafx.scene.image.Image TAUNT_2 = new javafx.scene.image.Image(
			Paths.get("resources/images/StaffCharacter/Taunt/2.png").toUri().toString());
	final static javafx.scene.image.Image TAUNT_3 = new javafx.scene.image.Image(
			Paths.get("resources/images/StaffCharacter/Taunt/3.png").toUri().toString());
	final static javafx.scene.image.Image TAUNT_4 = new javafx.scene.image.Image(
			Paths.get("resources/images/StaffCharacter/Taunt/4.png").toUri().toString());
	final static javafx.scene.image.Image TAUNT_5 = new javafx.scene.image.Image(
			Paths.get("resources/images/StaffCharacter/Taunt/5.png").toUri().toString());
	final static javafx.scene.image.Image TAUNT_6 = new javafx.scene.image.Image(
			Paths.get("resources/images/StaffCharacter/Taunt/6.png").toUri().toString());
	final static javafx.scene.image.Image TAUNT_7 = new javafx.scene.image.Image(
			Paths.get("resources/images/StaffCharacter/Taunt/7.png").toUri().toString());
	final static javafx.scene.image.Image TAUNT_8 = new javafx.scene.image.Image(
			Paths.get("resources/images/StaffCharacter/Taunt/8.png").toUri().toString());
	final static javafx.scene.image.Image TAUNT_9 = new javafx.scene.image.Image(
			Paths.get("resources/images/StaffCharacter/Taunt/9.png").toUri().toString());
	final static javafx.scene.image.Image TAUNT_10 = new javafx.scene.image.Image(
			Paths.get("resources/images/StaffCharacter/Taunt/10.png").toUri().toString());
	final static javafx.scene.image.Image TAUNT_11 = new javafx.scene.image.Image(
			Paths.get("resources/images/StaffCharacter/Taunt/11.png").toUri().toString());
	final static javafx.scene.image.Image TAUNT_12 = new javafx.scene.image.Image(
			Paths.get("resources/images/StaffCharacter/Taunt/12.png").toUri().toString());
	final static javafx.scene.image.Image TAUNT_13 = new javafx.scene.image.Image(
			Paths.get("resources/images/StaffCharacter/Taunt/13.png").toUri().toString());
	final static javafx.scene.image.Image TAUNT_14 = new javafx.scene.image.Image(
			Paths.get("resources/images/StaffCharacter/Taunt/14.png").toUri().toString());
	final static javafx.scene.image.Image TAUNT_15 = new javafx.scene.image.Image(
			Paths.get("resources/images/StaffCharacter/Taunt/15.png").toUri().toString());
	final static javafx.scene.image.Image TAUNT_16 = new javafx.scene.image.Image(
			Paths.get("resources/images/StaffCharacter/Taunt/16.png").toUri().toString());
	final static javafx.scene.image.Image TAUNT_17 = new javafx.scene.image.Image(
			Paths.get("resources/images/StaffCharacter/Taunt/17.png").toUri().toString());
	final static javafx.scene.image.Image TAUNT_18 = new javafx.scene.image.Image(
			Paths.get("resources/images/StaffCharacter/Taunt/18.png").toUri().toString());
	final static javafx.scene.image.Image TAUNT_19 = new javafx.scene.image.Image(
			Paths.get("resources/images/StaffCharacter/Taunt/19.png").toUri().toString());
	final static javafx.scene.image.Image TAUNT_20 = new javafx.scene.image.Image(
			Paths.get("resources/images/StaffCharacter/Taunt/20.png").toUri().toString());
	final static javafx.scene.image.Image TAUNT_21 = new javafx.scene.image.Image(
			Paths.get("resources/images/StaffCharacter/Taunt/21.png").toUri().toString());
	final static javafx.scene.image.Image TAUNT_22 = new javafx.scene.image.Image(
			Paths.get("resources/images/StaffCharacter/Taunt/22.png").toUri().toString());
	final static javafx.scene.image.Image TAUNT_23 = new javafx.scene.image.Image(
			Paths.get("resources/images/StaffCharacter/Taunt/23.png").toUri().toString());
	final static javafx.scene.image.Image TAUNT_24 = new javafx.scene.image.Image(
			Paths.get("resources/images/StaffCharacter/Taunt/24.png").toUri().toString());

	
	private Group taunt;

	@Override
	public void start(Stage primaryStage) throws IOException {
		final ImageView taunt1 = new ImageView(TAUNT_1);
		final ImageView taunt2 = new ImageView(TAUNT_2);
		final ImageView taunt3 = new ImageView(TAUNT_3);
		final ImageView taunt4 = new ImageView(TAUNT_4);
		final ImageView taunt5 = new ImageView(TAUNT_5);
		final ImageView taunt6 = new ImageView(TAUNT_6);
		final ImageView taunt7 = new ImageView(TAUNT_7);
		final ImageView taunt8 = new ImageView(TAUNT_8);
		final ImageView taunt9 = new ImageView(TAUNT_9);
		final ImageView taunt10 = new ImageView(TAUNT_10);
		final ImageView taunt11 = new ImageView(TAUNT_11);
		final ImageView taunt12 = new ImageView(TAUNT_12);
		final ImageView taunt13 = new ImageView(TAUNT_13);
		final ImageView taunt14 = new ImageView(TAUNT_14);
		final ImageView taunt15 = new ImageView(TAUNT_15);
		final ImageView taunt16 = new ImageView(TAUNT_16);
		final ImageView taunt17 = new ImageView(TAUNT_17);
		final ImageView taunt18 = new ImageView(TAUNT_18);
		final ImageView taunt19 = new ImageView(TAUNT_19);
		final ImageView taunt20 = new ImageView(TAUNT_20);
		final ImageView taunt21 = new ImageView(TAUNT_21);
		final ImageView taunt22 = new ImageView(TAUNT_22);
		final ImageView taunt23 = new ImageView(TAUNT_23);
		final ImageView taunt24 = new ImageView(TAUNT_24);

		taunt = new Group(taunt1);

		taunt.setTranslateX(0);
		taunt.setTranslateY(0);

		Timeline t = new Timeline();
		t.setCycleCount(Timeline.INDEFINITE);

		t.getKeyFrames().add(new KeyFrame(Duration.millis(100), (ActionEvent event) -> {
			taunt.getChildren().setAll(taunt2);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(150), (ActionEvent event) -> {
			taunt.getChildren().setAll(taunt3);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(200), (ActionEvent event) -> {
			taunt.getChildren().setAll(taunt4);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(250), (ActionEvent event) -> {
			taunt.getChildren().setAll(taunt5);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(300), (ActionEvent event) -> {
			taunt.getChildren().setAll(taunt6);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(350), (ActionEvent event) -> {
			taunt.getChildren().setAll(taunt7);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(400), (ActionEvent event) -> {
			taunt.getChildren().setAll(taunt8);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(450), (ActionEvent event) -> {
			taunt.getChildren().setAll(taunt9);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(500), (ActionEvent event) -> {
			taunt.getChildren().setAll(taunt10);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(600), (ActionEvent event) -> {
			taunt.getChildren().setAll(taunt11);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(650), (ActionEvent event) -> {
			taunt.getChildren().setAll(taunt12);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(700), (ActionEvent event) -> {
			taunt.getChildren().setAll(taunt13);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(750), (ActionEvent event) -> {
			taunt.getChildren().setAll(taunt14);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(800), (ActionEvent event) -> {
			taunt.getChildren().setAll(taunt15);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(850), (ActionEvent event) -> {
			taunt.getChildren().setAll(taunt16);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(900), (ActionEvent event) -> {
			taunt.getChildren().setAll(taunt17);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(950), (ActionEvent event) -> {
			taunt.getChildren().setAll(taunt18);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(1000), (ActionEvent event) -> {
			taunt.getChildren().setAll(taunt19);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(1050), (ActionEvent event) -> {
			taunt.getChildren().setAll(taunt20);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(1100), (ActionEvent event) -> {
			taunt.getChildren().setAll(taunt21);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(1150), (ActionEvent event) -> {
			taunt.getChildren().setAll(taunt22);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(1200), (ActionEvent event) -> {
			taunt.getChildren().setAll(taunt23);
		}));
		t.getKeyFrames().add(new KeyFrame(Duration.millis(1250), (ActionEvent event) -> {
			taunt.getChildren().setAll(taunt24);
		}));
		t.play();

		primaryStage.setScene(new Scene(taunt, 1000, 800));
		primaryStage.setTitle("Taunt");
		primaryStage.show();
	}

	public static void main(String[] args) {
		launch(args);
	}
}