package Utils;

public enum CharacterTypes {
    REGULAR_CHARACTER,
    STAFF_CHARACTER

}
