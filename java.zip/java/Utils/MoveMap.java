package Utils;

import GameLogic.*;

import java.util.HashMap;
import java.util.Map;

/**
 * Class which instantiates and provides access to the mapping between moveID and move objects,
 * used to realise damage and other move modifiers
 */
public class MoveMap {

    private final Map<Integer, Move> map = new HashMap<>();

    public MoveMap() {
        map.put(0, new HighKick());
        map.put(1, new HighPunch());
        map.put(2, new LowKick());
        map.put(3, new LowPunch());
        map.put(4, new HighBlock());
        map.put(5, new LowBlock());
        map.put(6,new MoveForward());
        map.put(7,new MoveBackward());

    }

    public  Map<Integer, Move> getMap() {
        return map;
    }
}
