package KeyboardInput;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.HashSet;
import java.util.Set;

public class KeyboardInput implements KeyListener {

    private static Set<Integer> keysPressed = new HashSet<>();
    private int moveID = -1;
    private static Logger logger = Logger.getLogger(KeyboardInput.class);

    @Override
    public void keyTyped(KeyEvent e) {

    }

    @Override
    public void keyPressed(KeyEvent e) {
        logger.setLevel(Level.TRACE);
        keysPressed.add(e.getKeyCode());
        // movement
        logger.trace("Keystroke registered ");
        if (keyPressedHelper('a') && keyPressedHelper('d')) {
            // don't move
            setMoveID(-1);
        } else if (keyPressedHelper('a')) {
            // move backwards
            logger.trace("a registered");
            setMoveID(7);
        } else if (keyPressedHelper('d')) {
            // move forwards
            logger.trace("d registered");
            setMoveID(6);
        }
        // attacks
        if (keyPressedHelper('w')) {
            if (keyPressedHelper('b')) {
                // high block
                logger.trace("w b registered");
                setMoveID(4);
            } else if (keyPressedHelper('k')) {
                // high kick
                logger.trace("w k  registered");
                setMoveID(0);
            } else if (keyPressedHelper('p')) {
                // high punch
                logger.trace("w p registered");
                setMoveID(1);
            }
        } else if (keyPressedHelper('s')) {
            if (keyPressedHelper('b')) {
                // low block
                logger.trace("s b registered");
                setMoveID(5);
            } else if (keyPressedHelper('k')) {
                // low kick
                logger.trace("s k registered");
                setMoveID(2);
            } else if (keyPressedHelper('p')) {
                // low punch
                logger.trace("s p registered");
                setMoveID(3);
            }
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {
        keysPressed.remove(e.getKeyCode());
        if (keysPressed.isEmpty()) {
            setMoveID(-1);
        }
    }

    private int keyID(char key) {
        switch (key) {
            case 'w':
                return KeyEvent.VK_W;
            case 'a':
                return KeyEvent.VK_A;
            case 's':
                return KeyEvent.VK_S;
            case 'd':
                return KeyEvent.VK_D;
            case 'b':
                return KeyEvent.VK_B;
            case 'k':
                return KeyEvent.VK_K;
            case 'p':
                return KeyEvent.VK_P;
            default:
                return KeyEvent.VK_SPACE;
        }
    }

    private boolean keyPressedHelper(char key) {
        return keysPressed.contains(keyID(key));
    }

    public void setMoveID(int ID) {
        this.moveID = ID;
    }

    public int getMoveID() {
        return this.moveID;
    }


}