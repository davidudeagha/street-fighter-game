package KeyboardInput;

public class KBTest {
    public static void main(String[] args) {

    }
}
