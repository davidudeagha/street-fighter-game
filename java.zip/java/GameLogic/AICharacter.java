package GameLogic;

import AI.IntegratedMarkovLearner;
import RenderEngine.Animation;
import Utils.CharacterTypes;
import Utils.Coordinate;
import Utils.MoveMap;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import java.io.File;
import java.util.*;

public class AICharacter extends Character {
    private static Logger logger = Logger.getLogger(AICharacter.class);


    private static final int MAXHEALTH = 100;
    private static final double STARTPOINT_X = 700;
    private static final double STARTPOINT_Y = 250;
    private double oppPos = 25;
    private IntegratedMarkovLearner learner = new IntegratedMarkovLearner();
    ;
    private Map<String, Image[]> animationMap = new HashMap<>();
    private Map<Integer, Move> moveMap = new MoveMap().getMap();
    private boolean flipped = false;
    private int playerID;

    public void flip() {
        flipped = !flipped;
    }

    public boolean isFlipped() {
        return flipped;
    }

    public AICharacter(int playerID, CharacterTypes type) {
        System.out.println(type);
        this.playerID = playerID;
        logger.setLevel(Level.OFF);
        this.health = MAXHEALTH;
        if (this.
                playerID == 2) {
            coordinate = new Coordinate(STARTPOINT_X, STARTPOINT_Y);
        } else {
            coordinate = new Coordinate(20, STARTPOINT_Y);

        }
        System.out.println("Creating AI Character");

        ArrayList<Image[]> sprites = new ArrayList<>();
        String[] animations = new String[]{};
        String dir = "";
        String imgPath = "";
        if (type == CharacterTypes.REGULAR_CHARACTER) {
            dir = "src/main/resources/images/RegularCharacter/";
            imgPath = "/images/RegularCharacter/";
            animations = new String[]{"HighKick", "HighPunch", "Idle",
                    "LowKick", "LowPunch", "WalkForward", "HighBlock", "LowBlock", "HighOof", "LowOof"};
//            case STAFF_CHARACTER:
        } else if (type == CharacterTypes.STAFF_CHARACTER) {
            dir = "src/main/resources/images/StaffCharacter/";
            imgPath = "/images/StaffCharacter/";
            animations = new String[]{"EndBlock", "HighKick", "HighOof", "HighPunch", "Idle"
                    , "StartBlock", "Taunt", "WalkBackward", "WalkForward"};
        }
        for (String animation : animations) {
            String[] currentDir = new File(dir + animation + "/").list();
            assert currentDir != null;
//
            Image[] action = new Image[currentDir.length + 1];

            for (int i = 1; i < (currentDir.length) + 1; i++) {
                try {
                    action[i] = new Image(imgPath + animation + "/" + i + ".png", 92, 221, false, true);


                } catch (Exception e) {
                    System.err.println(dir + animation + "/" + i + ".png");
                    e.printStackTrace();
                }

            }
            sprites.add(action);
            animationMap.put(animation, action);
        }


//        this.moveID = -1;
        this.type = "AI";

        //Init Animations
        //idle


        //            while (true) {
//            }
        Thread thread = new Thread(() -> {
            while (true) {
                moveID = learner.chooseMove(getCurrentPos_x(), getOppPos());
                logger.trace("AI Move registered " + moveMap.get(moveID) + "OpPos" + getOppPos());
                setAnimation(moveID);
                moveCounter++;
                if (moveID!=6&&moveID!=7) {
                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }else{
                    try {
                        Thread.sleep(300);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        });
        animation = new Animation();
        animation.importFrames(animationMap.get("Idle"));
        animation.setDelay(60);
        logger.debug("starting learner thread");
        thread.start();
    }

    @Override
    public void updateHealth(double damage, int hitBox, int currentMoveID) {
        if ((hitBox == 1 && this.moveID != 4) || (hitBox == 0 && this.moveID != 5)) {
            this.health -= damage;
            List<Integer> attackMoves = Arrays.asList(0,1,2,3);
            if (hitBox == 1) {
                //todo may be causing hangs *keep and eye
                while (!animation.hasPlayedOnce()&&!attackMoves.contains(currentMoveID)){
                    break;
//                    try {
//                        Thread.sleep(1);
//                    } catch (InterruptedException e) {
//                        e.printStackTrace();
//                    }
                }
                this.animation.importFrames(animationMap.get("HighOof"));
            } else {
                while (!animation.hasPlayedOnce()&&!attackMoves.contains(currentMoveID)){
                    break;
//                    try {
////                        Thread.sleep(1);
//                    } catch (InterruptedException e) {
//                        e.printStackTrace();
//                    }
                }
                this.animation.importFrames(animationMap.get("LowOof"));
            }

//        logger.debug(this.health);
        }
    }

    @Override
    public double getCurrentPos_x() {
        return this.coordinate.getX();
    }

    private double getOppPos() {
        return this.oppPos;
    }


    public void updateLearner(int oppMove, double oppPos) {
//        if (0<=oppMove && oppMove<=6) {
        learner.update(oppMove);
//        }
        this.oppPos = oppPos;
    }


    public void alterXPos(int delta) {
        if (coordinate.getX() + delta < oppPos) {
            coordinate = new Coordinate(oppPos, coordinate.getY());
        } else {
            coordinate = new Coordinate(coordinate.getX() + delta, coordinate.getY());
        }
        logger.fatal("Updating X Pos" + coordinate.getX());
    }

    private void setAnimation(int id) {
        try {
            if (this.animationMap.get(this.moveMap.get(id).moveName) != null) {
                if (!((animation.getAnimationID() == 6 && id == 6)||(animation.getAnimationID() == 7 && id == 7))) {
                    this.animation.importFrames(this.animationMap.get(this.moveMap.get(id).moveName));
                }
            } else {
                this.animation.importFrames(this.animationMap.get("Idle"));
            }
        } catch (Exception e) {
            this.animation.importFrames(this.animationMap.get("Idle"));
        }
//        this.animation.setDelay(400/this.animation.getFrameArray().length);
    }

    @Override
    public void update() {
        animation.update();
    }

    @Override
    public void render(GraphicsContext g) {
        logger.trace("Rendering AI Character ");
        try {
            if (flipped) {
                g.drawImage(animation.getImage(), 0, 0, animation.getImage().getWidth(), animation.getImage().getHeight(), coordinate.getX() + 185.0d, coordinate.getY(), -animation.getImage().getWidth(), animation.getImage().getHeight());
            } else {
                g.drawImage(animation.getImage(), coordinate.getX()+15, coordinate.getY());
            }
        } catch (NullPointerException ignored) {

        }

    }


//	public void setOppPos(double oppPos){ this.oppPos = oppPos;}


	/*@Override
	public void run() {
		try{
			while(true) {
				moveID = learner.chooseMove(currentPos_x, oppPos);
				learner.update(oppMoveID);
				getMoveID();
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}*/

}
