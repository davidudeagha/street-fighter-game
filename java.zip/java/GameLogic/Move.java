package GameLogic;

/**
 * skeleton class for all player moves in the game
 */
public abstract class Move {
    protected double moveDmg=0;
    protected double moveRange=0;
    protected String moveName="UNSET";
    protected int moveDmgNeg=0;
    protected int rangeMod=0;
    protected int scoreMod=0;

    public int getScoreMod() {
        return scoreMod;
    }

    public int getRangeMod() {
        return rangeMod;
    }

    /**
     * hitbox is where the move attacks i.e. top of character or bottom
     *  0 = bottom
     *  1 = top
     *  -1 = n/a
     */
    protected int hitBox;

    public int getHitBox() {
        return hitBox;
    }

    public double getDamage() {
        return moveDmg;
    }

    public int getMoveDmgNeg() {
        return moveDmgNeg;
    }

    public double getRange() {
        return moveRange;
    }

    @Override
    public String toString() {
        return "Move{" +
                "moveDmg=" + moveDmg +
                ", moveRange=" + moveRange +
                ", moveName='" + moveName + '\'' +
                '}';
    }
}
