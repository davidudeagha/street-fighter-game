package GameLogic;

import Level.RenderedObject;
import Utils.Coordinate;

/**
 * Abstract class for characters to be rendered to the screen,
 * outlines the required methods and implements the ones common to all characters
 */
public abstract class Character extends RenderedObject {

    private static final int MINHEALTH = 0;
    double health;
    
//    double currentPos_x;

    int moveID;
    String type;
    int moveCounter = 0;
    //    double currentPos_y;
    Coordinate coordinate;

    /**
     * Sets the health of the character
     * @param health integer for health to be set to
     */
    public void setHealth(double health) {
        this.health = health;
    }

    /**
     * sets x coordinate of character
     * @param currentPos_x
     */
    public void setCurrentPos_x(double currentPos_x) {
        this.coordinate.setX(currentPos_x);
    }

    /**
     * Sets y coordinate of character
     * @param currentPos_y
     */
    public void setCurrentPos_y(double currentPos_y) {
        this.coordinate = new Coordinate(coordinate.getX(),currentPos_y);
    }

    /**
     * Sets current move ID of player move, used to fetch correct animation files and parse for
     * updating health etc.
     * @param moveID moveId for local moveID to be set to
     */
    public void setMoveID(int moveID) {
        this.moveID = moveID;
    }

    public double getCurrentPos_y() {
        return coordinate.getY();
    }


    public int getMoveCounter() {
        return moveCounter;
    }

    public double getHealth() {
        return health;
    }

    public abstract void updateHealth(double damage, int hitBox, int currentMoveID);

    public double getCurrentPos_x() {
        return this.coordinate.getX();
    }

    public void alterXPos(double position) {
        this.coordinate.setX(coordinate.getX() + position);
    }

    @Override
    public String toString() {
        return "Character{" +
                "health=" + health +
                ", coordinate=" + coordinate +
                ", moveID=" + moveID +
                ", moveCounter=" + moveCounter +
                ", type='" + type + '\'' +
                '}';
    }

    public int getMoveID() {
        return this.moveID;
    }

    public boolean isDead() {
        return health <= MINHEALTH;
    }


}
