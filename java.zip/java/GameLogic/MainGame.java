package GameLogic;

import KeyboardInput.KeyboardInput;
import Level.Background;
import Utils.CharacterTypes;
import Utils.MoveMap;
import javafx.animation.AnimationTimer;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import org.apache.log4j.Logger;

import java.awt.image.BufferedImage;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

//import java.awt.event.KeyEvent;


public class MainGame extends Application {

    static Background bg;
    private HumanCharacter user1;
    private Character user2;
    static Map<Integer, Move> moveMap;

    private static final long serialVersionUID = 1L;

    public static final int WIDTH = 960; //Use WIDTH and SCALE to scale up the window.
    //    public static final int HEIGHT = WIDTH / 16 * 9; //16:9 aspect ratio.
    public static final int HEIGHT = 540;
    public static final int SCALE = 1; //Use WIDTH and SCALE to scale up the window.
    public static final String GAMENAME = "STICKFIGHTER"; //Current working title
    int localU1MoveCounter = 0;
    int localU2MoveCounter = 0;
//    private JFrame frame;
    GraphicsContext g;
    private Pane root = new Pane();

    public boolean running = false;

    private BufferedImage image = new BufferedImage(WIDTH, HEIGHT, BufferedImage.TYPE_INT_RGB);
    //    Graphics2D g = (Graphics2D) image.getGraphics();

//
//    JProgressBar user1HealthBar;
//    JProgressBar user2HealthBar;


    static String p1;
    static String p2;


    Logger logger;

    KeyboardInput input;
    Stage stage;

    public void init(Stage stage) {

        logger = Logger.getLogger(MainGame.class);
        logger.setLevel(org.apache.log4j.Level.DEBUG);
        running = true;
        moveMap = new MoveMap().getMap();


        try {
            System.out.println("Creating Characters");

            if (p1.equals("one") && p2.equals("one")) {
                this.user1 = new HumanCharacter(1);
                this.user2 = new HumanCharacter(2);
            } else {
                this.user1 = new HumanCharacter(1);
                this.user2 = new AICharacter(2, CharacterTypes.REGULAR_CHARACTER);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        bg = new Background("/images/Backgrounds/bg/");

        Scene scene = new Scene(root);

        Canvas canvas = new Canvas(WIDTH * SCALE, HEIGHT * SCALE);
        g = canvas.getGraphicsContext2D();
        stage.setScene(scene);
        stage.setResizable(false);

//        level = new TestLevel();

        root.getChildren().add(canvas);

        scene.setOnKeyPressed(event -> keyPressed(event));
        scene.setOnKeyReleased(event -> keyReleased(event));

    }


    public void update() {
        bg.update();
        this.user1.update();
        this.user2.update();
//        player.update();
    }

    public void render(GraphicsContext g) {
        bg.render(g);
        user1.render(g);
        user2.render(g);
//        player.render(g);
    }

    private void getMoves(int localU1MoveCounter, int localU2MoveCounter, HumanCharacter player1, AICharacter player2) {
        try {
            assert player1 != null;
            if (player1.moveCounter != localU1MoveCounter) {
                logger.warn("player1 move registered by maingame");
                int user1Move = player1.getMoveID();
                this.localU1MoveCounter = player1.moveCounter;
                if (user1Move != 7 && user1Move != 6 && user1Move != -1) {
//                    player2.updateHealth(moveMap.get(user1Move).getDamage(), moveMap.get(user1Move).getHitBox());
                    player2.updateHealth(moveMap.get(user1Move).getDamage(), moveMap.get(user1Move).getHitBox(), player2.getMoveID());
//                    user2HealthBar.setValue(player2.health);

                } else if (user1Move == -1) {

                } else {
                    player1.alterXPos(moveMap.get(user1Move).getRangeMod());
                }
//                        player2.render(g);

                //todo look for blocks (block move or same move opposing)
//                player2.updateHeath(moveMap.get(user1Move).getDamage(), moveMap.get(user1Move).getHitBox());
                player2.updateLearner(user1Move, player1.coordinate.getX());
                if (player2.health <= 0) {
                    logger.fatal("User2 Dead");
//                    JLabel resultLabel = new JLabel();
//                    resultLabel.setText("YOU WIN!");
//                    frame.add(resultLabel, BorderLayout.SOUTH);
//                    frame.pack();
                    running = false;

                }

            }
            assert player2 != null;
            if (player2.moveCounter != localU2MoveCounter) {
                logger.warn("player2 move registered by maingame");
                int user2Move = player2.getMoveID();
                this.localU2MoveCounter = player2.moveCounter;
                if (user2Move != 7 && user2Move != 6) {
                    player1.updateHealth(moveMap.get(user2Move).getDamage(), moveMap.get(user2Move).getHitBox(), player1.getMoveID());
//                    user1HealthBar.setValue(player1.health);
                } else {
                    player2.alterXPos(moveMap.get(user2Move).getRangeMod());
//                        player2.render(g);
                }
            }
            if (player1.health <= 0) {
                logger.fatal("User1 Dead");
//                JLabel resultLabel = new JLabel("", SwingConstants.CENTER);
//                resultLabel.setText("YOU LOSE!");
//                resultLabel.setFont(new Font(resultLabel.getFont().getName(), Font.PLAIN, 50));
//                resultLabel.setSize(new Dimension(50, 20));
//                frame.add(resultLabel, BorderLayout.SOUTH);
//                frame.pack();
                running=false;

            }
            try {
                Thread.sleep(400);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
//                    player2.setOppPos(player1.getCurrentPos_x());


        } catch (
                Exception e) {
            e.printStackTrace();
        }


    }

    private static void getMoves(int localU1MoveCounter, int localU2MoveCounter, HumanCharacter user1, HumanCharacter user2) {
        try {

            while (true) {
                assert user1 != null;
                if (user1.moveCounter != localU1MoveCounter) {
                    int user1Move = user1.getMoveID();
                    localU1MoveCounter = user1.moveCounter;
                }
                assert user2 != null;
                if (user2.moveCounter != localU2MoveCounter) {
                    int user2Move = user2.getMoveID();
                    localU2MoveCounter = user2.moveCounter;

                }

            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    @Override
    public void start(Stage stage) {

        stage.setTitle(GAMENAME);
        init(stage);

        Thread getMovesThread = new Thread(() -> {
            while (true) {
                if (this.user2.getClass().equals(AICharacter.class) && this.user1.getClass().equals(HumanCharacter.class)) {
                    getMoves(localU1MoveCounter, localU2MoveCounter, this.user1, (AICharacter) this.user2);
                } else {
                    getMoves(localU1MoveCounter, localU2MoveCounter, this.user1, (HumanCharacter) this.user2);
                }
            }
        });
        getMovesThread.start();

        AnimationTimer timer = new AnimationTimer() {

            @Override
            public void handle(long now) {
                update();
                g.clearRect(0, 0, WIDTH, HEIGHT);
                render(g);
            }
        };

        timer.start();

        stage.show();
    }




    public static void main(String[] args) {
        try {
            p1 = args[0];
            p2 = args[1];
        } catch (Exception e) {
            p1 = "one";
            p2 = "ai";
        }
        launch(args);
    }

    //    @Override
    public void keyTyped(KeyEvent e) {

    }

    private static Set<String> keysPressed = new HashSet<String>();

    //    @Override
    public void keyPressed(KeyEvent e) {
        logger.setLevel(org.apache.log4j.Level.TRACE);
        keysPressed.add(e.getCode().toString());
        // movement
        logger.trace("Keystroke registered ");
        if (keyPressedHelper('a') && keyPressedHelper('d')) {
            // don't move
            user1.setMoveID(-1);
        } else if (keyPressedHelper('a')) {
            // move backwards
            logger.trace("a registered");
            user1.setMoveID(7);
        } else if (keyPressedHelper('d')) {
            // move forwards
            logger.trace("d registered");
            user1.setMoveID(6);
        }
        // attacks
        if (keyPressedHelper('w')) {
            if (keyPressedHelper('b')) {
                // high block
                logger.trace("w b registered");
                user1.setMoveID(4);
            } else if (keyPressedHelper('k')) {
                // high kick
                logger.trace("w k  registered");
                user1.setMoveID(0);
            } else if (keyPressedHelper('p')) {
                // high punch
                logger.trace("w p registered");
                this.user1.setMoveID(1);
            }
        } else if (keyPressedHelper('s')) {
            if (keyPressedHelper('b')) {
                // low block
                logger.trace("s b registered");
                user1.setMoveID(5);
            } else if (keyPressedHelper('k')) {
                // low kick
                logger.trace("s k registered");
                user1.setMoveID(2);
            } else if (keyPressedHelper('p')) {
                // low punch
                logger.trace("s p registered");
                user1.setMoveID(3);
            }
        }
//        try {
//            Thread.sleep(400);
//        } catch (InterruptedException e1) {
//            e1.printStackTrace();
//        }

    }

    //    @Override
    public void keyReleased(KeyEvent e) {
        keysPressed.remove(e.getCode().toString());
        if (keysPressed.isEmpty()) {
            user1.setMoveID(-1);
        }
    }

//    private int keyID(char key) {
//        switch (key) {
//            case 'w':
//                return ;
//            case 'a':
//                return KeyEvent.VK_A;
//            case 's':
//                return KeyEvent.VK_S;
//            case 'd':
//                return KeyEvent.VK_D;
//            case 'b':
//                return KeyEvent.VK_B;
//            case 'k':
//                return KeyEvent.VK_K;
//            case 'p':
//                return KeyEvent.VK_P;
//            default:
//                return KeyEvent.VK_SPACE;
//        }
//    }

    private boolean keyPressedHelper(char key) {
        return keysPressed.contains(key);
    }


}
