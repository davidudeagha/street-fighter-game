package GameLogic;

public class HighPunch extends Move{

	public HighPunch() {
		this.moveDmg = 4;
		this.moveRange = 1.5;
		this.hitBox =1;
		this.scoreMod = 15;
		this.moveName = "HighPunch";

		// TODO Auto-generated constructor stub
	}
	
}
