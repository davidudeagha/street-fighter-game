package GameLogic;

public class LowPunch extends Move{

	public LowPunch() {
		this.moveDmg = 2.0;
		this.hitBox = 0;
		this.moveRange = 1;
		this.scoreMod = 10;
		this.moveName = "LowPunch";

		// TODO Auto-generated constructor stub
	}
	
}
