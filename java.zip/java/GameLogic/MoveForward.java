package GameLogic;

public class MoveForward extends Move{

    public MoveForward() {
        this.hitBox = -1;
        this.rangeMod = 30;
        this.moveName = "MoveForward";
    }
}
