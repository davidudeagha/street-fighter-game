package GameLogic;

public class Motion {
	Move combat;
	/* 
	 Waiting for Tarun's Physics Code
	 */
}
