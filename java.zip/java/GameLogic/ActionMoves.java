package GameLogic;

public class ActionMoves {
	
	boolean HPunch = false;
	boolean LPunch = false;
	boolean HKick = false;
	boolean LKick = false;
	boolean Block = false;
	int opDmg = 0;
	
	public void highPunch() {
		this.HPunch = true;
	}
	
	public void lowPunch() {
		this.LPunch = true;
	}
	
	public void highKick() {
		this.HKick = true;
	}
	
	public void lowKick() {
		this.LKick = true;
	}
	
	public void blockAttack() {
		this.Block = true;
	}
	
}
