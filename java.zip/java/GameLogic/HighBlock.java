package GameLogic;

public class HighBlock extends Move{


    public HighBlock() {
        this.moveDmgNeg = 50;
        this.hitBox = 1;
        this.scoreMod = 5;
        this.moveName = "HighBlock";
    }
}
