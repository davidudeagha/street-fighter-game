package GameLogic;

public class MoveBackward extends Move{
    public MoveBackward() {
        this.hitBox = -1;
        this.rangeMod = -20;
        this.moveName = "MoveBackwards";
    }
}
