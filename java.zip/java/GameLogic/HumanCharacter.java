package GameLogic;

import RenderEngine.Animation;
import Utils.Coordinate;
import Utils.MoveMap;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;


/**
 * Human-controlled character object. Loads animations and parses keyboard input from Game
 */
public class HumanCharacter extends Character {
    private static Logger logger = Logger.getLogger(HumanCharacter.class);

    /**
     * Maximum health, also used as starting health
     */
    private static final int MAXHEALTH = 100;
    /**
     * Starting x position
     */
    private static final double STARTPOINT_X = 20.0D;
    /**
     * Starting y position
     */
    private static final double STARTPOINT_Y = 250;
    private int playerID;


    Map<String, Image[]> animationMap = new HashMap<>();
    Map<Integer, Move> moveMap = new MoveMap().getMap();

    private boolean flipped = false;

    /**
     * used to set a character to face the opponent
     */
    public void flip() {
        flipped = !flipped;
    }


    public void setPlayerID(int playerID) {
        System.out.println("Changing playerID ");
        this.playerID = playerID;
    }

    public int getPlayerID() {
        return playerID;
    }

    public HumanCharacter(int playerID) {
        this.playerID = playerID;
        logger.setLevel(Level.DEBUG);
//        input = new KeyboardInput();
        this.health = MAXHEALTH;
        if (this.playerID == 1) {
            coordinate = new Coordinate(STARTPOINT_X, STARTPOINT_Y);
        } else {
            coordinate = new Coordinate(700, STARTPOINT_Y);
        }
        logger.trace("Basic Character Created");
        ArrayList<Image[]> sprites = new ArrayList<>();
        String[] animations = new String[]{"HighKick", "HighPunch", "Idle",
                "LowKick", "LowPunch", "WalkForward", "HighBlock", "LowBlock", "HighOof", "LowOof"};
        for (String animation : animations) {
            String[] currentDir = new File("src/main/resources/images/RegularCharacter/" + animation + "/").list();
            assert currentDir != null;
            Image[] action = new Image[currentDir.length + 1];
            // currentDir.length/2 as the folder will contain png and gif files
            for (int i = 1; i < (currentDir.length) + 1; i++) {
                try {
                    action[i] = new Image("/images/RegularCharacter/" + animation + "/" + i + ".png", 92, 221, false, true);//                    double h = before.getHeight();
//                    Image after = new Image(w, h, Image);
//                    AffineTransform at = new AffineTransform();
//                    at.scale(0.25, 0.25);
////                    at.scale(1, 1);
//                    AffineTransformOp scaleOp =
//                            new AffineTransformOp(at, AffineTransformOp.TYPE_BILINEAR);
//                    after = scaleOp.filter(before, after);
//                    action[i] = after;

                } catch (Exception e) {
                    System.err.println("src/main/resources/images/" + animation + "/" + i + ".gif");
                    e.printStackTrace();
                }

            }
            sprites.add(action);
            animationMap.put(animation, action);
        }

//        this.moveID = -1;


        this.type = "Human";
        this.animation = new Animation();

        this.animation.importFrames(this.animationMap.get("Idle"));
        animation.setIdle(true);
        this.animation.setDelay(60);


    }

    public void updateHealth(double damage, int hitBox, int currentMoveID) {
        logger.debug("updating health" + this.moveID);
        if ((hitBox == 1 && this.moveID != 4) || (hitBox == 0 && this.moveID != 5)) {
            this.health -= damage;
            if (hitBox == 1) {
                this.animation.importFrames(animationMap.get("HighOof"));
                animation.setIdle(true);
            } else {
                this.animation.importFrames(animationMap.get("LowOof"));
                animation.setIdle(true);
            }

//        logger.debug(this.health);
        }else{
            logger.debug("Player"+playerID+" blocked a move");
        }
    }

    public void setMove(int id){
        this.moveID = id;
        moveCounter++;
    }

//    public void alterXPos(int delta) {
////        if (this.currentPos_x + delta < oppPos) {
////            this.currentPos_x = oppPos;
////        } else {
//        this.currentPos_x += delta;
//    }

//        logger.fatal("Updating X Pos" + currentPos_x);

    private void setAnimation(int id) {
        try {
            if (this.animationMap.get(this.moveMap.get(id).moveName) != null) {
                if (animation.isIdle()) {
                    this.animation.importFrames(this.animationMap.get(this.moveMap.get(id).moveName));
                } else if (!animation.hasPlayedOnce()) {
                    System.err.println("animation locked");
                } else {
                    this.animation.importFrames(this.animationMap.get(this.moveMap.get(id).moveName));
                }
                animation.setIdle(false);
            } else {
                this.animation.importFrames(this.animationMap.get("Idle"));
                animation.setIdle(true);
            }
        } catch (Exception e) {
            this.animation.importFrames(this.animationMap.get("Idle"));
            animation.setIdle(true);
        }
//        this.animation.setDelay(10);

    }

    @Override
    public void update() {
        animation.update();
    }


    @Override
    public void render(GraphicsContext g) {
        logger.trace("Rendering Basic Character ");
        if (animation.hasPlayedOnce()&&!animation.isIdle()){
            animation.importFrames(animationMap.get("Idle"));
            animation.setIdle(true);
        }
        if (flipped) {
            g.drawImage(animation.getImage(), 0, 0, animation.getImage().getWidth(), animation.getImage().getHeight(), coordinate.getX() + 185, coordinate.getY(), -animation.getImage().getWidth(), animation.getImage().getHeight());
        } else {
            g.drawImage(animation.getImage(), coordinate.getX()+15, coordinate.getY());
        }
    }


	/*@Override
	public void run() {
		try{d
			while(true) {
				moveID = input.getMoveID();
				getMoveID();
				input.setMoveID(-1);
			
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}*/


    public void setMoveID(int ID) {
        if (animation.isIdle() || animation.hasPlayedOnce()) {
            this.moveID = ID;
            setAnimation(ID);
            logger.debug("Updating move counter");
            moveCounter++;
        }
    }

    public int getMoveID() {
        return this.moveID;
    }


}

