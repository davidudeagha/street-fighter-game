package GameLogic;

public class HighKick extends Move{

	public HighKick() {
		this.moveDmg = 3;
		this.moveRange = 1.5;
		this.hitBox= 1;
		this.scoreMod = 20;
		this.moveName = "HighKick";
		// TODO Auto-generated constructor stub
	}
	
}
