package GameLogic;

public class LowKick extends Move {

	public LowKick() {
		this.moveDmg = 3.4;
		this.hitBox = 0;
		this.moveRange = 1;
		this.scoreMod = 5;
		this.moveName = "LowKick";
		// TODO Auto-generated constructor stub
	}
	
}