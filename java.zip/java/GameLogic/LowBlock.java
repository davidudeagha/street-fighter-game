package GameLogic;

public class LowBlock extends Move {
    public LowBlock() {
        this.moveDmgNeg = 50;
        this.hitBox = 0;
        this.moveRange = 0;
        this.scoreMod = 5;
        this.moveName = "LowBlock";
    }
}
