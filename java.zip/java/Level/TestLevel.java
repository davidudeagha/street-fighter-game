package Level;

import javafx.scene.canvas.GraphicsContext;

public class TestLevel extends Level {
	
	private Background bg;
	private Player player;
	private Player player2;
	
	public TestLevel() { //Just a test level
		init();
	}

	@Override
	public int getWinner() {
		return 0;
	}

	public void init() {
		bg = new Background("/images/backgrounds/bg");
		bg.setMovementAmount(0, 0);
		player = new Player(125.0d, 355.0d, 0);
		player2 = new Player(635.0d, 355.0d, 1);
	}

	public void update() {
		bg.update();
		player.update();
		player2.update();
		
		if (player.intersects(player2)) {
			System.out.println("COLLISION!");
		}
	}

	@Override
	public boolean isRunning() {
		return false;
	}

	@Override
	public double getPlayerScore() {
		return 0;
	}

	public void render(GraphicsContext g) {
		bg.render(g);
		player.render(g);
		player2.render(g);
	}

	@Override
	public void parseMoves(PlayerHealthBar p1,PlayerHealthBar p2) {

	}

	public void keyPressed(String k) {
		if (k.equals("A")) {
			player.setLeft(true);
		}
		
		if(k.equals("D")) {
			player.setRight(true);
		}
		
		if (k.equals("Q")) {
			player.setPunch(true);
		}

		if (k.equals("P")) {
			player2.setPunch(true);
		}
		
		if (k.equals("RIGHT")) {
			player2.setRight(true);
		}
		
		if (k.equals("LEFT")) {
			player2.setLeft(true);
		}
		
		
	}
	
	public void keyReleased(String k) {
		if (k.equals("A")) {
			player.setLeft(false);
		}
		
		if(k.equals("D")) {
			player.setRight(false);
		}
		
		if (k.equals("Q")) {
			player.setPunch(false);
		}
		
		if (k.equals("P")) {
			player2.setPunch(false);
		}
		
		if (k.equals("RIGHT")) {
			player2.setRight(false);
		}
		
		if (k.equals("LEFT")) {
			player2.setLeft(false);
		}
	}
}