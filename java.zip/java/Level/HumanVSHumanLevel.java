package Level;

import Audio.Audio;
import GameLogic.HumanCharacter;
import GameLogic.Move;
import Network.Client4Two;
import Network.UpdatePacket;
import Utils.MoveMap;
import javafx.scene.canvas.GraphicsContext;
import org.apache.log4j.Logger;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import static java.lang.Math.abs;

public class HumanVSHumanLevel extends Level {
    private Background bg;
    private int winner = 0;
    private HumanCharacter player1;
    private HumanCharacter player2;
    private Logger logger = Logger.getLogger(HumanVSHumanLevel.class);
    private int roomNumber;
    private Client4Two client;

    private Audio audio;

    public HumanVSHumanLevel(int roomNumber) {
        this.roomNumber = roomNumber;
        init();
    }

    @Override
    public int getWinner() {
        return 0;
    }

    @Override
    public void init() {
        // connect to room & create object to receive update packets via
        bg = new Background("/images/Backgrounds/bg/");
        bg.setMovementAmount(0, 0);
        player1 = new HumanCharacter(1);
        player2 = new HumanCharacter(2);
        client = new Client4Two(createUpdatePacket());

//        try {
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//Kexin comment it: I think these two part of code shouldn't work with match() at same time.
//I think we can give a parameter to tell Level should use which mode
//or only use match mode for now
//it works, separately
        //---------------start of create & join mode---------------
//        Thread networkThread = new Thread(() -> {
//            try {
//                client.createRoom(roomNumber);
//                client.joinRoom(roomNumber);
////                Thread.sleep(400);
////                Thread.sleep(400);
//            } catch (Exception ignored) {
//            }
//        });
//        networkThread.start();
        //---------------end of create & join mode---------------


        //---------------start of match mode---------------
        Thread mainNetworkThread = new Thread(() -> {
//            System.out.println("Starting main network thread");
            try {
                audio = new Audio();
                audio.playBGM();
                client.match();

            } catch (Exception e) {
                e.printStackTrace();
            }
        });
        mainNetworkThread.start();
        //---------------start of match mode---------------
        try {
            Thread.sleep(300);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        if (client.connectedFirst()) {
//            System.err.println("Connected first hvh");
            player1 = new HumanCharacter(1);
            player2 = new HumanCharacter(2);
            player2.flip();
            client.setUpdatePacket(createUpdatePacket());
        }else{
//            System.err.println("Player2");
            player2 = new HumanCharacter(1);
            player1 = new HumanCharacter(2);
            player1.flip();
            client.setUpdatePacket(createUpdatePacket());
        }

//        try {
//            mainNetworkThread.join();

//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }

    }

    @Override
    public void update() {
        bg.update();
        //update using local data for locally controlled things & using data from update packet
        unpackUpdatePacket(client.getOpponent());
        client.setUpdatePacket(createUpdatePacket());
        player1.update();
        player2.update();
    }

    @Override
    public boolean isRunning() {
        return true;
    }

    @Override
    public double getPlayerScore() {
        return 0;
    }

    @Override
    public void render(GraphicsContext g) {
        //same as other levels
        bg.render(g);
        player1.render(g);
        player2.render(g);
    }

    private static Set<String> keysPressed = new HashSet<>();

    private int localU1MoveCounter, localU2MoveCounter = 0;
    private Map<Integer, Move> moveMap = new MoveMap().getMap();

    private void moveCharacter(int amount, HumanCharacter p1, HumanCharacter p2) {
        try {
            if(p1.getPlayerID()==1) {
                if (p1.getCurrentPos_x() + amount >= p2.getCurrentPos_x()) {
                    moveCharacter(amount / 2, p1, p2);
                } else {
                    p1.alterXPos(amount);
                }
            }else{
                if (p1.getCurrentPos_x() - amount <= p2.getCurrentPos_x()) {
                    moveCharacter(amount / 2, p1, p2);
                } else {
                    p1.alterXPos(-amount);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            // (the original exception is StackOverflowError)
            // If it print any exception just contact Kexin.
            // Kexin comment the line below at 22/03/19, add printStackTrace()
//            moveCharacter(-amount,p1, p2);
        }

    }


    @Override
    public void parseMoves(PlayerHealthBar p1, PlayerHealthBar p2) {
//        logger.debug("Parsing Moves");
        try {
            localU1MoveCounter = registerMove(p1, player1, player2, localU1MoveCounter);
//            localU2MoveCounter = registerMove(p2, player2, player1, localU2MoveCounter);
            p1.setValue(player1.getHealth()/100);
            p2.setValue(player2.getHealth()/100);
//            try {
//                Thread.sleep(400);
//            } catch (InterruptedException e) {
//                e.printStackTrace();
//            }
//                    player2.setOppPos(player1.getCurrentPos_x());


        } catch (
                Exception e) {
            e.printStackTrace();
        }


    }

    private int registerMove(PlayerHealthBar p2, HumanCharacter player1, HumanCharacter player2, int moveCounter) {
        assert player1 != null;

        if (player1.getMoveCounter() != moveCounter) {
            int player1Move = player1.getMoveID();
            moveCounter = player1.getMoveCounter();
            if (player1Move != -1) {
                if (player1Move != 7 && player1Move != 6) {
//                    player2.updateHealth(moveMap.get(player1Move).getDamage(), moveMap.get(player1Move).getHitBox());
                    if (moveMap.get(2).getRange() >= abs(player1.getCurrentPos_x() - player2.getCurrentPos_x())) {
                        player2.updateHealth(moveMap.get(player1Move).getDamage(), moveMap.get(player1Move).getHitBox(), player2.getMoveID());
                        p2.setValue((double) player2.getHealth() / 100);

                    }
//                    player2HealthBar.setValue(player2.health);

                } else {
//                    player1.alterXPos(moveMap.get(player1Move).getRangeMod());
                    moveCharacter(moveMap.get(player1Move).getRangeMod(), player1, player2);


                }
//                logger.debug("Setting update packet");
                client.setUpdatePacket(createUpdatePacket());

            }
//                        player2.render(g);


//                player2.updateHeath(moveMap.get(player1Move).getDamage(), moveMap.get(player1Move).getHitBox());

            if (player2.isDead()) {
                winner=1;
                logger.fatal("player2 Dead");

//                    JLabel resultLabel = new JLabel();
//                    resultLabel.setText("YOU WIN!");
//                    frame.add(resultLabel, BorderLayout.SOUTH);
//                    frame.pack();
//                    running = false;
                audio.winSound();
            }

        }
        return moveCounter;
    }


    @Override
    public void keyPressed(String toString) {
        logger.setLevel(org.apache.log4j.Level.TRACE);
        keysPressed.add(toString.toLowerCase());
        // movement
        logger.trace("Keystroke registered by HVCLevel " + toString);

        if (keyPressedHelper("a") && keyPressedHelper("d")) {
            // don't move
            player1.setMoveID(-1);
        } else if (keyPressedHelper("a")) {
            // move backwards
            logger.trace("a registered");
            player1.setMoveID(7);
        } else if (keyPressedHelper("d")) {
            // move forwards
            logger.trace("d registered");
            player1.setMoveID(6);
        }
        // attacks
        if (keyPressedHelper("w")) {
            if (keyPressedHelper("b")) {
                // high block
                logger.trace("w b registered");
                player1.setMoveID(4);
            } else if (keyPressedHelper("k")) {
                // high kick
                logger.trace("w k  registered");
                player1.setMoveID(0);
                audio.highKickSound();
            } else if (keyPressedHelper("p")) {
                // high punch
                logger.trace("w p registered");
                this.player1.setMoveID(1);
                audio.punchSound();
            }
        } else if (keyPressedHelper("s")) {
            if (keyPressedHelper("b")) {
                // low block
                logger.trace("s b registered");
                player1.setMoveID(5);
            } else if (keyPressedHelper("k")) {
                // low kick
                logger.trace("s k registered");
                player1.setMoveID(2);
                audio.lowKickSound();
            } else if (keyPressedHelper("p")) {
                // low punch
                logger.trace("s p registered");
                player1.setMoveID(3);
                audio.punchSound();
            }
        }
//        parseMoves();

//        try {
//            Thread.sleep(400);
//        } catch (InterruptedException e1) {
//            e1.printStackTrace();
//        }

    }

    private boolean keyPressedHelper(String key) {
        return keysPressed.contains(key);
    }

    @Override
    public void keyReleased(String toString) {
        keysPressed.remove(toString.toLowerCase());
        if (keysPressed.isEmpty()) {
            player1.setMoveID(-1);
        }
    }


    private UpdatePacket createUpdatePacket() {
        return new UpdatePacket(player1.getCurrentPos_x(), player1.getCurrentPos_y(), player2.getHealth(), player1.getMoveID(),player1.getPlayerID());
    }

    private void unpackUpdatePacket(UpdatePacket packet) {
        try {
            logger.debug("Unpacking update packet");
            logger.debug(packet);
            if (packet.getPlayerID() == 1) {
                if (player1.getPlayerID() != 2 && !client.connectedFirst()) {
//                    System.err.println("I am player2 ");
                    player1 = new HumanCharacter(2);
                    player2 = new HumanCharacter(1);
                }
            }
            player2.setCurrentPos_x(packet.getX());
//            player2.setCurrentPos_y(packet.getY());
            player2.setMoveID(packet.getMoveID());
            if (packet.getMoveID()!=-1) {
                player1.updateHealth(packet.getHealth()-player1.getHealth(), moveMap.get(packet.getMoveID()).getHitBox(), player1.getMoveID());
                player1.setHealth(packet.getHealth());
                if (player1.getHealth()<=0){
                    winner=2;
                    //todo running=false
                }
            }
            player2.setMoveID(packet.getMoveID());
//            update();
//            player1.setHealth(packet.getHealth());
        } catch (Exception ignored) {
            logger.trace("Waiting for opponent");
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

//            ignored.printStackTrace();
        }
    }

}
