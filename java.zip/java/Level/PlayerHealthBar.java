package Level;

import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.shape.StrokeType;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;


public class PlayerHealthBar extends Pane {

    private Rectangle outerHealthRect;
    private Rectangle innerHealthRect;
    private Text currentHealth;
    private double x;
    private double y;

    public double getX() {
        return x;
    }

    public double getY() {
        return y;
    }

    public void setX(double x) {
        this.x = x;
    }

    public void setY(double y) {
        this.y = y;
    }

    public PlayerHealthBar() {

        double height = 30;

        double outerWidth = 240;
        double innerWidth = 160;

        x = 0.0;
        y = 0.0;
        outerHealthRect = new Rectangle(x, y, outerWidth, height);
        outerHealthRect.setStroke(Color.BLACK);
        outerHealthRect.setStrokeWidth(2);
        outerHealthRect.setStrokeType(StrokeType.OUTSIDE);
        outerHealthRect.setFill(Color.RED);


        innerHealthRect = new Rectangle(x, y, innerWidth, height);
        innerHealthRect.setStrokeType(StrokeType.OUTSIDE);
        innerHealthRect.setFill(Color.LIMEGREEN);


        currentHealth = new Text(x+(outerWidth/2), y+(height/2), "100");
        currentHealth.setStrokeType(StrokeType.OUTSIDE);
        currentHealth.setTextAlignment(TextAlignment.CENTER);

        getChildren().addAll(currentHealth, outerHealthRect, innerHealthRect);

    }

    public void setValue(double value) {
        currentHealth.setText(String.valueOf(value * 100));
        innerHealthRect.setWidth(outerHealthRect.getWidth() * value);
    }

}
