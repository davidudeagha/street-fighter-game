package Level;

import GameLogic.AICharacter;
import GameLogic.HumanCharacter;
import GameLogic.Move;
import Network.SaveScores;
import Utils.CharacterTypes;
import Utils.MoveMap;
import javafx.scene.canvas.GraphicsContext;
import org.apache.log4j.Logger;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import static java.lang.Math.abs;

public class HumanVSAILevel extends Level {
    private boolean running;
    private int winner = 0;
    private Background bg;
    private HumanCharacter player1;
    private AICharacter player2;
    private double playerScore = 0;
    private double playerModifier = 1.0;
    private String username;

    private Logger logger = Logger.getLogger(HumanVSAILevel.class);

    /**
     * Level class that sets up a game for a human against an AI
     */
    public HumanVSAILevel(String username) {
        this.username = username;
        init();
    }

    @Override
    public int getWinner() {
        return winner;
    }

    public void init() {
        running=true;
        bg = new Background("/images/Backgrounds/bg/");
        bg.setMovementAmount(0, 0);
        player1 = new HumanCharacter(1);
        player2 = new AICharacter(2, CharacterTypes.REGULAR_CHARACTER);
        player2.flip();
    }

    public void update() {
//        logger.trace(player1.getCurrentPos_x() + " p2:  "  + player2.getCurrentPos_x() + "in range: " + (moveMap.get(2).getRange() >= abs(player1.getCurrentPos_x() - player2.getCurrentPos_x())));
        bg.update();
        player1.update();
        player2.update();

    }

    @Override
    public boolean isRunning() {
        return running;
    }

    public void render(GraphicsContext g) {
        bg.render(g);
        player1.render(g);
        player2.render(g);
    }


    private static Set<String> keysPressed = new HashSet<>();

    private int localU1MoveCounter, localU2MoveCounter;
    private Map<Integer, Move> moveMap = new MoveMap().getMap();

    private void moveCharacter(int amount, HumanCharacter p1, AICharacter p2) {

        if (p1.getCurrentPos_x() + amount > p2.getCurrentPos_x()) {
            moveCharacter(amount / 2, p1, p2);
        } else {
            p1.alterXPos(amount);
        }

    }

    private void moveCharacter(int amount, AICharacter p1, HumanCharacter p2) {

        if (p1.getCurrentPos_x() + amount < p2.getCurrentPos_x()) {
            moveCharacter(amount / 2, p1, p2);
        } else {
            p1.alterXPos(amount);
        }

    }


    public double getPlayerScore() {
        return playerScore;
    }

    @Override
    public void parseMoves(PlayerHealthBar p1, PlayerHealthBar p2) {
        logger.debug("parsing moves ");
//        try {
//        assert player1 != null;

        if (player1.getMoveCounter() != localU1MoveCounter) {
            int player1Move = player1.getMoveID();
            localU1MoveCounter = player1.getMoveCounter();
            if (player1Move != 7 && player1Move != 6 && player1Move != -1) {
//                    player2.updateHealth(moveMap.get(player1Move).getDamage(), moveMap.get(player1Move).getHitBox());
                if (moveMap.get(player1Move).getRange() >= abs(player1.getCurrentPos_x() - player2.getCurrentPos_x())) {
                    double beforeHealth = player2.getHealth();
                    player2.updateHealth(moveMap.get(player1Move).getDamage(), moveMap.get(player1Move).getHitBox(), player2.getMoveID());
                    p2.setValue(player2.getHealth() / 100);
                    if (player2.getHealth() != beforeHealth) {
                        logger.debug("Increasing player score");
                        playerScore += playerModifier * moveMap.get(player1Move).getScoreMod();
                        playerModifier += 0.2;
                    } else {
                        playerModifier = 1;
                    }
                }
//                    player2HealthBar.setValue(player2.health);

            } else if (player1Move != -1) {
//                    player1.alterXPos(moveMap.get(player1Move).getRangeMod());
                moveCharacter(moveMap.get(player1Move).getRangeMod(), player1, player2);


            }
//                        player2.render(g);


//                player2.updateHeath(moveMap.get(player1Move).getDamage(), moveMap.get(player1Move).getHitBox());
            logger.trace("Updating learner");
            player2.updateLearner(player1Move, player1.getCurrentPos_x());
        }
        logger.debug("Checking if player2 is dead");
        if (player2.isDead()) {
            winner=1;
            logger.fatal("player2 Dead");
            saveScores();

//                    JLabel resultLabel = new JLabel();
//                    resultLabel.setText("YOU WIN!");
//                    frame.add(resultLabel, BorderLayout.SOUTH);
//                    frame.pack();
//                    running = false;


        }
//                player1.setMove(-1);
//                player1.animation.importFrames(anim);


//        assert player2 != null;
        if (player2.getMoveCounter() != localU2MoveCounter) {
//				logger.warn("player2 move registered by maingame");
            int player2Move = player2.getMoveID();
            this.localU2MoveCounter = player2.getMoveCounter();
            if (player2Move != 7 && player2Move != 6) {
                if (player1.getMoveID() != -1) {
                    if ((moveMap.get(player1.getMoveID()).getHitBox() == 1 && player1.getMoveID() != 4) || ((moveMap.get(player1.getMoveID()).getHitBox() == 0 && player1.getMoveID() != 5))) {
                        playerModifier = 1;
                        player1.updateHealth(moveMap.get(player2Move).getDamage(), moveMap.get(player2Move).getHitBox(), player1.getMoveID());
                        p1.setValue(player1.getHealth() / 100);
                    } else {
                        logger.debug("Move blocked by player1");
                        logger.debug("Increasing player score");
                        playerScore += playerModifier * moveMap.get(player1.getMoveID()).getScoreMod();
                        playerModifier += 0.2;
                    }
                } else {
                    player1.updateHealth(moveMap.get(player2Move).getDamage(), moveMap.get(player2Move).getHitBox(), player1.getMoveID());
                    p1.setValue(player1.getHealth() / 100);
                }
//                    player1HealthBar.setValue(player1.health);
            } else {
//                    player2.alterXPos(moveMap.get(player2Move).getRangeMod());
//                        player2.render(g);

                moveCharacter(moveMap.get(player2Move).getRangeMod(), player2, player1);
//                    if ((player2.getCurrentPos_x()+moveMap.get(player2Move).getRangeMod()>player2.getCurrentPos_x())){
//                        player2.alterXPos(player1.getCurrentPos_x()-5);
//                    }else {
//                        player2.alterXPos(moveMap.get(player2Move).getRangeMod());
//                    }
            }
        }
        logger.debug("Checking if player1 is dead");
        if (player1.isDead()) {
            winner=2;
            logger.fatal("player1 Dead");
            saveScores();

//                JLabel resultLabel = new JLabel("", SwingConstants.CENTER);
//                resultLabel.setText("YOU LOSE!");
//                resultLabel.setFont(new Font(resultLabel.getFont().getName(), Font.PLAIN, 50));
//                resultLabel.setSize(new Dimension(50, 20));
//                frame.add(resultLabel, BorderLayout.SOUTH);
//                frame.pack();
//                running=false;

        }
//            try {
//                Thread.sleep(400);
//            } catch (InterruptedException e) {
//                e.printStackTrace();
//            }
//                    player2.setOppPos(player1.getCurrentPos_x());


//        } catch (
//                Exception e) {
//            e.printStackTrace();
//        }


    }

    private void saveScores() {
        logger.debug("Saving scores");
        SaveScores ss = new SaveScores();
        ss.save(username, playerScore);
//        System.exit(0);
        running=false;

    }

    @Override
    public void keyPressed(String toString) {
        logger.setLevel(org.apache.log4j.Level.DEBUG);
        keysPressed.add(toString.toLowerCase());
        // movement
        logger.trace("Keystroke registered by HVCLevel " + toString);

        if (keyPressedHelper("a") && keyPressedHelper("d")) {
            // don't move
            player1.setMoveID(-1);
        } else if (keyPressedHelper("a")) {
            // move backwards
            logger.trace("a registered");
            player1.setMoveID(7);
        } else if (keyPressedHelper("d")) {
            // move forwards
            logger.trace("d registered");
            player1.setMoveID(6);
        }
        // attacks
        if (keyPressedHelper("w")) {
            if (keyPressedHelper("b")) {
                // high block
                logger.trace("w b registered");
                player1.setMoveID(4);
            } else if (keyPressedHelper("k")) {
                // high kick
                logger.trace("w k  registered");
                player1.setMoveID(0);
            } else if (keyPressedHelper("p")) {
                // high punch
                logger.trace("w p registered");
                this.player1.setMoveID(1);
            }
        } else if (keyPressedHelper("s")) {
            if (keyPressedHelper("b")) {
                // low block
                logger.trace("s b registered");
                player1.setMoveID(5);
            } else if (keyPressedHelper("k")) {
                // low kick
                logger.trace("s k registered");
                player1.setMoveID(2);
            } else if (keyPressedHelper("p")) {
                // low punch
                logger.trace("s p registered");
                player1.setMoveID(3);
            }
        }
//        parseMoves();

//        try {
//            Thread.sleep(400);
//        } catch (InterruptedException e1) {
//            e1.printStackTrace();
//        }

    }

    private boolean keyPressedHelper(String key) {
        return keysPressed.contains(key);
    }

    @Override
    public void keyReleased(String toString) {
        keysPressed.remove(toString.toLowerCase());
        if (keysPressed.isEmpty()) {
            player1.setMoveID(-1);
        }
    }


}
