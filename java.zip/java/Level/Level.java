package Level;

import GameLogic.AICharacter;
import GameLogic.HumanCharacter;
import javafx.scene.canvas.GraphicsContext;

public abstract class Level {
    private int winner = 0;
    private boolean running;
    private Background bg;
    private HumanCharacter player1;
    private AICharacter player2;

    public abstract int getWinner();

    public abstract void init();

    public abstract void update();

    public abstract boolean isRunning();

    public abstract double getPlayerScore();

    /**
     * renders all objects extending RenderedObject class instantiated within the level
     *
     * @param g
     */
    public abstract void render(GraphicsContext g);

    /**
     * unpacks moves and applies required effects (changes in health, position etc.)
     *
     * @param p1 health bar for player1, defined in Game so must be passed in in order to be updated with correct value
     * @param p2 "" for player2
     */
    public abstract void parseMoves(PlayerHealthBar p1, PlayerHealthBar p2);

    public abstract void keyPressed(String toString);

    public abstract void keyReleased(String toString);
}
