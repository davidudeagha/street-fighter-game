package Level;

import GameLogic.AICharacter;
import GameLogic.Move;
import Utils.CharacterTypes;
import Utils.MoveMap;
import javafx.scene.canvas.GraphicsContext;
import org.apache.log4j.Logger;

import java.util.Map;

public class AIVSAILevel extends Level {

    private Background bg;
    private AICharacter player1;
    private AICharacter player2;
    private Logger logger = Logger.getLogger(AIVSAILevel.class);

    public AIVSAILevel() {
        init();
    }

    @Override
    public int getWinner() {
        return 0;
    }

    @Override
    public void init() {
        bg = new Background("/images/Backgrounds/bg/");
        bg.setMovementAmount(0, 0);
        player1 = new AICharacter(1, CharacterTypes.REGULAR_CHARACTER);
        player2 = new AICharacter(2,CharacterTypes.REGULAR_CHARACTER);
        player1.flip();
    }

    @Override
    public void update() {
        bg.update();
        player1.update();
        player2.update();
    }

    @Override
    public boolean isRunning() {
        return true;
    }

    @Override
    public double getPlayerScore() {
        return 0;
    }

    @Override
    public void render(GraphicsContext g) {
        bg.render(g);
        player1.render(g);
        player2.render(g);
    }

    @Override
    public void keyPressed(String toString) {

    }

    @Override
    public void keyReleased(String toString) {

    }


    private int localU1MoveCounter, localU2MoveCounter;
    private Map<Integer, Move> moveMap = new MoveMap().getMap();

    //    private void moveCharacter(int amount, AICharacter p1, AICharacter p2) {
//
//        if (p1.getCurrentPos_x() + amount < p2.getCurrentPos_x()) {
//            moveCharacter(amount / 2, p1, p2);
//        } else {
//            p1.alterXPos(amount);
//        }
//
//    }
    private void moveCharacter(int amount, AICharacter p1, AICharacter p2) {
        try {
            if (p1.isFlipped()) {
                if (p1.getCurrentPos_x() + amount > p2.getCurrentPos_x()) {
                    moveCharacter(amount / 2, p1, p2);
                } else {
                    p1.alterXPos(amount);
                }
            } else {
                if (p1.getCurrentPos_x() - amount < p2.getCurrentPos_x()) {
                    moveCharacter(amount / 2, p1, p2);
                } else {
                    p1.alterXPos(-amount);
                }
            }
        } catch (StackOverflowError e) {
            moveCharacter(-amount, p1, p2);
        }

    }



    @Override
    public void parseMoves(PlayerHealthBar p1, PlayerHealthBar p2) {
        try {
            assert player1 != null;

            if (player1.getMoveCounter() != localU1MoveCounter) {
                int player1Move = player1.getMoveID();
                localU1MoveCounter = player1.getMoveCounter();
                if (player1Move != 7 && player1Move != 6 && player1Move != -1) {
//                    player2.updateHealth(moveMap.get(player1Move).getDamage(), moveMap.get(player1Move).getHitBox());

                    if (moveMap.get(player1Move).getRange() >= (player1.getCurrentPos_x() - player2.getCurrentPos_x())) {

                        player2.updateHealth(moveMap.get(player1Move).getDamage(), moveMap.get(player1Move).getHitBox(),player2.getMoveID());

                        p2.setValue((double) player2.getHealth() / 100);
                    }
//                    player2HealthBar.setValue(player2.health);

                } else if (player1Move == -1) {

                } else {
//                    player1.alterXPos(moveMap.get(player1Move).getRangeMod());
                    moveCharacter(moveMap.get(player1Move).getRangeMod(), player1, player2);


                }
//                        player2.render(g);


//                player2.updateHeath(moveMap.get(player1Move).getDamage(), moveMap.get(player1Move).getHitBox());
                player2.updateLearner(player1Move, player1.getCurrentPos_x());
                if (player2.isDead()) {
                    logger.fatal("player2 Dead");
//                    JLabel resultLabel = new JLabel();
//                    resultLabel.setText("YOU WIN!");
//                    frame.add(resultLabel, BorderLayout.SOUTH);
//                    frame.pack();
//                    running = false;


                }

            }
            assert player2 != null;
            if (player2.getMoveCounter() != localU2MoveCounter) {
//				logger.warn("player2 move registered by maingame");
                int player2Move = player2.getMoveID();
                this.localU2MoveCounter = player2.getMoveCounter();
                if (player2Move != 7 && player2Move != 6) {
                    player1.updateHealth(moveMap.get(player2Move).getDamage(), moveMap.get(player2Move).getHitBox(), player1.getMoveID());
                    System.out.println("updating player1healthbar");
                    p1.setValue(player1.getHealth() / 100);
//                    player1HealthBar.setValue(player1.health);
                } else {
//                    player2.alterXPos(moveMap.get(player2Move).getRangeMod());
//                        player2.render(g);

                    moveCharacter(moveMap.get(player2Move).getRangeMod(), player2, player1);
//                    if ((player2.getCurrentPos_x()+moveMap.get(player2Move).getRangeMod()>player2.getCurrentPos_x())){
//                        player2.alterXPos(player1.getCurrentPos_x()-5);
//                    }else {
//                        player2.alterXPos(moveMap.get(player2Move).getRangeMod());
//                    }
                }
                player1.updateLearner(player2Move, player2.getCurrentPos_x());


                if (player1.isDead()) {
                    logger.fatal("player1 Dead");
//                JLabel resultLabel = new JLabel("", SwingConstants.CENTER);
//                resultLabel.setText("YOU LOSE!");
//                resultLabel.setFont(new Font(resultLabel.getFont().getName(), Font.PLAIN, 50));
//                resultLabel.setSize(new Dimension(50, 20));
//                frame.add(resultLabel, BorderLayout.SOUTH);
//                frame.pack();
//                running=false;

                }
            }
//            try {
//                Thread.sleep(400);
//            } catch (InterruptedException e) {
//                e.printStackTrace();
//            }
//                    player2.setOppPos(player1.getCurrentPos_x());


        } catch (
                Exception e) {
            e.printStackTrace();
        }


    }
}
