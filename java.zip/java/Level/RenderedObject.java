package Level;

import RenderEngine.Animation;
import javafx.scene.canvas.GraphicsContext;

/**
 * implemented by all classes that need to be rendered to the screen
 */
public abstract class RenderedObject {
	
	protected Animation animation;

	public abstract void update();	
	public abstract void render(GraphicsContext g);
}