package Network;

import java.io.Serializable;

public class UpdatePacket implements Serializable {

    private double x;
    private double y;

    @Override
    public String toString() {
        return "UpdatePacket{" +
                "x=" + x +
                ", y=" + y +
                ", playerID=" + playerID +
                ", health=" + health +
                ", moveID=" + moveID +
                '}';
    }

    private int playerID = 1;
    private double health;

    private int moveID;

    public int getPlayerID() {
        return playerID;
    }

    public void setPlayerID(int playerID) {
        this.playerID = playerID;
    }

    /**
     * @param x      X position of character
     * @param y      Y position of character
     * @param health health of opponent character (player character of client that unpacks it)
     * @param moveID current move character is making
     */
    public UpdatePacket(double x, double y, double health, int moveID, int playerID) {
        this.x = x;
        this.y = y;
        this.health = health;
        this.moveID = moveID;
        this.playerID = playerID;
    }


    public double getX() {
        return x;
    }

    public double getY() {
        return y;
    }

    public double getHealth() {
        return health;
    }

    public int getMoveID() {
        return moveID;
    }

}
