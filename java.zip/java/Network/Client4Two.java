package Network;

import java.io.*;
import java.net.*;

//TODO auto-match, send method, database use


// Client use in 1v1 game
// Send object

/**
 * @author Kexin
 * @update [10][23-03-2019] [Kexin][Add javadoc]
 */
public class Client4Two {
    public void setOpponent(UpdatePacket opponent) {
        this.opponent = opponent;
    }

    //    private static UpdatePacket player = new Player(300, 400, 1000);
    private UpdatePacket opponent;
    private static ObjectInputStream fromOpponent;
    private static ObjectOutputStream toOpponent;
    private int twoPlayerPort = 6140;
    UpdatePacket updatePacket;
    private Socket asClient;
    private ServerSocket asServer;

    public boolean connectedFirst() {
        return connectedFirst;
    }

    boolean connectedFirst = false;

    public Client4Two(UpdatePacket updatePacket) {
        this.updatePacket = updatePacket;
    }

    boolean flag = false;

    public UpdatePacket getOpponent() {
        return this.opponent;
    }

    boolean gameStatus;

    /**
     * This method use to connect to server
     * @return The connected socket
     * @throws Exception
     */
    public Socket connServer() throws Exception {
        Socket socket = new Socket();
        //TODO change the local host to real server
//		use this line when test two client on one computer
//        socket.connect(new InetSocketAddress(Inet4Address.getLocalHost(), ServerConf.serverPort), ServerConf.timeout);
//		use this line when have a LAN
		socket.connect(new InetSocketAddress("192.168.191.1",ServerConf.serverPort),ServerConf.timeout);
        return socket;
    }

    public void getConnect(Inet4Address address, int port) throws Exception {
        Socket socket = new Socket();
        socket.connect(new InetSocketAddress(address, port), ServerConf.timeout);
    }


    /**
     * This method use to send room creator's info to server,
     * Server will receive player's Ip + port + roomNum.
     * After that client will receive a string which tell client what happened.
     * Sever will only help player to match up.
     * After this method server will not transfer the game data during the game time(two client P2P)
     * @param roomNum The number of the room.
     * @return -1 Succeed: Send info to server succeed.
     *         -2 DUPLICATION: This room already exist, can't use duplication room number.
     *         -3 Exception: Server no response. (eg. Server stuck.)
     *         -4 Exception: Cannot connect to server. (eg. Client bad network)
     *         -5 Exception: Other exception.
     */
    public int sendRoomInfo(int roomNum) {
        try {
            Socket sdRoomInfo = connServer();
            String ip = sdRoomInfo.getLocalAddress().getHostAddress();
            int port = twoPlayerPort + roomNum;
            //get socket output stream
            OutputStream outputStream = sdRoomInfo.getOutputStream();
            //transfer socket output stream to print stream
            PrintStream socketPrintStream = new PrintStream(outputStream);
            System.out.println("NEWROOM" + ip.toString() + '&' + port + '@' + roomNum);
            socketPrintStream.println("NEWROOM" + ip.toString() + '&' + port + '@' + roomNum);
            BufferedReader serverEcho = new BufferedReader(new InputStreamReader(sdRoomInfo.getInputStream()));
            boolean flag = true;
            do {
                //read server echo
                String echo;
                try {
                    echo = serverEcho.readLine();
                    if ("GETROOMINFO".equalsIgnoreCase(echo)) {
                        flag = false;
                        socketPrintStream.close();
                        serverEcho.close();
                        sdRoomInfo.close();
                        return -1;
                    } else if ("DUPLICATION".equalsIgnoreCase(echo)) {
                        flag = false;
                        System.out.println("Room number already exist.");
                        socketPrintStream.close();
                        serverEcho.close();
                        sdRoomInfo.close();
                        return -2;
                    }
                } catch (SocketTimeoutException e) {
                    e.printStackTrace();
                    System.out.println("Server no response.");
                    socketPrintStream.close();
                    serverEcho.close();
                    sdRoomInfo.close();
                    return -3;
                }
            } while (flag);
        } catch (Exception e1) {
            // TODO Auto-generated catch block
            System.out.println("Cannot connect to server.");
            e1.printStackTrace();
            return -4;
        }
        return -5;
    }

    /**
     * This method is the main method of *create* a room.
     * 1. Send the player's info(IP+port+roomNUm) to server(use sendRoomInfo() method).
     * 2. Succeeded -> Start a socket and waiting opponent to join to room(connect to this socket).
     * @param roomNum The number of the room.
     * @throws Exception
     */
    public void createRoom(int roomNum) throws Exception {
        System.out.println("Start to create the room.");
        // Send ip + port to server
        int createStatus = sendRoomInfo(roomNum);
        if (createStatus == -1) {
            System.out.println("Room create successed!");
            asServer = new ServerSocket(twoPlayerPort + roomNum);
            // Waiting opponent to join the game
//            connectedFirst = true;
            asClient = asServer.accept();
            Receiver rc = new Receiver(asClient);
            Sender sd = new Sender(asClient);
            System.err.println("creating threads 1");
            rc.start();
            sd.start();
//            opponent.setPlayerID(2);
            rc.join();
            sd.join();
//            return;
//            asClient.close();
//            asServer.close();
        } else if (createStatus == -2) {
            System.out.println("Room number already exist.");
        } else if (createStatus == -3) {
            System.out.println("Server no response.");
        } else if (createStatus == -4) {
            System.out.println("Cannot connect to server.");
        } else {
            System.out.println("Room create failed.");
        }

        //Get opponent ip & port
//		InetAddress ip = asClient.getInetAddress();
//		InetAddress ip = InetAddress.getByName("192.168.191.1");
//		int port = asClient.getPort();
//		System.out.println("Opponent IP:" + ip);
//		System.out.println("Opponent Port:" + port);

    }

    /**
     * This method use to send join room request to server,
     * Server will receive a request and return the room creator's info.
     * @param roomNum The number of room.
     * @return info      : Room creator's info(IP+port).
     *         "NOROOM"  : No such room, the room doesn't exist.
     *         "SNR"     : Server no response. (eg. Server stuck.)
     *         "FAILCON" : Cannot connect to server. (eg. Client bad network)
     *          null     : Other exception.
     */
    public String getRoomInfo(int roomNum) {
        try {
            Socket getRoomInfo = connServer();
            OutputStream outputStream = getRoomInfo.getOutputStream();
            PrintStream socketPrintStream = new PrintStream(outputStream);
            BufferedReader serverEcho = new BufferedReader(new InputStreamReader(getRoomInfo.getInputStream()));
            socketPrintStream.println("JOINROOM" + roomNum);
            boolean flag = true;
            do {
                //read server echo
                String echo;
                try {
                    echo = serverEcho.readLine();
                    if (echo.toUpperCase().startsWith("INFO")) {
                        flag = false;
                        socketPrintStream.close();
                        serverEcho.close();
                        getRoomInfo.close();
                        return echo;
                    } else if (echo.toUpperCase().startsWith("NOROOM")) {
                        return "NOROOM";
                    }
                } catch (SocketTimeoutException e) {
                    e.printStackTrace();
                    System.out.println("Server no response.");
                    socketPrintStream.close();
                    serverEcho.close();
                    getRoomInfo.close();
                    return "SNR";
                }
            } while (flag);
        } catch (Exception e1) {
            // TODO Auto-generated catch block
            System.out.println("Cannot connect to server.");
            e1.printStackTrace();
            return "FAILCON";
        }
        return null;
    }

    /**
     * This method is the main method of *join* a room.
     * 1. Send the join request(roomNum) to server.
     * 2. Succeeded -> Get server return info(opponent IP+port).
     * 3. Use socket to connect to opponent.
     * @param roomNum The number of room.
     * @throws Exception
     */
    public void joinRoom(int roomNum) throws Exception {
        System.out.println("Start to join the room.");
        String roomInfo = getRoomInfo(roomNum);
        System.out.println(roomInfo);
        if (roomInfo.toUpperCase().startsWith("INFO")) {
            String[] info = (roomInfo.substring("INFO".length())).split("&");
            InetAddress oppoAddress = InetAddress.getByName(info[0]);
//			System.out.println(info[0]);
//			System.out.println(info[1]);
            int oppoPort = Integer.parseInt(info[1]);
            Socket asClient = new Socket();
            try {
                asClient.connect(new InetSocketAddress(oppoAddress, oppoPort), ServerConf.timeout);
                System.out.println("Join room succeeded!");

                Receiver rc = new Receiver(asClient);
                Sender sd = new Sender(asClient);
                System.err.println("creating threads 2");

//                toOpponent.writeInt(2);
                rc.start();
                sd.start();

                rc.join();
                sd.join();
//                asClient.close();
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        } else if (roomInfo.toUpperCase().startsWith("NOROOM")) {
            System.out.println("Room[" + roomNum + "] doesn't exist.");
        } else if (roomInfo.toUpperCase().startsWith("SNR")) {
            System.out.println("Server no response.");
        } else if (roomInfo.toUpperCase().startsWith("FAILCON")) {
            System.out.println("Connection failed.");
        } else {
            System.out.println("Get room info error.");
        }


//		asClient.connect(new InetSocketAddress(Inet4Address.getLocalHost(),ServerConf.serverPort),ServerConf.timeout);
//		asClient = new Socket(Inet4Address.getLocalHost(), 6140);
//		asClient = new Socket(oppoAddress, oppoPort);
        // These 4 line use to print opponent ip & address
//		InetAddress ip = asClient.getInetAddress();
//		int port = asClient.getPort();
//		System.out.println("Opponent IP:" + ip);
//		System.out.println("Opponent Port:" + port);


    }

    //TODO need to handler these exception
    /**
     * This method is use to match two player without room number.
     * 1. Use sendMatchInfo() to request match.
     * 2. Get return info from server.
     * 3. Wait connect from opponent or connect to a opponent.
     * @throws Exception
     */
    public void match() throws Exception {
        System.out.println("Start to matching.");
        String echo = sendMatchInfo();
        if (echo.startsWith("WAITMATCH")) {
            System.out.println("WAITING OPPO...");
            connectedFirst = true;
            int port = Integer.parseInt(echo.substring("WAITMATCH".length()));
            ServerSocket asServer = new ServerSocket(port);
            // Waiting opponent to join the game
            Socket asClient = asServer.accept();
//            Server.matchP1 = true;
            Receiver rc = new Receiver(asClient);
            Sender sd = new Sender(asClient);
            System.err.println("creating threads 3");
            rc.start();
            sd.start();

            rc.join();
            sd.join();
//            asClient.close();
//            asServer.close();
        } else if (echo.startsWith("MATCHING")) {
            System.out.println("MATCHING...");
            // address has been turned into string once so need to sub
            String ipPort = echo.substring("MATCHING".length() + 1);
            System.out.println("#Server echo:" + ipPort);
            String[] info = ipPort.split("@");
            InetAddress ip = InetAddress.getByName(info[0]);
            int port = Integer.parseInt(info[1]);

            System.out.println("#Oppo IP:" + ip);
            System.out.println("#Oppo Port:" + port);

            Socket asClient = new Socket();
            try {
//				asClient.connect(new InetSocketAddress(ip,port),ServerConf.timeout);
                asClient.connect(new InetSocketAddress(ip, port));
                System.out.println("Join room successed!");
//                Server.matchP2 = true;
                Receiver rc = new Receiver(asClient);
                Sender sd = new Sender(asClient);
                System.err.println("creating threads 4");
                rc.start();
                sd.start();

                rc.join();
                sd.join();
//                asClient.close();
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }

        } else if (echo.startsWith("SNR")) {
            System.out.println("Server no response.");
        } else if (echo.startsWith("CCS")) {
            System.out.println("Cannot connect server.");
        }
    }

    /**
     * This method use to send match request to server,
     * Server will receive a request and return the opponent's info.
     * @return info      : Opponent's info(IP+port).
     *         "SNR"     : Server no response. (eg. Server stuck.)
     *         "CCS" : Cannot connect to server. (eg. Client bad network)
     */
    public String sendMatchInfo() {
        try {
            Socket sdMatchInfo = connServer();
            String ip = sdMatchInfo.getLocalAddress().getHostAddress();
            System.out.println("#Send IP:" + ip);
            //get socket output stream
            OutputStream outputStream = sdMatchInfo.getOutputStream();
            //transfer socket output stream to print stream
            PrintStream socketPrintStream = new PrintStream(outputStream);
            //TODO Actually it's no need to send ip here because Sever can get IP&Port
            String print = "MATCH" + ip;
            System.out.println("#Print:" + print);
            socketPrintStream.println(print);
            BufferedReader serverEcho = new BufferedReader(new InputStreamReader(sdMatchInfo.getInputStream()));
            do {
                //read server echo
                String echo;
                try {
                    echo = serverEcho.readLine();
                    System.out.println("sendMatchInfo's ECHO:" + echo);
                    if (echo.startsWith("WAITMATCH")) {
                        System.err.println("Connected First");
                        connectedFirst = true;
                        System.out.println("Waiting opponent.");
                        socketPrintStream.close();
                        serverEcho.close();
                        sdMatchInfo.close();
                        return echo;
                    } else if (echo.startsWith("MATCHING")) {
                        System.out.println("Find the opponent, try to connection.");
                        socketPrintStream.close();
                        serverEcho.close();
                        sdMatchInfo.close();
                        return echo;
                    } else if (echo.startsWith("UNKNOWIP")) {
                        System.out.println("Error: Player1 get unknow ip.");
                    } else {
                        System.out.println("Error.");
                    }
                } catch (SocketTimeoutException e) {
                    e.printStackTrace();
                    System.out.println("Server no response.");
                    socketPrintStream.close();
                    serverEcho.close();
                    sdMatchInfo.close();
                    return "SNR";
                }
            } while (true);
        } catch (Exception e1) {
            // TODO Auto-generated catch block
            System.out.println("Cannot connect to server.");
            e1.printStackTrace();
            return "CCS";
        }
    }


    // This two method is use to change the receiver & sender's status.

    /**
     * Set the flag
     * @param flag : true for still running, false for terminate.
     */
    public void setFlag(boolean flag) {
        this.flag = flag;
    }

    /**
     * Get the status of game.
     * @return true for still running, false for terminate.
     */
    public boolean getFlag() {
        return flag;
    }

    private class Receiver extends Thread {
        private Socket client;

        /**
         * Constructor of Receiver class: get a socket
         * @param client a socket use to receive the object
         */
        Receiver(Socket client) {
            this.client = client;
        }

        /**
         * The main body of receiver thread
         */
        public void run() {
            try {
                fromOpponent = new ObjectInputStream(client.getInputStream());
                while (true) {
                    try {

                        setOpponent((UpdatePacket) fromOpponent.readObject());
                        System.out.println("you: " + updatePacket + "   enemy: " + opponent);
                        Thread.sleep(200);
                    } catch (Exception ignored) {

                    }
//                    Thread.sleep(400);
                }
            } catch (Exception e) {
                System.out.println("Receiver error.");
                e.printStackTrace();
            }

        }
    }


    public class Sender extends Thread {
        private Socket client;
        /**
         * Constructor of Sender class: get a socket
         * @param client a socket use to send the object
         */
        Sender(Socket client) {
            this.client = client;
        }

        /**
         * The main body of sender thread
         */
        public void run() {
            try {
                toOpponent = new ObjectOutputStream(client.getOutputStream());
            } catch (IOException e) {
                e.printStackTrace();
            }
            while (true) {
                try {
                    System.err.println("sending update packet");
                    toOpponent.writeObject(updatePacket);
                    toOpponent.flush();
                    Thread.sleep(200);
//                    toOpponent.reset();
//                    Thread.sleep(400);
                } catch (Exception e) {
                    System.out.println("Sender error.");
                    e.printStackTrace();
                }
            }

        }
    }

    /**
     * pack the update packet, so sender can send it.
     * @param packet
     */
    public void setUpdatePacket(UpdatePacket packet) {
        System.err.println("Updating update packet" + this.updatePacket + "\n" + packet);
        this.updatePacket = packet;
    }

    /**
     * UDP module: does't use for now.
     */
    public class UDP extends Thread {
        private Socket client;
        DatagramSocket ds = null;
        boolean done = false;

        UDP(Socket client) {
            this.client = client;
        }

        public void run() {
            try {
                // give a port to receive UDP message
                ds = new DatagramSocket(20000);
                while (done == false) {
                    //construct a receive entity
                    final byte[] buf = new byte[512];
                    DatagramPacket receivePack = new DatagramPacket(buf, buf.length);
                    //receive
                    ds.receive(receivePack);
                    //print the receive message
                    int dataLen = receivePack.getLength();
                    String sbOnline = new String(receivePack.getData(), 0, dataLen);
                    System.out.println(sbOnline);
                }
            } catch (Exception e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } finally {
                close();
            }
            ds.close();
        }

        void close() {
            if (ds != null) {
                ds.close();
                ds = null;
            }
        }

        void exit() {
            done = true;
            close();
        }
    }


}
