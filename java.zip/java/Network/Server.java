package Network;
import java.io.*;
import java.net.*;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * @author Kexin
 * @update [10][23-03-2019] [Kexin][Add java doc]
 */
public class Server {
	private static ArrayList<Socket> clientList = new ArrayList();
	private static HashMap<Integer,String> rooms = new HashMap<>();
	
	//these use in matching part
//	public static boolean matchP1=false;
//	public static boolean matchP2=false;
	//init the match() room number, start from 1, increment 1 every match, reset to 1when roomNum=100
	static int matchRoomNum = 1;
	// get the first player IP then waiting second player to get it to connect
	// reset it to null, after second player get it
	static InetAddress matcherIP = null;
	
	public static void main(String[] args) {
		ServerSocket server;
		try {
			server = new ServerSocket(6140);
			System.out.println("Server is ready!");
			System.out.println("Server Info: "+"Host"+"@Port"+server.getLocalPort());
			
			//waiting for client to connect
			for(;;) {  //infinite loop
				//get the client
				Socket client = server.accept();
				clientList.add(client);
				InetAddress ip = client.getInetAddress();
				int port = client.getPort();
				//this part is to boardcast who is online
//				try {
//					udpOnline(ip,port);
//				} catch (Exception e) {
//					// TODO Auto-generated catch block
//					e.printStackTrace();
//					System.out.println("Server UDP broadcast error!");
//				}
				
				//client asynchronous start
				ClientHandler clientHandler = new ClientHandler(client);
				//start thread
				clientHandler.start();
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("!!-01-Server failling to start.-!!");
		}
		

	}
	
	//UDP to boardcast who is online(It works, but not use now.)
	public static void udpOnline(InetAddress ip, int port) throws Exception {
		DatagramSocket ds = new DatagramSocket();
		String send = ip.toString() + "@Port"+String.valueOf(port)+" is online now~!";
		byte[] sendBytes = send.getBytes();
		DatagramPacket sendPacket = new DatagramPacket(sendBytes,sendBytes.length);
		sendPacket.setAddress(InetAddress.getByName("255.255.255.255"));
		sendPacket.setPort(20000);
		ds.send(sendPacket);
		ds.close();
	}
	
	
	
	//deal with multiply client
	//deal with client message
	private static class ClientHandler extends Thread{
		private Socket socket;
		private boolean flag = true;
		
		ClientHandler(Socket socket){
			this.socket = socket;
		}
		
		public static int parseComm(String data) {
			String newroom = "NEWROOM";
			String joinroom = "JOINROOM";
			String match = "MATCH";
			if(data.startsWith(newroom)) {
				return 1;
			}else if(data.startsWith(joinroom)) {
				return 2;
			}else if(data.startsWith(match)) {
				return 3;
			}else {
				return -1;
			}
		}
		
		public static String[] parseNewRoom(String data) {
			String newroom = "NEWROOM";
			String roomInfo = data.substring(newroom.length());
			String[] info = roomInfo.split("@");
			return info;
		}
		
		public static int parsejoinRoom(String data) {
			String joinroom = "JOINROOM";
			int roomNum = Integer.parseInt(data.substring(joinroom.length()));
			return roomNum;
		}
		
		public static String parseMatch(String data) {
			String match = "MATCH";
			String ip = data.substring(match.length());
			return ip;
		}
		
		public void run() {
			System.out.println("!-New Client Connect: "+socket.getInetAddress()+"@Port"+socket.getPort()+"-!");
			try {
				//use this to give the echo
				PrintStream socketOutput = new PrintStream(socket.getOutputStream());
				//use this to receive data
				BufferedReader socketInput = new BufferedReader(new InputStreamReader(socket.getInputStream()));
				//Try to identify what kind of command it is
				String str = socketInput.readLine();
				if (parseComm(str)==1) {
					String[] info = parseNewRoom(str);
					String creatorInfo = info[0];
					int roomNum = Integer.parseInt(info[1]);
					if(rooms.containsKey(roomNum)) {
						socketOutput.println("DUPLICATION\n");
					}else {
						rooms.put(roomNum,creatorInfo);	
						socketOutput.println("GETROOMINFO\n");
					}	
					
					
					
				}else if (parseComm(str)==2) {
					int roomNum = parsejoinRoom(str);
					if(rooms.containsKey(roomNum)) {
						String info = rooms.get(roomNum);
						socketOutput.println("INFO"+info+"\n");
					}else {
						socketOutput.println("NOROOM\n");
					}
					
					
					
				}else if (parseComm(str)==3) {
					int roomNumInit = matchRoomNum;
					int connPort;
					try {
						String matchInfo = parseMatch(str);
						System.out.println("#Sever matchInfo: Client which act as server is"+matchInfo);
						try {
							InetAddress ip = InetAddress.getByName(matchInfo);
							System.out.println("#Type conversion: ip:"+ip);
							if(matcherIP==null) {
								matcherIP = ip;
								connPort = 12000+matchRoomNum;
								socketOutput.println("WAITMATCH"+connPort+"\n");
//								while(matchP1==false) {}
//								matcherIP = null;
								System.out.println("#ClientA join successed!");
							}else if (matcherIP!=null) {
								InetAddress oppoIP = matcherIP;
								System.out.println("#Server oppoIP:"+oppoIP);
								connPort = 12000+matchRoomNum;
								socketOutput.println("MATCHING"+oppoIP+"@"+connPort+"\n");
//								while(matchP2==false) {}
//									matcherIP = null;
									matchRoomNum++;
									System.out.println("#ClientB join successed!");
									matcherIP = null;
							}
						} catch (UnknownHostException e) {
							// TODO Auto-generated catch block
							matcherIP = null;
							matchRoomNum = roomNumInit;
							socketOutput.println("UNKNOWIP\n");
							e.printStackTrace();
						}
//					} catch (SocketException e) {
//						matcherIP = null;
//						matchRoomNum = roomNumInit;
					}finally {
						if (matchRoomNum>100) {
							matchRoomNum=1;
						}
					}
				}else if (parseComm(str)==-1) {
					System.out.println("Command error. Check [parseComm()]");
				}
			} catch(EOFException e){
				System.out.println("!-"+socket.getInetAddress()+"@Port"+socket.getPort()+"client is close.-!");
			}catch (Exception e){
				System.out.println("!!-03-Connection exception.");
			}finally {
				//close the socket and connection
				//close all & socket
				try {
					socket.close();
				} catch (Exception e){
					e.printStackTrace();
				}
			}
		}
	}

}
