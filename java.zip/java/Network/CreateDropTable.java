package Network;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class CreateDropTable {
	static Connection conn;

	public static void main(String args[]) {
		createTable();
//		dropTable();
	}

	static void createTable() {
		conn = DBConnect.getConn();
		try {
			Statement stat;
			stat = conn.createStatement();
			String sql = "CREATE TABLE userInfo " + "(id INTEGER PRIMARY KEY AUTOINCREMENT,"
					+ " username CHAR(16) NOT NULL UNIQUE, " + " pswHash INTEGER NOT NULL, " + " latestIP CHAR(15), "
					+ "latestPort INTEGER)";
			stat.executeUpdate(sql);
			System.out.println("Table create successed!");
			stat.close();
		} catch (SQLException e1) {
			e1.printStackTrace();
			System.out.println("Fail to make connection.");
		}

		try {
			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	static void dropTable() {
		conn = DBConnect.getConn();
		try {
			Statement stat;
			stat = conn.createStatement();
			String sql = "DROP TABLE userInfo";
			stat.executeUpdate(sql);
			System.out.println("Table drop successed!");
			stat.close();
		} catch (SQLException e1) {
			e1.printStackTrace();
			System.out.println("Fail to make connection.");
		}

		try {
			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
