package Network;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Register {
	static Connection conn;
	private String username;
	private String psw;
	public void close(){
		try {
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	public boolean register(String username, String psw) {
		conn = DBConnect.getConn();
		PreparedStatement pstmt;
		this.username = username;
		this.psw = psw;
		int pswHash = psw.hashCode();
		final String insertUser = "insert into userInfo(username, pswHash) values(?, ?);";
		try {
			pstmt = (PreparedStatement) conn.prepareStatement(insertUser);
			pstmt.setString(1, username);
			pstmt.setInt(2, pswHash);
//			pstmt.executeUpdate();
			int i= pstmt.executeUpdate();
//            System.out.println(i);
            if(i>=1) {
                System.out.println("Register successed!");
                conn.close();
                return true;
            }else {
                System.out.println("Register failed.");
                conn.close();
                return false;
            }
		} catch (SQLException e) {
			System.out.println("Input Error!");
			System.out.println(e.getMessage());
			return false;
		} catch (Exception e) {
			System.out.println(e.getMessage());
			return false;
		}
	}
}
