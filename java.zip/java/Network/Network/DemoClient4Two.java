//package Network;
///
////Client4Two: Connect two client without server, use TCP
////Client4Mult: Connect multiply user with server, maybe use UDP
//
//
////Already tested in LAN, it works.
////--------Mode A: Play with friend---------
////1.Run server
////2.one of player create the room use(Example in Main1.java)
////  Client4Two ct = new Client4Two();
////  ct.createRoom(513); //arguement 513 is room number
////3.An other player try to join the room use(Example in Main2.java)
////  ct.joinRoom(513)
////4.Start to pass object(Player)
//
////During the game time just need to change the Object attributes.
//
//
////--------Mode B: Auto matched with something---------
////1.Run server
////2.one of player wants to play game but he doesn't have friend(Example in Main3.java)
////Client4Two ct = new Client4Two();
////ct.match;
////It will auto match one player who also in match mode
////3.An other player choose match mode too(Example in Main2.java)
////ct.match();
////4.Start to pass object
//
//import GameLogic.HumanCharacter;
//
//public class DemoClient4Two{
//	public static void main(String[] args) throws Exception {
//		//one player invite an other to join the game
//		//This three method should run in different client
//		System.out.println("Demo start!");
//		roomCreater();
////		roomJoiner();
//
////		Test: match mode
////		matcher();
//	}
//
//	public static void roomCreater() throws Exception {
//		Client4Two ct = new Client4Two(new UpdatePacket(new HumanCharacter()));
//		ct.createRoom(513);
//	}
//
//	public static void roomJoiner() throws Exception {
////		Client4Two ct = new Client4Two(new UpdatePacket(new HumanCharacter()));
//		ct.joinRoom(513);
//	}
//
//	public static void matcher() throws Exception {
//		Client4Two ct = new Client4Two(new UpdatePacket(new HumanCharacter()));
//		ct.match();
//	}
//}
