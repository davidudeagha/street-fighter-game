package Network;

public class UserConf {
	String username;
	boolean winner;
}
