package Network;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class SaveScores {
    static Connection conn;
    private String username;
    private String psw;

    public void close() {
        try {
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void save(String username, double score) {
        conn = DBConnect.getConn();
        PreparedStatement pstmt;
        this.username = username;
        int id = -1;
        final String getId = "SELECT id FROM userInfo WHERE username = ?;";
        final String insertScore = "INSERT INTO scores (playerID, score) VALUES (?,?);";
        try {
            System.err.println(username);
            pstmt = conn.prepareStatement(getId);
            pstmt.setString(1, username);
//1

            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                id = rs.getInt("id");
                rs.close();
            }
            pstmt = conn.prepareStatement(insertScore);
            System.err.println("Inserting score " + score);
            pstmt.setString(1, String.valueOf(id));
            pstmt.setString(2, String.valueOf(score));
            int i =pstmt.executeUpdate();
            conn.close();
        } catch (SQLException e) {
            System.out.println("Input Error!");
            System.out.println(e.getMessage());
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}


