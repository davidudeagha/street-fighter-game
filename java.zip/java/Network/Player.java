package Network;

import java.io.Serializable;
// An example of Object which send to other client / server
// Can initialize in other class by:
// Player playerA = new Player(500,500,1000);

// Change player coordinates by(KeyboardListener need jHook.jar):
//public void listenKeyboard() {
//	keyboard.addListener(new KeyboardListener() {
//
//		@Override
//		public void keyPressed(boolean arg0, int key) {
//			if(key==37) {
//				player.left();
//			}else if(key==38) {
//				player.up();
//			}else if(key==39) {
//				player.right();
//			}else if(key==40) {
//				player.down();
//			}
//			
//		}
//		
//	});
//}

public class  Player implements Serializable {

    private int x;
    private int y;
    private int hp;

    public Player(int x, int y, int hp) {
        this.x = x;
        this.y = y;
        this.hp = hp;
    }

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public int getHp() {
        return hp;
    }

    public void setHp(int hp) {
        this.hp = hp;
    }

    public void left() {
        this.setX(getX() - 1);
        loseHp();
    }

    public void right() {
        this.setX(getX() + 1);
        loseHp();
    }

    public void up() {
        this.setY(getY() + 1);
        loseHp();
    }

    public void down() {
        this.setY(getY() - 1);
        loseHp();
    }

    public void loseHp() {
        this.setHp(getHp() - 1);
    }

    @Override
    public String toString() {
        return "Player [x=" + x + ", y=" + y + ", hp=" + hp + "]";
    }


}
