package Network;

// To run this demo need have mysql driver
public class DemoLoginRegister {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		welcome();
//		Menu menu = new Menu();	
		Login lg = new Login();
//		System.out.println(lg.login("kxs710", "kxs710"));	//return true
//		System.out.println(lg.login("kxs710", "kxs666"));	//return false because psw wrong
//		System.out.println(lg.login("kxs666", "kxs666"));   //return false because no such user
		Register rg = new Register();
//		System.out.println(rg.register("kxs710","kxs710")); //return false because username duplicate
//		System.out.println(rg.register("aaa123","aaa321")); //return true
	}

}
