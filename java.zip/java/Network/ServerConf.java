package Network;

/**
 * @author Kexin
 */
public class ServerConf {
//	static final InetAddress serverIP = Inet4Address.getLocalHost();
	static final int serverPort = 6140;
	static final int timeout = 30000;
}
