package Network;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnect {
//	static final String username = "member";
//	static final  String password = "teamproject";
//	static final String database = "teamproject";
//	static final String URL = "jdbc:mysql://47.106.190.203:3306/" + database;
	
    public static Connection getConn() {
        Connection conn = null;
        try {
        	Class.forName("org.sqlite.JDBC");
            conn = DriverManager.getConnection("jdbc:sqlite:users.db");
//            System.out.println("Database connected!");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            System.out.println("Driver not found.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        if (conn != null) { 
            System.out.println("DBConnect - Database accessed!"); 
        } else { 
            System.out.println("Failed to make connection."); 
        } 
        return conn;
    }
}
