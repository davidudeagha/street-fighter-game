package Network;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Login {
	boolean rst;
	static Connection conn;
	private String username;
	private String psw;
	int col;

	private int getID;
	private int getHash;
	public void close(){
		try {
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	public boolean login(String username, String psw) {
		conn = DBConnect.getConn();
		PreparedStatement pstmt;
		this.username = username;
		this.psw = psw;
		int pswHash = psw.hashCode();
//		System.out.println("pswHash" + pswHash);
		String sql = "select id, pswHash from userInfo WHERE username ='" + username + "'";
		try {
			pstmt = conn.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();
			col = rs.getMetaData().getColumnCount();
			if (col > 0) {
				while (rs.next()) {
					getID = rs.getInt(1);
					getHash = rs.getInt(2);
					if (getHash == pswHash) {
						System.out.println("Login successed!");
						rs.close();
						conn.close();
						return true;

					}
				}
			} else {
				System.out.println("No such user.");
				return false;
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		try {
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
			return false;
		
	}
}
