package AI;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * redundant basic markov learner, has been replaced with more complex system to allow for integration with rest of
 * game logic
 */
public class Learner {

    private static Logger logger = Logger.getLogger(Learner.class);

    private int[] history = new int[]{1, 1, 1};

    private List<List<List<Integer>>> transitions = new ArrayList<>(4);

    private List<List<Integer>> resultsTable = new ArrayList<>();

    /**
     * @param scores static move, score combinations, e.g score[i][j] is the score resulting from action i against j
     */
    public Learner(List<List<Integer>> scores) {
        logger.setLevel(Level.TRACE);
        initTransitions();
        initResultsTable(scores);

    }

    /**
     * initialises the transitions table to a uninformed prior, i.e no actions have been taken by either player
     */
    private void initTransitions() {
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 4; j++) {
                List<List<Integer>> t = new ArrayList<>();
                for (int k = 0; k < 4; k++) {
                    t.add(Arrays.asList(1, 1, 1, 1));
                }
                transitions.add(t);
            }
        }
    }

    /**
     * initialises the results table of all move combination (i.e. the point gain for option i against j)
     *
     * @param scores pass-through
     */
    private void initResultsTable(List<List<Integer>> scores) {
        for (int i = 0; i < 4; i++) {
            List<Integer> t = new ArrayList<>();
            for (int j = 0; j < 4; j++) {
                t.add((scores.get(j).get(i) - scores.get(i).get(j)));
            }
            resultsTable.add(t);
        }
        logger.fatal(resultsTable);

    }

    /**
     * updates the history and increments the transitions with the new information
     *
     * @param moveID what move has been played
     */
    public void update(Integer moveID) {
        history = new int[]{history[1], history[2], moveID};
        int x = transitions.get(history[0]).get(history[1]).get(history[2]);

        transitions.get(history[0]).get(history[1]).set(history[2], x + 1);
        System.out.println("\n");

    }

    public List<Float> predict() {
        List<Float> probabilities = new ArrayList<>();

        List<Integer> trans = transitions.get(history[1]).get(history[2]);
        Integer sum = 0;
        for (int k = 0; k < 4; k++) {
            sum += trans.get(k);
        }
        for (int k = 0; k < 4; k++) {
            probabilities.add((trans.get(k) / (float) sum));
        }
//        logger.trace(probabilities);
        return probabilities;

    }


    public Integer chooseMove() {
        List<Float> prob = predict();
        logger.trace(prob);
        List<Float> ExpectedScores = new ArrayList<>();
        //Initialising scores array
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 4; j++) {
                if (i == 0) {
                    ExpectedScores.add(0f);
                }
                Float x = ExpectedScores.get(j);
                ExpectedScores.set(j, x + (prob.get(i) * resultsTable.get(i).get(j)));

            }

        }
        Float bestScore = (float) -Integer.MIN_VALUE;
        logger.warn("Scores" + ExpectedScores);
        Integer bestMove = 0;
        for (int i = 0; i < 4; i++) {
            if (ExpectedScores.get(i) > bestScore) {
                bestScore = ExpectedScores.get(i);
                bestMove = i + 1;
            }
        }

        return bestMove;

    }

}
