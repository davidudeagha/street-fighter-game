package AI;

import Utils.MoveMap;

import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class IntegratedMarkovHumanTest {


    public static void main(String[] args) {
        Map map = new MoveMap().getMap();
        int humanHealth = 300;
        int aiHealth = 300;
        IntegratedMarkovLearner learner = new IntegratedMarkovLearner();
        List<List<Double>> s = learner.getResultsTable();

        Scanner scanner = new Scanner(System.in);
        List<List<Double>> scores = learner.getResultsTable();
        int humanScore = 0;
        int aiScore = 0;
        int humanMove;
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 4; j++) {
                if (i != j) {
                    System.out.println("Move " + (i + 1) + " against move " + (j + 1) + " \ngives you " + s.get(i).get(j) + " \nthe computer " + s.get(j).get(i) + "\n");
                } else {
                    System.out.println("All clashes of the same move give 0 to each player");
                }
            }
        }
        while (true) {
            System.out.println("Human: " + humanHealth + "\n AI: " + aiHealth);

            System.out.println("Enter a move (1-4) or -1 to exit ");

            humanMove = scanner.nextInt() - 1;
            if (humanMove == -2) {
                System.out.println("\n\n\n Final Scores : \n You: " + humanScore + "\n Computer: " + aiScore);
                System.exit(0);
            }


            int aiMove = learner.chooseMove(100,105) ;

            aiHealth -= s.get(humanMove).get(aiMove);
            humanHealth -= s.get(aiMove).get(humanMove);
            if (humanHealth<=0){
                System.out.println("Human player is dead");
                System.exit(0);
            }
            if (aiHealth<=0){
                System.out.println("AI player is dead");
                System.exit(0);
            }
            System.out.println("You chose move " + (humanMove + 1) + "\n The computer chose move " + (aiMove + 1) + "\n you scored " +
                    s.get(humanMove).get(aiMove) + "\n The computer scored " + s.get(aiMove).get(humanMove));
            learner.update(humanMove);
        }
    }

}


