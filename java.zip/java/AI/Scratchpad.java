package AI;

import java.util.Arrays;
import java.util.List;
import java.util.Random;

class Scratchpad {


    public static void main(String[] args) {
//        int[][] scores = {{10, 0, 0, 10}, {10, 10, 10, 0}, {5, 0, 0, 0}, {0, 5, 0, 0}};

        List<List<Integer>> s = Arrays.asList(Arrays.asList(10, 0, 0, 10), Arrays.asList(10, 10, 10, 0), Arrays.asList(5, 0, 0, 0), Arrays.asList(0, 5, 0, 0));
        BasicMarkovLearner learner = new BasicMarkovLearner(s);
        int nextPred = 0;
        int correct = 0;
        for (int i = 0; i < 120; i++) {
            Random random = new Random();
            int move = random.nextInt(3) + 1;
            System.out.println("move: " + move);
            if (nextPred == move && i >= 20) {
                System.out.println("Correct!");
                correct++;
            }
            learner.update(move);

//            System.out.println(learner.predict());
            nextPred = learner.chooseMove();
            System.out.println("next prediction: " + nextPred);


//            System.out.println(random.nextInt(4));
        }
        System.out.println("% Accuracy: " + correct + "%");

        System.out.println("END");


    }
}



