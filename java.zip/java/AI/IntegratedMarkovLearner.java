package AI;

import GameLogic.Move;
import Utils.MoveMap;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import static java.lang.Math.abs;

public class IntegratedMarkovLearner {
    //todo if neither player has made a damaging move for (random timeperiod > threshold ) then make one (most likely to inflict damage)

    private static Logger logger = Logger.getLogger(IntegratedMarkovLearner.class);


    private List<List<List<Integer>>> transitions = new ArrayList<>(4);

    private List<List<Double>> resultsTable = new ArrayList<>();
    /**
     * stores previous moves the human player has taken.
     */
    private List<Integer> history;

    public List<List<List<Integer>>> getTransitions() {
        return transitions;
    }


    public List<List<Double>> getResultsTable() {
        return resultsTable;
    }


    public List<Float> getExpectedScores() {
        return expectedScores;
    }


    private List<Float> expectedScores;
    private Map<Integer, Move> moves;

    /**
     *
     */
    public IntegratedMarkovLearner() {
        logger.fatal("Creating Learner");
        logger.setLevel(Level.TRACE);
        this.moves = new MoveMap().getMap();

        this.history = new ArrayList<>() {{
            add(1);
            add(1);
            add(1);
        }};
        initTransitions();
        initResultsTable();

    }

    /**
     * initialises the transitions table to a uninformed prior, i.e no actions have been taken by either player
     */
    private void initTransitions() {
//        for (int i = 0; i < moves.size(); i++) {

        for (int j = 0; j < moves.size(); j++) {
            List<List<Integer>> t = new ArrayList<>();
            for (int k = 0; k < moves.size(); k++) {
                t.add(Arrays.asList(1, 1, 1, 1, 1, 1));
            }
            transitions.add(t);
        }
//        }
    }

    /**
     * initialises the results table of all move combination (i.e. the point gain for option i against j)
     */
    private void initResultsTable() {

        for (int i = 0; i < this.moves.size(); i++) {
            List<Double> t = new ArrayList<>();
            for (int j = 0; j < this.moves.size(); j++) {

                double x;
                if (this.moves.get(j).getHitBox() == this.moves.get(i).getHitBox()) {
                    x = this.moves.get(i).getDamage() - this.moves.get(j).getMoveDmgNeg();
                } else {
                    x = this.moves.get(i).getDamage();
                }
                // todo review this, here if two players try to do the same move at the same time the result will be 0
                if (i == j) {
                    x = 0;
                }
                if (x < 0) {
                    t.add(0D);
                } else {
                    t.add(x);
                }
            }

            resultsTable.add(t);
        }
//        System.out.println("restable" + resultsTable);
//        logger.fatal(resultsTable);

    }

    /**
     * updates the history and increments the transitions with the new information
     *
     * @param moveID what move has been played
     */
    public void update(Integer moveID) {

//        history = new Pair<Integer,Move>[]{history[1], history[2], move};
        if (moveID != -1) {
            this.history = new ArrayList<>() {{
                add(history.get(1));
                add(history.get(2));
                add(moveID);
            }};
            try {
                int x = transitions.get((history.get(0))).get((history.get(1))).get((history.get(2)));

                transitions.get((history.get(0))).get((history.get(1))).set((history.get(2)), x + 1);
            } catch (Exception ignored) {

            }
        }
    }

    /**
     * program to generate the probabilities of each move being made by the human player
     *
     * @return returns a list of probabilities that a move is made
     */
    private List<Float> predict() {
        List<Float> probabilities = new ArrayList<>();

        List<Integer> trans = transitions.get(history.get(1)).get(history.get(2));
        int sum = 0;
        for (Integer tran1 : trans) {
            sum += tran1;
        }
        for (Integer tran : trans) {
            probabilities.add((tran / (float) sum));
        }
//        logger.trace(probabilities);
        return probabilities;

    }

    private int countSinceLastDamagingMove = 0;

    /**
     * chooses the move that is expected to have the highest return
     *
     * @return returns moveID of optimum move
     */

    public Integer chooseMove(double currentPos, double playerPos) {
        List<Float> probs = predict();
//        logger.trace(prob);
        expectedScores = new ArrayList<>();
//        logger.trace("Probs" + probs);
        //Initialising scores array
        for (int i = 0; i < probs.size(); i++) {
            for (int j = 0; j < probs.size(); j++) {
                if (i == 0) {
                    expectedScores.add(0f);
                }
                Float x = expectedScores.get(j);
                // revises prediction using weighted data from probabilities and result mappings from resultsTable
                expectedScores.set(j, (float) (x + (probs.get(i) * resultsTable.get(j).get(i))));

            }

        }

//        logger.warn("Scores" + expectedScores);
        int bestMove = getBestMove(expectedScores);
        List<Move> bestMoves = new ArrayList<>();
        for (int i = 0; i < expectedScores.size(); i++) {
            bestMoves.add(moves.get(i));
        }
        for (int i = 0; i < expectedScores.size(); i++) {
//            logger.trace("Range diff" + abs(currentPos_x - playerPos) + "range of move" + bestMoves.get(bestMove).getRange() + "bool " + (bestMoves.get(bestMove).getRange() < (abs(currentPos_x - playerPos))));
            if (bestMoves.get(bestMove).getRange() < (abs(currentPos - playerPos))) {
                bestMove = getBestMove(expectedScores.subList(1, expectedScores.size()));
            } else {
                break;
            }
        }
        if (bestMoves.get(bestMove).getRange() < (abs(currentPos - playerPos))) {
            if ((currentPos - playerPos) < 0) {

                logger.warn("Moving right");
                bestMove = 6;
            } else {
                logger.warn("Moving left");
                bestMove = 7;
            }
        }
        int highestProb = 0;
        for (int i = 0; i < probs.size(); i++) {
            if (probs.get(i) > highestProb) {
                highestProb = i;
            }
        }
        //if human player is set to do more damage than AI, attempt to block it
        if (bestMove != 6 && bestMove != 7) {
            // to avoid two AIs constantly blocking, the max number of blocks in a row is 4
            if (!(countSinceLastDamagingMove > 4)) {
                if (moves.get(highestProb).getDamage() > moves.get(bestMove).getDamage()) {
                    if (moves.get(highestProb).getHitBox() == 1) {
                        bestMove = 4;
                    } else {
                        bestMove = 5;
                    }
                    countSinceLastDamagingMove++;
                }
            } else {
                countSinceLastDamagingMove = 0;
            }
        }
        logger.fatal("Move chosen by learner: " + moves.get(bestMove));
        return bestMove;

    }

    private int getBestMove(List<Float> scores) {
        Float bestScore = (float) -Integer.MAX_VALUE;
        int bestMove = 0;
        for (int i = 0; i < scores.size(); i++) {
            if (scores.get(i) > bestScore) {
                bestScore = scores.get(i);
                bestMove = i;
            }
        }
        return bestMove;
    }
}
