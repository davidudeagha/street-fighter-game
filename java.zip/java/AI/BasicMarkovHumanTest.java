package AI;

import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class BasicMarkovHumanTest {


    public static void main(String[] args) {
        List<List<Integer>> s = Arrays.asList(Arrays.asList(10, 0, 0, 10), Arrays.asList(10, 10, 10, 0), Arrays.asList(5, 0, 0, 0), Arrays.asList(0, 5, 0, 0));
        BasicMarkovLearner learner = new BasicMarkovLearner(s);

        Scanner scanner = new Scanner(System.in);
        List<List<Integer>> scores = learner.getResultsTable();
        int humanScore = 0;
        int aiScore = 0;
        int humanMove;
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 4; j++) {
                if (i != j) {
                    System.out.println("Move " + (i + 1) + " against move " + (j + 1) + " \ngives you " + s.get(i).get(j) + " \nthe computer " + s.get(j).get(i) + "\n");
                } else {
                    System.out.println("All clashes of the same move give 0 to each player");
                }
            }
        }
        while (true) {
            System.out.println("Human: " + humanScore + "\n AI: " + aiScore);

            System.out.println("Enter a move (1-4) or -1 to exit ");

            humanMove = scanner.nextInt() - 1;
            if (humanMove == -2) {
                System.out.println("\n\n\n Final Scores : \n You: "+humanScore+ "\n Computer: "+aiScore);
                System.exit(0);
            }


            int aiMove = learner.chooseMove() - 1;

            humanScore += s.get(humanMove).get(aiMove);
            aiScore += s.get(aiMove).get(humanMove);
            System.out.println("You chose move " + (humanMove + 1) + "\n The computer chose move " + (aiMove + 1) + "\n you scored " +
                    s.get(humanMove).get(aiMove) + "\n The computer scored " + s.get(aiMove).get(humanMove));
            learner.update(humanMove);
        }
    }

}
