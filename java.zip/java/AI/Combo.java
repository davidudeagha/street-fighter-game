package AI;

import GameLogic.Move;

import java.util.List;

public class Combo {

    // moves in order of execution e.g. punch, block, kick, punch, step backwards as objects
    private List<Move> moves;

    public List<Move> getMoves() {
        return moves;
    }

    public Combo(List moves) {
        this.moves = moves;
    }

//
//    public void run(){
//        for (Move move: moves){
//            execute(move);
//        }
//    }
//
//    private void execute(Move move){
//        if (move.inRange()){
//            move.execute();
//            return;
//        }else{
//            moveForward.execute();
//            execute(move);
//        }
//    }
}
