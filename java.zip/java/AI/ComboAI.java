package AI;

import GameLogic.*;

import java.util.List;
import java.util.Random;

public class ComboAI {
    private Move[] comboOneList = new Move[]{new HighBlock(), new HighPunch(), new HighBlock(), new LowKick()};
    private Combo comboOne = new Combo(List.of(comboOneList));

    private Move[] comboTwoList = new Move[]{new LowBlock(), new LowPunch(), new LowKick(), new LowBlock()};
    private Combo comboTwo = new Combo(List.of(comboTwoList));

    private Move[] comboThreeList = new Move[]{new LowBlock(), new HighPunch(), new LowKick(), new HighBlock()};
    private Combo comboThree = new Combo(List.of(comboThreeList));

    public void run() {
        Combo[] combos = new Combo[]{comboOne, comboTwo, comboThree};
        while (true) {
            Random random = new Random();
            Combo currentCombo = combos[random.nextInt(combos.length)];
            for (Move move : currentCombo.getMoves()) {
                break;
//                move.execute();
            }

        }

    }


}
