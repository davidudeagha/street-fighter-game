package Audio;

import javax.sound.sampled.*;
import java.io.File;

/**
 * @author Kexin
 * @update [01][23-03-2019] [Kexin][Create file]
 */
public class Audio {
    private BGMPlayer BGM;
    private SEPlayer punch;
    private SEPlayer lowKick;
    private SEPlayer highKick;
    private SEPlayer win;
    private SEPlayer fail;

    private float BGMVolume = 60;
    private float SEVolume = 60;

    public Audio(){
        this.BGM = loadBGM(new File(AudioConf.BGM));
        this.highKick = loadSounds(new File(AudioConf.highKickSound));
        this.lowKick = loadSounds(new File(AudioConf.lowKickSound));
        this.punch = loadSounds(new File(AudioConf.punchSound));
        this.win = loadSounds(new File(AudioConf.win));
        this.fail = loadSounds(new File(AudioConf.fail));
    }

    public void setBGMVolume(float v){
        if(v>=0&&v<=80) {
            this.BGMVolume = v;
            this.BGM.setVolume(this.BGMVolume);
        }
    }

    /**
     * Set the sound effect volume
     * @param v the volume
     */
    public void setSEVolume(float v){ if(v>=0&&v<=80) this.SEVolume = v; }

    /**
     * Start to play background music
     */
    public void playBGM(){ this.BGM.play(); }

    /**
     * Mute background music
     */
    public void muteBGM(){ this.BGM.setVolume(0.0f); }

    /**
     * Play punch sound effect
     */
    public void punchSound(){ this.punch.play(); }

    /**
     * play high kick sound effect
     */
    public void highKickSound(){ this.highKick.play(); }

    /**
     * play low kick sound effect
     */
    public void lowKickSound(){ this.lowKick.play(); }

    public void winSound(){ this.win.play(); }

    public void failSound(){ this.fail.play(); }
    /**
     * mute sound effect
     */
    public void muteSE(){ setSEVolume(0.0f); }

    /**
     *
     * @param file
     * @return a Clip that generated from the file
     */
    private Clip getClip(File file){
        Clip clip=null;
        try {
            AudioInputStream audioStream = AudioSystem.getAudioInputStream(file);
            AudioFormat format = audioStream.getFormat();
            DataLine.Info info = new DataLine.Info(Clip.class, format);
            clip = (Clip) AudioSystem.getLine(info);
            clip.open(audioStream);
        }catch (Exception e) {
            System.out.println("#Audio - clip error.");
            e.printStackTrace();
        }
        return clip;
    }

    /**
     * Load the background music file
     * @param file background music file
     * @return a background music player object
     */
    public BGMPlayer loadBGM(File file){ return new BGMPlayer(getClip(file)); }

    /**
     * Load the sound effect file
     * @param file sound effect file
     * @return a sound effect player object
     */
    public SEPlayer loadSounds(File file){ return new SEPlayer(getClip(file)); }



    /** -------------------------------------------------------------------------------------------*/
    private class BGMPlayer{
        Clip clip;
        FloatControl floatControl;

        /**
         * Constructor of BGMPlayer
         * @param clip
         */
        public BGMPlayer(Clip clip){
            this.clip=clip;
            floatControl = (FloatControl)clip.getControl(FloatControl.Type.MASTER_GAIN);
        }

        /**
         * Loop: play BGM
         */
        public void play(){
            setVolume(BGMVolume);
            clip.loop(Clip.LOOP_CONTINUOUSLY);
        }

        /**
         * Set volume
         * @param volume
         */
        public void setVolume(float volume){
            floatControl.setValue(volume-80);
        }
    }

    /** -------------------------------------------------------------------------------------------*/
    private class SEPlayer{
        Clip clip;
        FloatControl floatControl;

        /**
         * Constructor of SEPlayer
         * @param clip
         */
        public SEPlayer(Clip clip){
            this.clip=clip;
            floatControl = (FloatControl)clip.getControl(FloatControl.Type.MASTER_GAIN);
        }

        /**
         * Play the sound effects
         */
        public void play(){
            floatControl.setValue(SEVolume-80);
            new Thread(new Runnable() {
                @Override
                public void run() {
                    clip.setMicrosecondPosition(0);
                    clip.start();
                }
            }).start();

        }
    }
}
