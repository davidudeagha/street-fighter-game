package Audio;

/**
 *  @author Kexin 3/23/2019
 */
public class AudioConf {
    public static final String highKickSound = "src/main/resources/sounds/highKick.wav";
    public static final String lowKickSound = "src/main/resources/sounds/lowKick.wav";
    public static final String punchSound = "src/main/resources/sounds/punch.wav";
    public static final String BGM = "src/main/resources/sounds/Big Mojo.wav";
    public static final String win = "src/main/resources/sounds/win.wav";
    public static final String fail = "src/main/resources/sounds/fail.wav";
}
